package toodle.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import toodle.model.AutoLoginEntry;

public class AutoLoginEntryDAO {
	@Autowired
	private SqlSessionTemplate sql;
	
	public void insert(AutoLoginEntry entry) {
		sql.insert("sql.autoLoginEntry.insert", entry);
	}
	public List<AutoLoginEntry> selectBySelector(String selector) {
		return sql.selectList("sql.autoLoginEntry.selectBySelector", selector);
	}
	public void deleteOldEntries() {
		sql.delete("sql.autoLoginEntry.deleteOldEntries");
	}
	public void delete(AutoLoginEntry entry) {
		sql.delete("sql.autoLoginEntry.delete", entry);
	}
	
	public void updateLastLogin(AutoLoginEntry entry){
		sql.update("sql.autoLoginEntry.updateLastLogin", entry);
	}
}
