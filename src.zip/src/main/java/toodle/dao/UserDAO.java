package toodle.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import toodle.model.User;

public class UserDAO {

	@Autowired
	private SqlSessionTemplate sql;

	public int insert(User dto){
		return sql.insert("sql.user.insert",dto);
	}

	public User selectByIdx(String idx) {
		return sql.selectOne("sql.user.selectByIdx", idx);
	}

	public User selectByEmail(String email){
		return sql.selectOne("sql.user.selectByEmail", email);
	}

	public int update(User dto){
		return sql.update("sql.user.update", dto);
	}
	
	public List<User> selectByTaskIdx(String idx){
		return sql.selectList("sql.user.selectByTaskIdx", idx);
	}
	
	public List<User> selectUserContacts(String userIdx){
		return sql.selectList("sql.user.selectUserContacts", userIdx);
	}
	
	public User selectByUserEmail(String email){
		return sql.selectOne("sql.user.selectByUserEmail", email);
	}
	
	public int updatePassword(String email, String newpassword){
		Map<String, Object> params=new HashMap<String, Object>();
		params.put("email", email);
		params.put("newpassword", newpassword);
		return sql.update("sql.user.updatePassword", params);
		
	}
	
	public int updateSettings(String userIdx, String settings){
		Map<String, Object> param=new HashMap<String, Object>();
		param.put("userIdx", userIdx);
		param.put("settings", settings);
		int count = sql.update("sql.user.upadteSettings", param);
		return count;
	}
}
