package toodle.dao;

import static toodle.util.Str.isEmpty;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import toodle.model.EntityCount;
import toodle.model.Reminder;
import toodle.model.Task;
import toodle.util.Entry;
import toodle.util.Utils;

public class TaskDAO {
	@Autowired
	private SqlSessionTemplate sqlMap;

	@Autowired
	private SqlSessionFactoryBean sqlSessionFactoryBean;

	final private String SQL_NAMESPACE = "sql.task.";

	public void setSqlMap(SqlSessionTemplate sqlMap) {
		this.sqlMap = sqlMap;
	}

	public Task selectByIdx(String taskIdx) {
		return sqlMap.selectOne(SQL_NAMESPACE + "selectByIdx", taskIdx);
	}

	public Task selectByIdxForUser(String taskIdx, String userIdx) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("idx", taskIdx);
		params.put("userIdx", userIdx);
		return sqlMap.selectOne(SQL_NAMESPACE + "selectByIdxForUser", params);
	}

	public String[] filterValidIdxes(String taskIdxes[], String userIdx) {
		if (taskIdxes == null) {
			return new String[0];
		}
		if (taskIdxes.length < 1) {
			return new String[0];
		}
		List<String> idxes = sqlMap.selectList(SQL_NAMESPACE + "filterValidIdxes", Utils.buildStrMap(
			"userIdx", userIdx,
			"idxes", taskIdxes));
		return idxes.toArray(new String[idxes.size()]);
	}

	public void insert(Task task) {
		sqlMap.insert(SQL_NAMESPACE + "insert", task);
	}

	public void update(Task task) {
		sqlMap.update(SQL_NAMESPACE + "update", task);
	}

	public void delete(String[] idxes) {
		if (idxes == null) {
			return;
		}
		if (idxes.length < 1) {
			return;
		}
		sqlMap.delete(SQL_NAMESPACE + "delete", idxes);
	}

	public void deleteAssignees(String taskIdx) {
		sqlMap.delete(SQL_NAMESPACE + "deleteAssignees", taskIdx);
	}

	public void addAssignees(String taskIdx, String userIdxes[]) {
		if (!Utils.isEmptyArray(userIdxes)) {
			Map<String, Object> params = new HashMap<String, Object>();
			for (int i = 0; i < userIdxes.length; i++) {
				params.put("taskIdx", taskIdx);
				params.put("userIdx", userIdxes[i]);
				params.put("ord", i);
				sqlMap.insert(SQL_NAMESPACE + "addAssignee", params);
			}
		}
	}

	public int countAssignments(String userIdx) {
		return sqlMap.selectOne(SQL_NAMESPACE + "countAssignments", userIdx);
	}

	public List<Task> assignmentsList(String userIdx) {
		return sqlMap.selectList(SQL_NAMESPACE + "assignments", userIdx);
	}

	public List<Task> selectByDate(String dateFrom, String dateTo, String userIdx) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("dateFrom", dateFrom);
		params.put("dateTo", dateTo);
		params.put("userIdx", userIdx);
		return sqlMap.selectList(SQL_NAMESPACE + "selectByDate", params);
	}

	public List<Task> selectImportantTasks(String userIdx) {
		return sqlMap.selectList(SQL_NAMESPACE + "selectImportantTasks", userIdx);
	}

	public int countImportantTasks(String userIdx) {
		return sqlMap.selectOne(SQL_NAMESPACE + "countImportantTasks", userIdx);
	}

	public List<Task> searchByKeywords(String userIdx, String fields[], String keyword) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("userIdx", userIdx);
		params.put("fields", fields);
		params.put("keyword", keyword);
		return sqlMap.selectList(SQL_NAMESPACE + "searchByKeywords", params);
	}

	public void deleteHashtags(String taskIdx) {
		deleteHashtags(new String[] { taskIdx });
	}

	public void deleteHashtags(String[] taskIdxes) {
		if (taskIdxes == null) {
			return;
		}
		if (taskIdxes.length < 1) {
			return;
		}
		sqlMap.delete(SQL_NAMESPACE + "deleteHashtags", taskIdxes);
	}

	public void insertHashtags(String taskIdx, Set<String> tags) {
		if (tags != null && tags.size() > 0) {
			sqlMap.insert(SQL_NAMESPACE + "insertHashtags", Utils.buildStrMap(
				"taskIdx", taskIdx,
				"tags", tags));
		}
	}

	public Collection<String> selectHashtags(String userIdx) {
		return sqlMap.selectList(SQL_NAMESPACE + "selectHashtags", userIdx);
	}

	public void sort(String taskIdxes[], String userIdx) {
		if (taskIdxes == null || taskIdxes.length < 1) {
			return;
		}

		try {
			SqlSessionFactory sessionFactory = sqlSessionFactoryBean.getObject();
			SqlSession sqlSession = sessionFactory.openSession(ExecutorType.BATCH, false);
			try {
				for (int i = 0; i < taskIdxes.length; i++) {
					if (isEmpty(taskIdxes[i])) {
						continue;
					}
					sqlSession.update(SQL_NAMESPACE + "updateOrd", Utils.buildStrMap(
						"taskIdx", taskIdxes[i],
						"userIdx", userIdx,
						"ord", taskIdxes.length - i));
				}
				sqlSession.commit();
			} finally {
				sqlSession.close();
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public Map<String, Object> selectDailyTaskCount(String userIdx, String dateFrom, String dateTo) {
		List<Entry> entries = sqlMap.selectList(SQL_NAMESPACE + "selectDailyTaskCount", Utils.buildStrMap(
			"userIdx", userIdx,
			"dateFrom", dateFrom,
			"dateTo", dateTo));
		return Entry.toHashMap(entries);
	}

	public List<Reminder> selectReminders() {
		return sqlMap.selectList(SQL_NAMESPACE + "selectReminders");
	}

	public List<String> selectUserIdxes(String taskIdx, String userIdx) {
		return sqlMap.selectList(SQL_NAMESPACE + "selectUserIdxes", Utils.buildStrMap(
			"taskIdx", taskIdx,
			"userIdx", userIdx));
	}

	public void deleteBadAssignees() {
		sqlMap.delete(SQL_NAMESPACE + "deleteBadAssignees");
	}

	public void sortSubtasks(String taskIdx, String idxes[]) {
		try {
			SqlSessionFactory sessionFactory = sqlSessionFactoryBean.getObject();
			SqlSession sqlSession = sessionFactory.openSession(ExecutorType.BATCH, false);
			try {
				for (int i = 0; i < idxes.length; i++) {
					if (isEmpty(idxes[i])) {
						continue;
					}
					sqlSession.update(SQL_NAMESPACE + "updateSubtaskOrd", Utils.buildStrMap(
						"taskIdx", taskIdx,
						"subtaskIdx", idxes[i],
						"ord", i));
				}
				sqlSession.commit();
			} catch (Exception e) {
				throw new RuntimeException(e);
			} finally {
				sqlSession.close();
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public Map<String, EntityCount> countEntities(String idxes[]) {
		return sqlMap.selectMap(SQL_NAMESPACE + "countEntities", idxes, "idx");
	}

	public List<Reminder> selectStaleReminders(String userIdx) {
		return sqlMap.selectList(SQL_NAMESPACE + "selectStaleReminders", userIdx);
	}
}
