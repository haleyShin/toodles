package toodle.dao;

class ListUserPair {
	private String listIdx;
	private String userIdx;
	public ListUserPair(String listIdx, String userIdx) {
		this.listIdx = listIdx;
		this.userIdx = userIdx;
	}
	public String getListIdx() {
		return listIdx;
	}
	public String getUserIdx() {
		return userIdx;
	}	
}
