package toodle.dao;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import toodle.model.EntityCount;
import toodle.model.Task;
//import toodle.controller.api.states;
import toodle.model.TaskList;
import toodle.model.User;
import toodle.util.Utils;

public class TaskListDAO {

	@Autowired
	private SqlSessionTemplate sqlMap;

	final private String SQL_NAMESPACE = "sql.taskList.";

	public void setSqlMap(SqlSessionTemplate sqlMap) {
		this.sqlMap = sqlMap;
	}

	public void insert(TaskList taskList) {
		sqlMap.insert(SQL_NAMESPACE + "insert", taskList);
	}
	
	public void insertUser(TaskList taskList) {
		sqlMap.insert(SQL_NAMESPACE + "insertUser", taskList);
	}

	public void update(TaskList taskList){
		sqlMap.update(SQL_NAMESPACE + "update", taskList);
	}

	public void updateUser(TaskList taskList){
		sqlMap.update(SQL_NAMESPACE + "updateUser", taskList); 
	}

	public void updateUserState(String listIdx, String userIdx, String state) {
		sqlMap.update(SQL_NAMESPACE + "updateUserState", Utils.buildStrMap(
			"listIdx", listIdx,
			"userIdx", userIdx,
			"state", state
		));
	}
	
	public void restoreList(String listIdx, String userIdx){
		sqlMap.update(SQL_NAMESPACE + "restoreList", new ListUserPair(listIdx, userIdx));
	}

	
	public void deleteUsers(String listIdx, String ...userIdxes){
		if (userIdxes != null && userIdxes.length > 0) {
			sqlMap.delete(SQL_NAMESPACE + "deleteUsers", Utils.buildStrMap( 
				"listIdx", listIdx,
				"userIdxes", userIdxes	
			));			
		}
	}
	
	public void totallyDeleteList(String listIdx, String userIdx){
		sqlMap.update(SQL_NAMESPACE + "totallyDeleteList", new ListUserPair(listIdx, userIdx));
	}
	
	public void deleteOtherUsers(String listIdx, String userIdx) {
		sqlMap.delete(SQL_NAMESPACE + "deleteOtherUsers", new ListUserPair(listIdx, userIdx));
	}
	

	public void sort(String listIdx, String userIdx, int ord, String folder){
		sqlMap.update(SQL_NAMESPACE + "sort", Utils.buildStrMap(
			"listIdx", listIdx,
			"userIdx", userIdx,
			"ord", ord,
			"folder", folder
		));
	}
	
	public List<TaskList> myLists(String userIdx){
		return sqlMap.selectList(SQL_NAMESPACE + "selectMyLists", userIdx);
	}

	public TaskList selectByIdx(String listIdx, String userIdx) {
      	return sqlMap.selectOne(SQL_NAMESPACE + "selectByIdx", new ListUserPair(listIdx, userIdx));
	}

	public List<TaskList> selectInvitations(String userIdx){
		return sqlMap.selectList(SQL_NAMESPACE + "selectInvitations", userIdx);
	}

	public List<Task> selectTasksByIdx(String listIdx, String userIdx) {
		return sqlMap.selectList(SQL_NAMESPACE + "selectTasksByIdx", new ListUserPair(listIdx, userIdx));
	}

	public List<User> selectUsersByState(String states[], String listIdx) {
		return sqlMap.selectList(SQL_NAMESPACE+"selectUsersByState", Utils.buildStrMap( 
			"listIdx", listIdx,
			"states", states
		));
	}

	public HashSet<String> selectUserIdxes(String listIdx, String userIdx) {
		List<String> idxes = sqlMap.selectList(SQL_NAMESPACE + "selectUserIdxes", Utils.buildStrMap(
			"listIdx", listIdx,
			"userIdx", userIdx
		));
		return new HashSet<String>(idxes);
	}

	public String selectUserState(String listIdx, String userIdx) {
		List<String> result = sqlMap.selectList(SQL_NAMESPACE + "selectUserState", new ListUserPair(listIdx, userIdx));
		if (result.size() > 0) {
			return result.get(0);			
		} else {
			return null;
		}
	}

	public int countNotCompleted(String listIdx, String userIdx) {
		try {
			return sqlMap.selectOne(SQL_NAMESPACE + "countNotCompleted", new ListUserPair(listIdx, userIdx));	
		} catch(NullPointerException ne) {
			return 0;
		}
	}

	public void inviteUsers(String listIdx, String ...userIdxes){
		if (userIdxes != null && userIdxes.length > 0) {
			sqlMap.insert(SQL_NAMESPACE + "inviteUsers", Utils.buildStrMap(
				"listIdx", listIdx,
				"userIdxes", userIdxes
			));			
		}
	}

	public List<String> selectTaskOrderByIdx(String userIdx, String listIdx){
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("userIdx", userIdx);
		params.put("listIdx", listIdx);
		return sqlMap.selectList(SQL_NAMESPACE+"selectTaskOrderByIdx", params);
	}

	public void markDelete(String listIdx) {
		sqlMap.update(SQL_NAMESPACE + "markDelete", listIdx);
	}

	public List<TaskList> deletedLists(String userIdx) {
		return sqlMap.selectList(SQL_NAMESPACE + "deletedLists", userIdx);
	}

	public List<EntityCount> getListEntities(String listIdx){
		return sqlMap.selectList(SQL_NAMESPACE + "getListEntities", listIdx);
	}
}
