package toodle.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import toodle.model.Notice;
import toodle.util.Utils;

public class NoticeDAO {
	@Autowired
	private SqlSessionTemplate sqlMap;
	
	final private String SQL_NAMESPACE = "sql.notice.";
	
	public void setSqlMap(SqlSessionTemplate sqlMap) {
		this.sqlMap = sqlMap;
	}
	
	public List<String> selectTargetUserIdxes(String taskIdx, String currentUserIdx){
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("taskIdx", taskIdx);
		params.put("currentUserIdx", currentUserIdx);
		return sqlMap.selectList(SQL_NAMESPACE + "selectTargetUserIdxes", params);
	}

	public String insertNoticeTask(String taskIdx, String userIdx) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("taskIdx", taskIdx);
		params.put("userIdx", userIdx);
		sqlMap.insert(SQL_NAMESPACE + "insertNoticeTask", params);
		return params.get("idx").toString();
	}

	public void insertNoticeUsers(String noticeIdx) {
		sqlMap.insert(SQL_NAMESPACE+"insertNoticeUsers", noticeIdx);
	}
	
	public String insertNoticeAssign(String taskIdx, String userIdx, String assigneeIdxes[]){
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("idx", null);
		params.put("taskIdx", taskIdx);
		params.put("userIdx", userIdx);
		params.put("assigneeIdxes", assigneeIdxes);
		sqlMap.insert(SQL_NAMESPACE + "insertNoticeAssign", params);
		return params.get("idx").toString();
	}

	public String insertNoticeCompleted(String taskIdx, String userIdx){
		Map<String, Object> params=new HashMap<String, Object>();
		params.put("idx", null);
		params.put("taskIdx", taskIdx);
		params.put("userIdx", userIdx);
		sqlMap.insert(SQL_NAMESPACE+"insertNoticeCompleted", params);
		return params.get("idx").toString();
	}

	public String insertNoticeAttachment(String taskIdx, String userIdx) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("taskIdx", taskIdx);
		params.put("userIdx", userIdx);
		sqlMap.insert(SQL_NAMESPACE + "insertNoticeAttachment", params);
		return params.get("idx").toString();
	}

	public String insertNoticeSubtaskAdd(String taskIdx, String userIdx) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("taskIdx", taskIdx);
		params.put("userIdx", userIdx);
		sqlMap.insert(SQL_NAMESPACE + "insertNoticeSubtaskAdd", params);
		return params.get("idx").toString();
	}

	public String insertNoticeComment(String taskIdx, String userIdx, String commentIdx){
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("idx", null);
		params.put("taskIdx", taskIdx);
		params.put("userIdx", userIdx);
		params.put("commentIdx", commentIdx);
		sqlMap.insert(SQL_NAMESPACE + "insertNoticeComment", params);
		return params.get("idx").toString();
	}

	public List<Notice> selectLastNotice(String userIdx) {
		return sqlMap.selectList(SQL_NAMESPACE + "selectLastNotice", userIdx);
	}
	
	public void updateLastSeen(String userIdx, String noticeIdx) {
		sqlMap.selectList(SQL_NAMESPACE + "updateLastNotice", Utils.buildStrMap( 
			"userIdx", userIdx,
			"noticeIdx", noticeIdx
		));		
	}

}
