package toodle.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import toodle.model.Subtask;

public class SubtaskDAO {
	@Autowired
	private SqlSessionTemplate sqlMap;

	final private String SQL_NAMESPACE = "sql.subtask.";
	
	public void insert(Subtask subtask){
		sqlMap.insert(SQL_NAMESPACE + "insert", subtask);
	}
	public List<Subtask> selectByTaskIdx(String taskIdx){
		return sqlMap.selectList(SQL_NAMESPACE + "selectByTaskIdx", taskIdx);
	}
	public void delete(String idx){
		sqlMap.delete(SQL_NAMESPACE + "delete", idx);
	}
	public Subtask select(String idx){
		return sqlMap.selectOne(SQL_NAMESPACE + "select", idx);
	}
	public void update(Subtask subtask){
		sqlMap.update(SQL_NAMESPACE + "update", subtask);
	}
}
