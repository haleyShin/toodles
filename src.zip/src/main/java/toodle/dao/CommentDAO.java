package toodle.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import toodle.model.Comment;
import toodle.util.Utils;

public class CommentDAO {

	@Autowired
	private SqlSessionTemplate sqlMap;
	
	final private String SQL_NAMESPACE = "sql.comment.";
	
	public void setSqlMap(SqlSessionTemplate sqlMap){
		this.sqlMap = sqlMap;
	}
	
	public void insert(Comment comment){
		sqlMap.insert(SQL_NAMESPACE + "insert", comment);
	}
	
	public Comment selectByIdx(String idx) {
		return sqlMap.selectOne(SQL_NAMESPACE + "selectByIdx", idx);
	}

	public List<Comment> selectByTaskIdx(String taskIdx,String userIdx){
		return sqlMap.selectList(SQL_NAMESPACE + "selectByTaskIdx", Utils.buildStrMap(
			"taskIdx", taskIdx,
			"userIdx", userIdx
		));
	}

	public boolean delete(String idx, String userIdx){
		return sqlMap.delete(SQL_NAMESPACE + "delete" , Utils.buildStrMap(
			"commentIdx", idx,
			"userIdx", userIdx
		)) > 0;
	}
}
