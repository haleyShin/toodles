package toodle.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import toodle.model.Attachment;

public class AttachmentDAO {
	
	@Autowired
	private SqlSessionTemplate sqlMap;
	
	final private String SQL_NAMESPACE = "sql.attachment.";
	
	public void setSqlMap(SqlSessionTemplate sqlMap) {
		this.sqlMap = sqlMap;
	}
	
	public AttachmentDAO() {
		super();
	}

	public int insertAttachment(Attachment attachment){
		int count = sqlMap.insert(SQL_NAMESPACE+"insert", attachment);
		return count;
	}
	
	public List<Attachment> selectByTaskIdx(String taskIdx){
		return sqlMap.selectList(SQL_NAMESPACE+"selectByTaskIdx", taskIdx);
	}
	
	public int deleteByAttachmentIdx(String attachmentIdx){
		int count = sqlMap.delete(SQL_NAMESPACE+"deleteByAttachmentIdx",attachmentIdx);
		return count;
	}
	
	public String selectUserstateDown(String attachmentIdx, String userIdx){
		Map<String, Object> params=new HashMap<String, Object>();
		params.put("attachmentIdx", attachmentIdx);
		params.put("userIdx", userIdx);
		return sqlMap.selectOne(SQL_NAMESPACE+"selectUserstateDown", params);
	}
	
	public String selectAttachmentName(String attachmentIdx){
		return sqlMap.selectOne(SQL_NAMESPACE+"selectAttachmentName", attachmentIdx);
	}
	
	
}
