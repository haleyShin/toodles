package toodle.service;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RootController {
	
	@Autowired 
	private SmtpMailSender smtpMailSender;
	
	@RequestMapping(method=RequestMethod.GET, value="/send-mail")
	public void sendMail() throws MessagingException{
		
	smtpMailSender.send("gpdlfflha@gmail.com", "dkfjdk", "testing");
	}
		
	
}
