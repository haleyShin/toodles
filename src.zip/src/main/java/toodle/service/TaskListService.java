package toodle.service;


import java.util.HashSet;
import java.util.Set;

import javax.management.RuntimeErrorException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.transaction.annotation.Transactional;

import toodle.dao.TaskDAO;
import toodle.dao.TaskListDAO;
import toodle.exception.APIException;
import toodle.model.TaskList;
import toodle.model.User;
import toodle.request.ListRequest;
import static toodle.util.Str.strEquals;
import static toodle.util.Str.isEmpty;
import static toodle.util.Str.strIn;

public class TaskListService {
	
	@Autowired
	private TaskDAO taskDAO;

	@Autowired
	private TaskListDAO taskListDAO;
	
	@Autowired
	private User currentUser;
	
	@Autowired
	private SyncMessagingService syncMessagingService;
	/**
	 * 다음 같은 동작을 한다.
	 * 
	 * 1) 목록 생성/수정
	 * 
	 * - listIdx가 null이면 목록을 새로 생성한다.
	 * - listIdx가 null이 아니면:
	 *     - 현재 사용자가 초대받은 사람인 경우: 구성원이 된다.
	 *     - 현재 사용자가 구성원이거나 소유자인 경우: 목록을 수정한다.
	 * 
	 * 목록이 없으면 404, 권한이 없으면 400에러.
	 * 
	 * 2) 사용자 초대/추방
	 * 
	 * 3) 소유자 변경
	 * 
	 * 권한이 없으면 400 에러.
	 * 
	 * @param listIdx 목록의 idx
	 * @param data    요청 데이터
	 * @param partial 부분적 업데이트 여부
	 * @return
	 */
	@Transactional
	public TaskList save(String listIdx, ListRequest data, boolean partial) {
		boolean exiting = false;
		boolean dirty;
		Set<String> oldUsers;
		TaskList list;

		if (listIdx == null) {
			if (isEmpty(data.getName())) {
				throw new APIException(HttpStatus.BAD_REQUEST, "missing argument: name");
			}
			list = new TaskList();
			dirty = false;
			data.setChown(null);

			data.update(list);
			list.setUserIdx(currentUser.getIdx());
			list.setUserState("owner");
			list.setOrd(0);

			oldUsers = new HashSet<String>();
			taskListDAO.insert(list);
			taskListDAO.insertUser(list);
			listIdx = list.getIdx();

		} else {
			list = taskListDAO.selectByIdx(listIdx, currentUser.getIdx());
			if (list == null) {
				throw new APIException(HttpStatus.NOT_FOUND);
			}
			if (list.getIdx().equals(currentUser.getInboxIdx())) {
				throw new APIException(HttpStatus.BAD_REQUEST, "cannot modify inbox");
			}

			String userState = list.getUserState();
			if (strEquals(userState, "invited")) {
				dirty = true;
				data.setChown(null);
				data.setExpels(null);
				data.setInvites(null);
				list.setUserState("member");

			} else if (strIn(userState, "member", "owner")) {
				
				// 자기가 나갈 때는 변경이나 초대를 못하게
				exiting = strIn(currentUser.getIdx(), data.getExpels());
				if (exiting) {
					data.setInvites(null);
					data.setChown(null);
					dirty = true;

				} else {
					if (partial) {
						dirty = data.partialUpdate(list);
					} else {
						String error = data.validate();
						if (error != null) {
							throw new APIException(HttpStatus.BAD_REQUEST, error);
						}
						dirty = data.update(list);
					}			
				}

			} else {
				throw new APIException(HttpStatus.BAD_REQUEST, "permission denied");
			}

			oldUsers = taskListDAO.selectUserIdxes(list.getIdx(), currentUser.getIdx()); 
			taskListDAO.update(list);
			taskListDAO.updateUser(list);				

		}

		taskListDAO.deleteUsers(listIdx, data.getExpels());
		taskListDAO.inviteUsers(listIdx, data.getInvites());
		if (data.getChown() != null) {
			if (!strEquals(taskListDAO.selectUserState(listIdx, currentUser.getIdx()), "owner")) {
				throw new APIException(HttpStatus.BAD_REQUEST, "failed to chown: permission denied");
			}
			if (!strEquals(taskListDAO.selectUserState(listIdx, data.getChown()), "member")) {
				throw new APIException(HttpStatus.BAD_REQUEST, "failed to chown: target user is not a member");
			}
			taskListDAO.updateUserState(listIdx, currentUser.getIdx(), "member");
			taskListDAO.updateUserState(listIdx, data.getChown(), "owner");
		}

		// 불량 담당자 제거
		taskDAO.deleteBadAssignees();
		
		Set<String> newUsers = taskListDAO.selectUserIdxes(listIdx, currentUser.getIdx());
		syncMessagingService.notifyListUsers(listIdx, oldUsers, newUsers, dirty);

		// 자기가 나간 경우
		if (exiting) {
			return null;
		}

		list.setUserCount(newUsers.size() + 1);
		return list;
	}
	
	/**
	 * 목록의 순서를 저장한다.
	 * 
	 * @param idxes 목록idx[:폴더 이름] 형식의 배열 
	 */
	@Transactional
	public void updateSorting(String[] idxes) {
		for (int i = 0; i < idxes.length; i++) {
			String idx = idxes[i];
			int colonIdx = idx.indexOf(':');
			String folder = null;
			if (colonIdx >= 0) {
				folder = idx.substring(colonIdx + 1);
				idx = idx.substring(0, colonIdx);
			}
			taskListDAO.sort(idx, currentUser.getIdx(), i, folder);
		}
	}
	@Transactional
	public void delete(String listIdx) {
		TaskList list = taskListDAO.selectByIdx(listIdx, currentUser.getIdx());
		if (list == null) {
			throw new APIException(HttpStatus.NOT_FOUND);
		}
		
		if (list.getIdx() == currentUser.getInboxIdx()) {
			throw new APIException(HttpStatus.BAD_REQUEST, "inbox cannot be deleted");
		}

		String state = list.getUserState();
		if (strIn(state, "invited", "member")) {
			taskListDAO.deleteUsers(listIdx, currentUser.getIdx());
			syncMessagingService.notifyListUsers(listIdx, SyncType.update);
		} else if (strEquals(state, "owner")) {
			syncMessagingService.notifyListUsers(listIdx, SyncType.delete);
			taskListDAO.deleteOtherUsers(listIdx, currentUser.getIdx());
			taskListDAO.markDelete(listIdx);
		} else {
			throw new APIException(HttpStatus.BAD_REQUEST, "permission denied");

		}
		taskDAO.deleteBadAssignees();
	}
}
