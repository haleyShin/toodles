package toodle.service;

import static toodle.util.Str.strIn;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import toodle.dao.TaskDAO;
import toodle.dao.TaskListDAO;
import toodle.exception.APIException;
import toodle.model.Task;
import toodle.model.User;
import toodle.request.TaskRequest;

public class TaskService {

	@Autowired
	private TaskDAO taskDAO;
	
	@Autowired
	private TaskListDAO taskListDAO;

	@Autowired
	private NoticeService noticeService;
	
	@Autowired
	private SyncMessagingService syncMessagingService;

	@Autowired
	private User currentUser;

	public Task[] cloneTasks(String taskIdxes[], Map<String, String> changes) {
		String validIdxes[] = taskDAO.filterValidIdxes(taskIdxes, currentUser.getIdx());
		Task tasks[] = new Task[validIdxes.length];
		for (int i = 0; i < validIdxes.length; i++) {
			Task task = getOrFail(validIdxes[i]);
			TaskRequest data = new TaskRequest(task);
			data.modify(changes);
			String _ = null;
			tasks[i] = save(_, data, false);
		}
		return tasks;
	}

	public Task[] save(String taskIdxes[], TaskRequest data, boolean partial) {
		String validIdxes[] = taskDAO.filterValidIdxes(taskIdxes, currentUser.getIdx());
		Task tasks[] = new Task[validIdxes.length];
		for (int i = 0; i < validIdxes.length; i++) {
			tasks[i] = save(validIdxes[i], data, partial);
		}
		return tasks;
	}

	public Task save(String taskIdx, TaskRequest data, boolean partial) {

		if (data.getListIdx() == null) {
			// 새로 만드는 경우나 부분 업데이트가 아니면
			if (taskIdx == null || !partial) {
				data.setListIdx(currentUser.getInboxIdx());			
			}
		}

		// 작업 가져오기/새로 만들기
		Task task;
		if (taskIdx == null) {
			task = new Task();
			task.setUserIdx(currentUser.getIdx());
		} else {
			task = taskDAO.selectByIdxForUser(taskIdx, currentUser.getIdx());
			if (task == null) {
				throw new APIException(HttpStatus.NOT_FOUND);
			}
		}
		
		// 공지를 위해 미리 받아 놓는 값
		boolean wasCompleted = task.isCompleted();
		
		// 데이터 세팅
		boolean isDirty;
		try {
			if (partial) {
				isDirty = data.updatePartial(task);
			} else {
				isDirty = data.update(task);
			}			
		} catch (IllegalStateException e) {
			throw new APIException(HttpStatus.BAD_REQUEST, e.getMessage());
		}
		
		// 권한 검사
		String state = taskListDAO.selectUserState(task.getListIdx(), currentUser.getIdx());
		if (!strIn(state, "owner", "member")) {
			throw new APIException(HttpStatus.BAD_REQUEST, "permission denied");
		}

		// DB에 반영
		if (task.getIdx() == null) {
			taskDAO.insert(task);
		} else {
			taskDAO.update(task);
		}
		
		// 동기화 메시지
		if (taskIdx == null) {
			syncMessagingService.notifyTaskUsers(task.getIdx(), SyncType.insert);			
		} else {
			if (isDirty) {
				syncMessagingService.notifyTaskUsers(taskIdx, SyncType.update);				
			}
		}
		
		// 공지 생성
		if (taskIdx == null) {
			noticeService.insertNoticeTask(task.getIdx());
		} else {
			if (!wasCompleted && task.isCompleted()) {
				noticeService.insertNoticeCompleted(task.getIdx());
			}
		}

		// 해시 태그 색인
		taskDAO.deleteHashtags(task.getIdx());
		taskDAO.insertHashtags(task.getIdx(), task.extractTags());

		//무결성유지
		taskDAO.deleteBadAssignees();

		return task;
	}

	public Task getOrFail(String taskIdx) {
		Task task = taskDAO.selectByIdxForUser(taskIdx, currentUser.getIdx());
		if (task == null) {
			throw new APIException(HttpStatus.NOT_FOUND);
		}
		return task;
	}

	public Object delete(String taskIdx) {
		String[] idxes = taskDAO.filterValidIdxes(taskIdx.split(","), currentUser.getIdx());
		for (String idx : idxes) {
			syncMessagingService.notifyTaskUsers(idx, SyncType.delete);			
		}
		taskDAO.deleteHashtags(idxes);
		taskDAO.delete(idxes);
		return true;
	}
}
