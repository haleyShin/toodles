package toodle.service;

public enum EntityType {
	list,
	task
}
