package toodle.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;

import toodle.dao.TaskDAO;
import toodle.dao.TaskListDAO;
import toodle.model.User;
import toodle.util.Utils;
 
public class SyncMessagingService {
	
	@Autowired
	private TaskListDAO taskListDAO;
	
	@Autowired
	private TaskDAO taskDAO;
	
	@Autowired
	private SimpMessagingTemplate message;
	
	@Autowired
	private User currentUser;
	
	public void notifyListUsers(
		String listIdx,
		Set<String> before,
		Set<String> after,
		boolean changed
	) {
		Set<String> deletes = Utils.setDifference(before, after);
		Set<String> inserts = Utils.setDifference(after, before);
		Set<String> updates = Utils.setIntersection(before, after);
		if (changed || deletes.size() > 0 || inserts.size() > 0) {
			for (String userIdx : updates) {
				notifyUser(userIdx, EntityType.list, SyncType.update, listIdx);
			}
		}
		for (String userIdx : deletes) {
			notifyUser(userIdx, EntityType.list, SyncType.delete, listIdx);
		}
		for (String userIdx: inserts) {
			notifyUser(userIdx, EntityType.list, SyncType.insert, listIdx);
		}
	}

	public void notifyListUsers(String listIdx, SyncType syncType) {
		Set<String> userIdxes = taskListDAO.selectUserIdxes(listIdx, currentUser.getIdx());
		for (String userIdx : userIdxes) {
			notifyUser(userIdx, EntityType.list, SyncType.update, listIdx);
		}
	}

	public void notifyTaskUsers(String taskIdx, SyncType syncType) {
		notifyTaskUsers(taskIdx, syncType, null);
	}

	public void notifyTaskUsers(String taskIdx, SyncType syncType, String extra) {
		List<String> userIdxes = taskDAO.selectUserIdxes(taskIdx, currentUser.getIdx());
		for (String userIdx : userIdxes) {
			notifyUser(userIdx, EntityType.task, syncType, taskIdx, extra);
		}
	}

	private void notifyUser(String userIdx, EntityType entity, SyncType sync, String identifier) {
		notifyUser(userIdx, entity, sync, identifier, null);
	}

	private void notifyUser(String userIdx, EntityType entity, SyncType sync, String identifier, String extra) {
		if (extra == null) {
			message.convertAndSend("/topic/sync/" + userIdx, entity + " " + sync + " " + identifier);
		} else {
			message.convertAndSend("/topic/sync/" + userIdx, entity + " " + sync + " " + identifier + " " + extra);			
		}
	}
}
