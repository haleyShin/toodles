package toodle.service;

import static toodle.util.Utils.getCookieByName;
import static toodle.util.Utils.makeKillerCookie;

import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeUtility;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import toodle.dao.AutoLoginEntryDAO;
import toodle.dao.UserDAO;
import toodle.model.AutoLoginEntry;
import toodle.model.User;

public class LoginService {

	@Autowired
	private AutoLoginEntryDAO autoLoginEntryDAO;
	
	@Autowired
	private UserDAO userDAO;


	
	public void authenticate(String email, String password, User currentUser) {
		User user = userDAO.selectByEmail(email);
		if (user == null) {
			return;
		}
		if (password.equals(user.getPassword())) {
			currentUser.merge(user);
		}
	}

	public void issueAutoLoginToken(HttpServletResponse response, User currentUser) {
		AutoLoginEntry entry = AutoLoginEntry.generate(currentUser.getIdx());
		autoLoginEntryDAO.insert(entry);
		response.addCookie(entry.makeCookie("autoLogin"));
	}
	
	public User getAutoLoginUser(HttpServletRequest request, User currentUser) {
		AutoLoginEntry fromCookie = new AutoLoginEntry(getCookieByName(request.getCookies(), "autoLogin"));
		if (!fromCookie.hasValidSelector()) {
			return null;
		}

		List<AutoLoginEntry> entries = autoLoginEntryDAO.selectBySelector(fromCookie.getSelector());		
		AutoLoginEntry match = fromCookie.check(entries);
		if (match == null) {
			return null;
		} else {
			autoLoginEntryDAO.updateLastLogin(fromCookie);
			return userDAO.selectByIdx(match.getUserIdx());			
		}
	}

	public void deleteAutoLoginToken(HttpServletRequest req, HttpServletResponse res, User currentUser) {
		AutoLoginEntry entry = new AutoLoginEntry(getCookieByName(req.getCookies(), "autoLogin"), currentUser.getIdx());
		res.addCookie(makeKillerCookie("autoLogin"));
		if (entry.getSelector() != null) {
			autoLoginEntryDAO.delete(entry);
		}
	}
	


}
