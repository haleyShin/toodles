package toodle.service;

public enum SyncType {
	update,
	delete,
	insert,
	subtask,
	attachment,
	comment,
	assign
}
