package toodle.service;

import org.springframework.beans.factory.annotation.Autowired;

import toodle.dao.NoticeDAO;
import toodle.model.User;

public class NoticeService {

	@Autowired
	private NoticeDAO noticeDAO;
	
	@Autowired
	private User currentUser;


	public void insertNoticeTask(String taskIdx){
		noticeDAO.insertNoticeUsers(noticeDAO.insertNoticeTask(taskIdx, currentUser.getIdx()));
	}
	
	public void insertNoticeAssign(String taskIdx, String assigneeIdxes[]){
		noticeDAO.insertNoticeUsers(noticeDAO.insertNoticeAssign(taskIdx, currentUser.getIdx(), assigneeIdxes));
	}

	public void insertNoticeCompleted(String taskIdx){
		noticeDAO.insertNoticeUsers(noticeDAO.insertNoticeCompleted(taskIdx, currentUser.getIdx()));
		
	}

	public void insertNoticeAttachment(String taskIdx) {
		noticeDAO.insertNoticeUsers(noticeDAO.insertNoticeAttachment(taskIdx, currentUser.getIdx()));
		
	}

	public void insertNoticeSubtaskAdd(String taskIdx) {
		noticeDAO.insertNoticeUsers(noticeDAO.insertNoticeSubtaskAdd(taskIdx, currentUser.getIdx()));
		
	}
	
	public void insertNoticeComment(String taskIdx, String commentIdx){
		noticeDAO.insertNoticeUsers(noticeDAO.insertNoticeComment(taskIdx, currentUser.getIdx(), commentIdx));
	}

}
