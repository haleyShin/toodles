package toodle.view;

import java.io.OutputStream;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.view.AbstractView;

public class UploadErrorView extends AbstractView {

	public UploadErrorView() {
		setContentType("application/download; charset=utf-8");
	}

	@Override
	protected @ResponseBody void renderMergedOutputModel(Map<String, Object> model,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
			
		response.setStatus(400);
		String msg = (String)model.get("업로드 용량제한을 초과했습니다.");
		response.setContentType(getContentType());
		response.setContentLength(msg.length());
		OutputStream out = response.getOutputStream();
		out.flush();
	}

}
