package toodle.util;

public class NewPassword {

	/*public static void main(String[] args){
	String pwd="";
	for(int i=0;i<8;i++){
		char pwdstr=(char)(Math.random()*26+97);
		if(i%3==0){
			pwd+=(int)(Math.random()*10);
		}else{
			pwd+=pwdstr;
		}
	}
	System.out.println(pwd);
	
	}*/
	public String newPassword(){
		String pwd="";
		for(int i=0;i<8;i++){
			char pwdstr=(char)(Math.random()*26+97);
			if(i%2==0){
				pwd+=(int)(Math.random()*10);
			}else{
				pwd+=pwdstr;
			}
		}
		return pwd;
	}
}
