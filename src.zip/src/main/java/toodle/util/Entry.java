package toodle.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Entry {
	private String key;
	private Object value;
	public static Map<String, Object> toHashMap(List<Entry> entries) {
		Map<String, Object> map = new HashMap<String, Object>();
		for (Entry entry : entries) {
			map.put(entry.key, entry.value);
		}
		return map;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public Object getValue() {
		return value;
	}
	public void setValue(Object value) {
		this.value = value;
	}
}
