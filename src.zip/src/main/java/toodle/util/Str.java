package toodle.util;

import java.security.SecureRandom;
import java.util.HashSet;
import java.util.Set;

final public class Str {
	private static final Set<String> trueValues = new HashSet<String>(4);
	private static final Set<String> falseValues = new HashSet<String>(4);
	static {
		trueValues.add("true");
		trueValues.add("on");
		trueValues.add("yes");
		trueValues.add("1");
		
		falseValues.add("false");
		falseValues.add("off");
		falseValues.add("no");
		falseValues.add("0");
	}

	private static SecureRandom rnd = new SecureRandom();

	public static boolean strEquals(String s1, String s2) {
		if (s1 == null && s2 == null) {
			return true;
		}
		if (s1 == null || s2 == null) {
			return false;
		}
		return s1.equals(s2);
	}

	public static boolean strIn(String needle, String ...haystack) {
		if (haystack == null || haystack.length < 1) {
			return false;
		}
		for (String s : haystack) {
			if (strEquals(needle, s)) {
				return true;
			}
		}
		return false;
	}

	public static String nullIfEmpty(String s) {
		if (s == null || s.isEmpty()) {
			return s;
		} else {
			return s;
		}
	}

	public static boolean isEmpty(String s) {
		return s == null || s.isEmpty();
	}
	public static boolean isNotEmpty(String s) {
		return !isEmpty(s);
	}

	public static String randomString(int length) {
		return randomString(length, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXWYZ1234567890!@#$%^&*()-_+=");
	}

	public static String randomString(int length, String charSpace) {
		StringBuffer buff = new StringBuffer();
		int charSpaceSize = charSpace.length();
		while (length-- > 0) {
			buff.append(charSpace.charAt(rnd.nextInt(charSpaceSize)));
		}
		return buff.toString();
	}
	
	public static String getSuffix(String s) {
		int dotIndex = s.lastIndexOf('.');
		if (dotIndex < 0) {
			return "";
		} else {
			return s.substring(dotIndex);
		}
	}

	public static Boolean parseBoolean(String source) {
		if (isEmpty(source)) {
			return null;
		}
		source = source.toLowerCase();
		if (trueValues.contains(source)) {
			return true;
		} else if (falseValues.contains(source)){
			return false;
		} else {
			throw new IllegalArgumentException("Invalid boolean value: " + source);
		}
	}
}
