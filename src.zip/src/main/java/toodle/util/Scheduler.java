package toodle.util;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import toodle.dao.TaskDAO;
import toodle.model.Reminder;
import toodle.service.SmtpMailSender;

@Configuration
@EnableAsync
@EnableScheduling
@Service
public class Scheduler {

	@Autowired
	private TaskDAO taskDAO;

	@Autowired
	private SimpMessagingTemplate message;	

	@Autowired 
	private SmtpMailSender smtpMailSender;

	@Scheduled(cron="*/60 * * * * *")
	public void xmlFixedDelayTask() throws MessagingException{
		for (Reminder reminder : taskDAO.selectReminders()) {
			System.out.println("reminder:" + "/topic/sync/" + reminder.getUserIdx());
			message.convertAndSend("/topic/sync/" + reminder.getUserIdx(), "task reminder " + reminder.getTaskIdx());
			String subject = "[작업 알림] " + reminder.getTaskName();
			String body = reminder.getTaskName() + "에 대해 설정하신 알림입니다.";
			try {
				smtpMailSender.send(reminder.getEmail(), subject, body);					
			} catch (Exception e) {
				e.printStackTrace();
			}
		}			
	}
}
