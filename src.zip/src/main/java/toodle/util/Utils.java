package toodle.util;

import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import javax.servlet.http.Cookie;

import org.apache.logging.log4j.core.util.datetime.FastDateFormat;

public class Utils {
	static String PATTERN = "yyyy-MM-dd";
	static FastDateFormat dateFormat =  FastDateFormat.getInstance(PATTERN, TimeZone.getTimeZone("GMT+9"));
	final private static SimpleDateFormat iso8601Date = new SimpleDateFormat("yyyy-MM-dd");

	public static void main(String[] args) throws Exception {
		Date date=new Date();
		getWeekStart(date);
	}

	public static Map<String, Object> buildStrMap(Object ...things) {
		if (things.length % 2 != 0) {
			throw new IllegalArgumentException("The number of arguments is not even.");
		}
		Map<String, Object> map = new HashMap<String, Object>();
		for (int i = 0; i < things.length; i += 2) {
			map.put(String.valueOf(things[i]), things[i+1]);
		}
		return map;
	}
	
	public static Cookie getCookieByName(Cookie[] cookies, String name) {
		return getCookieByName(cookies, name, "");
	}

	public static Cookie getCookieByName(Cookie[] cookies, String name, String defaultValue) {
		for (Cookie cookie : cookies) {
			if (cookie.getName().equals(name)) {
				return cookie;
			}
		}
		return new Cookie(name, defaultValue);
	}
	
	public static Cookie makeKillerCookie(String name) {
		Cookie c = new Cookie(name, "");
		c.setMaxAge(0);
		return c;
	}
	


	public static Date getWeekStart(Date today){
		SimpleDateFormat simpledate=new SimpleDateFormat("yyyy-MM-dd");
		Calendar calendar=Calendar.getInstance();
		calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
		calendar.add(Calendar.DATE, 7-7);
		String sunday_s=simpledate.format(calendar.getTime());
		Date sunday=null;
		try {
			sunday=simpledate.parse(sunday_s);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		System.out.println(sunday);
		return sunday;
		
	}

	public static String getToday(){
		 
		 
		  Date date = new Date();
		  
		  String getToday = dateFormat.format(date);
		return getToday;
		
	}
	public static String getTime(){
		  String PATTERN_TIME = "HH:mm";
		  FastDateFormat dateFormat2 =  FastDateFormat.getInstance(PATTERN_TIME, TimeZone.getTimeZone("GMT+9"));
			
		  Date date = new Date();
		
		  String getTime = dateFormat2.format(date);
		return getTime;
	}
	public static String getYesterday(){
		 
		 
		 
		 Calendar calender = Calendar.getInstance();
		 calender.add(Calendar.DATE, -1);
		 String getYesterday = dateFormat.format(calender.getTime());
		 return getYesterday;
		
	}
	public static String getTommorow(){
		 
		 
		 Calendar calender = Calendar.getInstance();
		 calender.add(Calendar.DATE, +1);
		 String getTommorow = dateFormat.format(calender.getTime());
		 return getTommorow;
	}
	
	public static String getFirstDayOfMonth(String month, String year){
		
	
		 Calendar calender = GregorianCalendar.getInstance();
		 calender.set(Calendar.YEAR,Integer.valueOf(year));
		 calender.set(Calendar.MONTH, Integer.valueOf(month)-1);
		 calender.set(Calendar.DAY_OF_MONTH,1);
		 
		 String firstDayOfMonth = dateFormat.format(calender.getTime());
		 return firstDayOfMonth;
	}
	public static String getLastDayOfMonth(String month, String year){
		
		 
		 Calendar calender = GregorianCalendar.getInstance();
		 calender.set(Calendar.YEAR,Integer.valueOf(year));
		 calender.set(Calendar.MONTH, Integer.valueOf(month));
		 calender.set(Calendar.DATE,0);
		 
		 String	lastDayOfMonth = dateFormat.format(calender.getTime());
		 return lastDayOfMonth;
	}
	
	public static <T> Set<T> setDifference(Set<T> a, Set<T> b) {
		Set<T> aClone = new HashSet<T>(a);
		aClone.removeAll(b);
		return aClone;
	}
	
	public static <T> Set<T> setIntersection(Set<T> a, Set<T> b) {
		Set<T> aClone = new HashSet<T>(a);
		aClone.retainAll(b);
		return aClone;
	}
	
	public static boolean isEqualDate(Date d1, Date d2) {
		if (d1 == null && d2 == null) {
			return true;
		}
		if (d1 == null || d2 == null) {
			return false;
		}
		if (d1.after(d2) || d1.before(d2)) {
			return false;
		}
		return true;
	}
	
	public static Date parseDate(String str, SimpleDateFormat ...formats) {
		for (SimpleDateFormat format : formats) {
			try {
				return format.parse(str);
			} catch (ParseException e) {
				continue;
			}
		}
		return null;
	}
	
	public static boolean isEmptyArray(Object[] a) {
		return (a == null || a.length < 1);

	}
	//난수 발생 메소드
	public static String RandomNum(){
		StringBuffer buffer = new StringBuffer();
		for(int i=0; i <=6; i++){
			int n = (int) (Math.random()*10);
			buffer.append(n);
		}
		return buffer.toString();
	}
	
	//회원가입할때 맨처음 회원 프로필사진 생성해주는 메서드
	public static BufferedImage generateIdenticons(String text, int image_width, int image_height) {
        int width = 5, height = 5;

        byte[] hash = text.getBytes();

        MessageDigest md = null;
		try {
			md = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e);
		}
        byte[] theDigest = md.digest(hash);

        BufferedImage identicon = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        WritableRaster raster = identicon.getRaster();

        int [] background = new int [] {255,255,255, 0};
        int [] foreground = new int [] {theDigest[0] ^ 255, theDigest[1] ^ 255, theDigest[2] ^ 255, 255};

        for(int x=0 ; x < width ; x++) {
            //Enforce horizontal symmetry
            int i = x < 3 ? x : 4 - x;
            for(int y=0 ; y < height; y++) {
                int [] pixelColor;
                //toggle pixels based on bit being on/off
                if((theDigest[i] >> y & 1) == 1)
                    pixelColor = foreground;
                else
                    pixelColor = background;
                raster.setPixel(x, y, pixelColor);
            }
        }

        BufferedImage finalImage = new BufferedImage(image_width, image_height, BufferedImage.TYPE_INT_ARGB);

        //Scale image to the size you want
        AffineTransform at = new AffineTransform();
        at.scale(image_width / width, image_height / height);
        AffineTransformOp op = new AffineTransformOp(at, AffineTransformOp.TYPE_NEAREST_NEIGHBOR);
        finalImage = op.filter(identicon, finalImage);

        return finalImage;
	}
	
	public static Date normalizeDay(Date d) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(d);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}
	
	public static String iso8601Date(Date d) {
		return iso8601Date.format(d);
	}

}
