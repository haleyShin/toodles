package toodle.migration;

import toodle.migration.Operation.Direction;

public class Migration {
	private int version;
	private Operation up;
	private Operation down;
	public Migration(Operation o) {
		version = o.version;
		switch (o.direction) {
			case down: down = o; break;
			case up: up = o; break;
		}
	}
	
	public Operation getUp() {
		return up;
	}
	
	public Operation getDown() {
		return down;
	}

	public void setTheOther(Operation o) {
		if (version != o.version) {
			throw new RuntimeException("Expected version " + version + ", but got " + o.version);
		}
		switch (o.direction) {
			case down:
				if (down != null) {
					throw new RuntimeException(version + "_down is already set");
				}
				down = o; break; 
			case up: up = o;
				if (up != null) {
					throw new RuntimeException(version + "_up is already set");
				}
				break;
		}		
	}
	
	public Direction getMissing() {
		if (up == null) {
			return Direction.up;
		}
		if (down == null) {
			return Direction.down;
		}
		return null;
	}
}
