package toodle.migration;

public class Operation {
	public enum Direction { up, down }

	final public String id;
	final public int version;
	final public Direction direction;

	public Operation(String id) {
		this.id = id;
		int lodashIdx = id.indexOf('_');
		int minusIdx = id.indexOf('-');
		if (minusIdx < 0) {
			minusIdx = id.length();
		}
		version = Integer.parseInt(id.substring(0, lodashIdx));
		direction = Direction.valueOf(id.substring(lodashIdx + 1, minusIdx));
	}

	public String toString() {
		return "Migration(version="+version+",direction="+direction+")";
	}
	
}
