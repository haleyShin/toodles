package toodle.migration;

public class Column {
	private String columnName;
	private String dataType;
	private Integer dataLength;
	private Integer dataPrecision;
	private String nullable;

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public void setDataLength(Integer dataLength) {
		this.dataLength = dataLength;
	}
	public void setDataPrecision(Integer dataPrecision) {
		this.dataPrecision = dataPrecision;
	}

	
	public String getNullable() {
		return nullable;
	}
	public void setNullable(String nullable) {
		this.nullable = nullable;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getDataType() {
		return dataType;
	}
	public Integer getDataLength() {
		return dataLength;
	}
	public Integer getDataPrecision() {
		return dataPrecision;
	}
	
}
