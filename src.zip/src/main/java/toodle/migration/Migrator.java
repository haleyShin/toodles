package toodle.migration;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.dbcp.BasicDataSource;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import toodle.migration.Operation.Direction;

public class Migrator {
	@Autowired
	private BasicDataSource dataSource;
	
	@Autowired
	private SqlSessionTemplate sql;

	private String mapperPath;

	private int maxVersion = 0;
	private int targetVersion = 1;
	
	public void setMapperPath(String s) {
		mapperPath = s;
	}
	
	public void setTargetVersion(int i) {
		targetVersion = Math.max(0, i);
	}

	public int[] migrate() {
		
		Map<Integer, Migration> migrations = loadMigrations();
		if (maxVersion < targetVersion) {
			throw new RuntimeException("targetVersion exceeds maxVersion(" + maxVersion + ")");
		}

		try {
			int currentVersion = getCurrentVersion();
			if (targetVersion == currentVersion) {
				
			} else if (currentVersion < targetVersion) {
				for (int i = currentVersion + 1; i <= targetVersion; i++) {
					sql.update("sql.migration." + migrations.get(i).getUp().id);
				}
			} else if (currentVersion > targetVersion) {
				for (int i = currentVersion; i > targetVersion; i--) {
					sql.update("sql.migration." + migrations.get(i).getDown().id);
				}
			}
			sql.update("sql.migration.update", targetVersion);
			return new int[]{ currentVersion, targetVersion };
			
		} catch (SQLException e) {
			throw new RuntimeException("Failed to get current version", e);
		}
	}

	private int getCurrentVersion() throws SQLException {
		Connection conn = dataSource.getConnection();
		try {
			DatabaseMetaData meta = conn.getMetaData();
			ResultSet rs = meta.getTables(null, null, "TD_MIGRATION", null);
			try {
				if (rs.next()) {
					PreparedStatement ps = conn.prepareStatement("SELECT * FROM td_migration");
					ResultSet rs1 = ps.executeQuery();
					try {
						if (rs1.next()) {
							return rs1.getInt("version");
						} else {
							return 0;
						}
					} finally {
						rs.close();
					}
				} else {
					PreparedStatement ps1 = conn.prepareStatement("CREATE TABLE td_migration (version NUMBER(4))");
					try {
						ps1.execute();
					} finally {
						ps1.close();
					}
					PreparedStatement ps2 = conn.prepareStatement("INSERT INTO td_migration VALUES (0)");
					try {
						ps2.execute();
					} finally {
						ps2.close();
					}
					return 0;
				}
			} finally {
				rs.close();
			}
		} finally {
			try {
				conn.close(); 
			} catch (Exception e) {
				//
			}
		}
	}

	private Map<Integer, Migration> loadMigrations() {
		InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(mapperPath);
		if (inputStream == null) {
			throw new RuntimeException("Failed to open input stream: " + mapperPath);
		}
		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
		docBuilderFactory.setValidating(false);
		try {
			DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(inputStream);
			NodeList sqls = doc.getElementsByTagName("update");
			Map<Integer, Migration> migrations = new HashMap<Integer, Migration>();
			maxVersion = 0;
			for (int i = 0, l = sqls.getLength(); i < l; i++) {
				String id = sqls.item(i).getAttributes().getNamedItem("id").getNodeValue();
				try {
					Operation op = new Operation(id);
					if (migrations.containsKey(op.version)) {
						migrations.get(op.version).setTheOther(op);
					} else {
						migrations.put(op.version, new Migration(op));
					}
					maxVersion = Math.max(maxVersion, op.version);					
				} catch (RuntimeException e) {
					continue;
				}
			}
			for (int i = 1; i <= maxVersion; i++) {
				if (!migrations.containsKey(i)) {
					throw new RuntimeException("Migration version " + i + " is missing.");
				}
				Migration m = migrations.get(i);
				Direction missing = m.getMissing();
				if (missing != null) {
					throw new RuntimeException("Migration version " + i + " has no " + missing + ".");
				}
			}
			return migrations;
			
		} catch (ParserConfigurationException e) {
			throw new RuntimeException("Invalid XML parser configuration.", e);
		} catch (SAXException e) {
			throw new RuntimeException("Invalid XML", e);
		} catch (IOException e) {
			throw new RuntimeException("IO Exception", e);
		}
	}
}
