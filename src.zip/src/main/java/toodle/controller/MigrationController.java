package toodle.controller;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import toodle.migration.Migrator;
import toodle.util.Utils;

@Controller
public class MigrationController {
	
	@Autowired
	private SqlSessionTemplate sql;
	
	@Autowired
	private Migrator migrator;
	
	@RequestMapping(value="migration.do", method=RequestMethod.GET)
	public String index(ModelMap model) {
		model.put("result", migrator.migrate());
		return "migration";
	}
	
	@RequestMapping("tables.do")
	public String tables(ModelMap model) {
		List<String> tableNames = sql.selectList("sql.db.selectTableNames");
		Map<String, Object> columns = Utils.buildStrMap();
		for (String tableName : tableNames) {
			columns.put(tableName, sql.selectList("sql.db.selectColumns", tableName));
		}
		model.put("tableNames", tableNames);
		model.put("columns", columns);
		return "tables";
	}
}
