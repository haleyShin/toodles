package toodle.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import toodle.exception.APIException;

@ControllerAdvice
public class ControllerExceptionHandler {
	@ExceptionHandler({APIException.class})
	public ResponseEntity<Object> handleAPIException(APIException ex, HttpServletRequest req) {
		return new ResponseEntity<Object>(ex.getMessage(), new HttpHeaders(), ex.getStatus());
	}
}
