package toodle.controller;

import java.io.File;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import toodle.dao.AttachmentDAO;
import toodle.model.User;
import toodle.service.LoginService;

@Controller
public class IndexController {
	@Autowired
	private User currentUser;

	@Autowired
	private AttachmentDAO attachmentDAO;

	@Autowired
	private LoginService loginService;

	@RequestMapping("index.do")
	public String index(HttpServletRequest request) {
		try {
			User user = loginService.getAutoLoginUser(request, currentUser);
			if (user != null) {
				currentUser.merge(user);
				return "redirect:toodle.do";
			} else {
				return "index";
			}
		} catch (NullPointerException e) {
			return "index";
		}
	}

	@RequestMapping("toodle.do")
	public String toodle() {
		if (currentUser.isLoggedIn()) {
			return "toodle";
		} else {
			return "redirect:index.do";
		}
	}

	@RequestMapping("icons.do")
	public String icons() {
		return "icons";
	}

	@RequestMapping("/downloadAttachment.do")
	public ModelAndView download(
		HttpServletRequest req, HttpServletResponse response, @RequestParam("idx") String attachmentIdx
	) {
		String userIdxDown = attachmentDAO.selectUserstateDown(attachmentIdx, currentUser.getIdx());
		ModelAndView mav = new ModelAndView();
		if (userIdxDown != null) {
			File f = new File(req.getServletContext().getRealPath("WEB-INF/uploads"));
			mav = new ModelAndView("toodleDown");
			mav.addObject("downloadFile", new File(f, attachmentIdx));
			mav.addObject("filename", attachmentDAO.selectAttachmentName(attachmentIdx));
		} else {
			response.setStatus(404);
			throw new RuntimeException("권한이 없습니다.");
		}
		return mav;
	}
}
