package toodle.controller.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import toodle.dao.NoticeDAO;
import toodle.service.NoticeService;

@Controller
public class NoticeAPI extends APIController{
	
	@Autowired
	NoticeDAO noticeDAO;
	
	@Autowired
	NoticeService noticeService;
	
	@RequestMapping(method=RequestMethod.GET, value="/notices")
	public @ResponseBody Object notice(){
		return noticeDAO.selectLastNotice(currentUser.getIdx());
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/notices")
	public @ResponseBody Object updateNoticeSeen(@RequestParam (value="noticeIdx") String noticeIdx){
		noticeDAO.updateLastSeen(currentUser.getIdx(), noticeIdx);
		return noticeDAO.selectLastNotice(currentUser.getIdx());
	}
}
