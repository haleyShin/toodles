package toodle.controller.api;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import toodle.dao.UserDAO;
import toodle.model.User;
import toodle.service.LoginService;
import toodle.util.Str;

@Controller
public class UserAPI extends APIController {

	@Autowired
	private LoginService loginService;

	@Autowired
	private UserDAO userDAO;

	@RequestMapping(method = RequestMethod.GET, value = "/user/me")
	public @ResponseBody Object me() {
		return new User(currentUser);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/user/me")
	public @ResponseBody Object postMe(
		@RequestParam(value = "name", required = false) String name,
		@RequestParam(value = "password", required = false) String password, MultipartHttpServletRequest req
	) {
		User me = new User(currentUser);
		if (name != null) {
			me.setName(name);
			currentUser.setName(name);
		}
		if (password != null) {
			me.setPassword(password);
		}

		if (req.getFileNames() != null) {
			File uploadDirectory = new File(req.getServletContext().getRealPath("img/users"));
			if (!uploadDirectory.exists()) {
				uploadDirectory.mkdirs();
			}

			MultipartFile upload = req.getFile("photo");
			if (upload != null && !upload.isEmpty()) {
				String filename = me.getIdx() + Str.getSuffix(upload.getOriginalFilename());
				File uploadFile = new File(uploadDirectory, filename);
				try {
					upload.transferTo(uploadFile);
					me.setPhoto(filename);
					currentUser.setPhoto(filename);
				} catch (IllegalStateException e) {
					throw new RuntimeException(e);
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			}
		}

		currentUser.setUpdatedAt(new Date());
		me.setUpdatedAt(new Date());
		userDAO.update(me);
		return me;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/user/login")
	public @ResponseBody Object login(
		@RequestParam(value = "email", required = true) String email,
		@RequestParam(value = "password", required = true) String password,
		@RequestParam(value = "autoLogin", required = false) boolean autoLogin, HttpServletResponse response,
		HttpSession session
	) {
		loginService.authenticate(email, password, currentUser);
		if (currentUser.isLoggedIn()) {
			if (autoLogin) {
				loginService.issueAutoLoginToken(response, currentUser);
			}
		}
		return new User(currentUser);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/user/logout")
	public @ResponseBody Object logout(HttpServletRequest req, HttpServletResponse res, HttpSession session) {
		if (currentUser.isLoggedIn()) {
			loginService.deleteAutoLoginToken(req, res, currentUser);
			session.invalidate();
			currentUser.clear();
			return true;
		} else {
			return false;
		}
	}

	@RequestMapping(method = RequestMethod.GET, value = "/contacts")
	public @ResponseBody Object usersContacts(HttpServletResponse response) {
		return userDAO.selectUserContacts(currentUser.getIdx());
	}

	@RequestMapping(method = RequestMethod.GET, value = "/user")
	public @ResponseBody Object getUserEmail(@RequestParam("email") String email) {
		return userDAO.selectByUserEmail(email);
	}

}
