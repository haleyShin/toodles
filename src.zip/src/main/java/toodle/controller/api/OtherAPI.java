package toodle.controller.api;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class OtherAPI extends APIController {
	
	@RequestMapping("greet")
	public @ResponseBody Object greet(
		@RequestParam(value="name", required=false) String name
	) {
		Map<String, String> map = new HashMap<String, String>();
		if (name == null) {
			map.put("message", "hello world");
		} else {
			map.put("message", "hello " + name + "!");
		}
		return map;
	}
}
