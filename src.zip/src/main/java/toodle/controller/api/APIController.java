package toodle.controller.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import toodle.model.User;

@Controller
@RequestMapping("/api")
abstract public class APIController {

	@Autowired
	protected User currentUser;

}
