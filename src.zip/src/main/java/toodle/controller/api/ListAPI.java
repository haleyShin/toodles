package toodle.controller.api;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;
import static org.springframework.web.bind.annotation.RequestMethod.DELETE;
import static org.springframework.web.bind.annotation.RequestMethod.PUT;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import toodle.dao.TaskListDAO;
import toodle.model.ListSection;
import toodle.request.ListRequest;
import toodle.service.TaskListService;


@Controller
public class ListAPI extends APIController {

	@Autowired
	private TaskListService taskListService;

	@Autowired
	private TaskListDAO taskListDAO;

	@RequestMapping(method=GET, value="/list/myLists")
	public @ResponseBody Object myLists(){
		return taskListDAO.myLists(currentUser.getIdx());
	}

	@RequestMapping(method=GET, value="/list/invitations")
	public @ResponseBody Object invitations(){
		return taskListDAO.selectInvitations(currentUser.getIdx());
	}

	@RequestMapping(method=GET, value="/list/{listIdx}/tasks")
	public @ResponseBody Object listInTask(@PathVariable("listIdx") String listIdx) {
		if (listIdx.equals("inbox")) {
			listIdx = currentUser.getInboxIdx();
		}
		return ListSection.indexByCompleted(taskListDAO.selectTasksByIdx(listIdx, currentUser.getIdx()));
	} 

	@RequestMapping(method=GET, value="list/{listIdx}")
	public @ResponseBody Object getList(@PathVariable(value="listIdx", required=true) String listIdx) {
		return taskListDAO.selectByIdx(listIdx, currentUser.getIdx());
	}

	@RequestMapping(method=POST, value={"list", "list/{listIdx}"})
	public @ResponseBody Object postList(
		@PathVariable(value="listIdx", required=false) String listIdx,
		ListRequest listRequest
	) {
		return taskListService.save(listIdx, listRequest, false);
	}

	@RequestMapping(method=PUT, value="/list/{listIdx}")
	public @ResponseBody Object putList(
			@PathVariable(value="listIdx", required=true) String listIdx,
			ListRequest listRequest
	) {
		return taskListService.save(listIdx, listRequest, true);
	}

	@RequestMapping(method=DELETE, value="/list/{listIdx}")
	public @ResponseBody Object deleteList(@PathVariable(value="listIdx") String listIdx, HttpServletResponse response){
		taskListService.delete(listIdx);
		return true;
	}

	@RequestMapping(method=POST, value="/sortLists")
	public @ResponseBody Object sortList(
		@RequestParam("idxes") String idxes[]
	) {
		taskListService.updateSorting(idxes);
		return true;
	}

	@RequestMapping(method=GET, value="/list/{listIdx}/users" )
	public @ResponseBody Object selectUserState(
		@RequestParam(value="states", required=false) String states[],
		@PathVariable("listIdx")String listIdx
	) {
		if (states == null) {
			states = new String[]{"owner", "member", "invited"};
		}
		return taskListDAO.selectUsersByState(states, listIdx);
	}

	@RequestMapping(method=GET, value="/list/{listIdx}/notCompletedCount")
	public @ResponseBody Object notCompletedCount(@PathVariable("listIdx")String listIdx){
		return taskListDAO.countNotCompleted(listIdx, currentUser.getIdx());
	}

	@RequestMapping(method=GET, value="/list/{listIdx}/taskOrder")
	public @ResponseBody Object selectTaskOrderByTaskIdx(@PathVariable("listIdx") String listIdx){
		return taskListDAO.selectTaskOrderByIdx(listIdx, currentUser.getIdx());
	}
	 
	@RequestMapping(method=GET, value="/list/deleted")
	public @ResponseBody Object deletedLists(){
		return taskListDAO.deletedLists(currentUser.getIdx());
	}
	
	@RequestMapping(method=POST, value="/list/deleted/{listIdx}")
	public @ResponseBody Object restoreList(@PathVariable("listIdx") String listIdx){			
		taskListDAO.restoreList(listIdx, currentUser.getIdx());
		return true;
	}
	
	@RequestMapping(method=POST, value="/list/totallyDelete/{listIdx}")
	public @ResponseBody Object totallyDelete(@PathVariable("listIdx") String listIdx){
		taskListDAO.totallyDeleteList(listIdx, currentUser.getIdx());
		return true;
	}
}
