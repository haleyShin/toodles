package toodle.controller.api;

import static org.springframework.web.bind.annotation.RequestMethod.DELETE;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;
import static org.springframework.web.bind.annotation.RequestMethod.PUT;
import static toodle.util.Str.isEmpty;
import static toodle.util.Str.strIn;
import static toodle.util.Utils.iso8601Date;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileUploadBase.SizeLimitExceededException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import net.sf.jmimemagic.Magic;
import net.sf.jmimemagic.MagicException;
import net.sf.jmimemagic.MagicMatch;
import net.sf.jmimemagic.MagicMatchNotFoundException;
import net.sf.jmimemagic.MagicParseException;
import toodle.dao.AttachmentDAO;
import toodle.dao.CommentDAO;
import toodle.dao.SubtaskDAO;
import toodle.dao.TaskDAO;
import toodle.dao.TaskListDAO;
import toodle.dao.UserDAO;
import toodle.exception.APIException;
import toodle.model.Attachment;
import toodle.model.Comment;
import toodle.model.EntityCount;
import toodle.model.ListSection;
import toodle.model.Reminder;
import toodle.model.Subtask;
import toodle.model.Task;
import toodle.request.TaskRequest;
import toodle.service.NoticeService;
import toodle.service.SyncMessagingService;
import toodle.service.SyncType;
import toodle.service.TaskService;

@Controller
public class TaskAPI extends APIController {

	@Autowired
	private TaskListDAO taskListDAO;
	
	@Autowired
	private TaskDAO taskDAO;
	
	@Autowired
	private AttachmentDAO attachmentDAO;
	
	@Autowired
	private CommentDAO commentDAO;

	@Autowired
	private UserDAO userDAO;
	
	@Autowired
	private SubtaskDAO subtaskDAO;
	
	@Autowired
	private TaskService taskService;
	
	@Autowired
	private NoticeService noticeService;
	
	@Autowired
	private SyncMessagingService syncMessagingService;

	@RequestMapping(method=GET, value="/task/forCalendar")
	public @ResponseBody Object getTasksCountbyCalendarDate(
		@RequestParam("month") int month,
		@RequestParam("year") int year
	) {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month - 1);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		Date dateFrom = cal.getTime();
		
		cal.add(Calendar.MONTH, 1);
		Date dateTo = cal.getTime();

		return taskDAO.selectDailyTaskCount(currentUser.getIdx(), iso8601Date(dateFrom), iso8601Date(dateTo));
	}
	
	@RequestMapping(method=GET, value="/task/{taskIdx}")
	public @ResponseBody Object task(@PathVariable("taskIdx") String taskIdx) {
		return taskService.getOrFail(taskIdx);
	}

	@RequestMapping(method=POST, value={"/task", "/task/{taskIdx}"})
	public @ResponseBody Object postTask(
		@PathVariable(value="taskIdx", required=false) String taskIdx,
		TaskRequest params
	) {
		return taskService.save(taskIdx, params, false);
	}

	@RequestMapping(method=PUT, value={"/task", "/task/{taskIdx}"})
	public @ResponseBody Object putTask(
		@PathVariable(value="taskIdx", required=false) String taskIdx,
		TaskRequest params
	){
		return taskService.save(taskIdx, params, true);			
	}
	
	@RequestMapping(method=PUT, value="/task/{taskIdxes}/mput")
	public @ResponseBody Object mputTask(
		@PathVariable("taskIdxes") String taskIdxes,
		TaskRequest params
	) {
		return taskService.save(taskIdxes.split(","), params, true);		
	}
	
	@RequestMapping(method=POST, value="/task/{taskIdxes}/clone")
	public @ResponseBody Object cloneTasks(
		@PathVariable("taskIdxes") String taskIdxes,
		@RequestParam Map<String, String> changes
	) {
		return taskService.cloneTasks(taskIdxes.split(","), changes);
	}

	@RequestMapping(method=DELETE, value="/task/{taskIdx}")
	public @ResponseBody Object deleteTask(@PathVariable("taskIdx") String taskIdx) {
		return taskService.delete(taskIdx);
	}

	@RequestMapping(method=POST, value="/task/{taskIdx}/comment")
	public @ResponseBody Object comment(
		@PathVariable("taskIdx") String taskIdx,
		@RequestParam("content") String content
	){
		taskService.getOrFail(taskIdx);
		Comment comment = new Comment();
		comment.setTaskIdx(taskIdx);
		comment.setUserIdx(currentUser.getIdx());
		comment.setUserName(currentUser.getName());
		comment.setUserEmail(currentUser.getEmail());
		comment.setUserPhoto(currentUser.getPhoto());
		comment.setContent(content);
		commentDAO.insert(comment);
		noticeService.insertNoticeComment(taskIdx, comment.getIdx());
		syncMessagingService.notifyTaskUsers(taskIdx, SyncType.comment, "i" + comment.getIdx());
		return comment;
	}

	@RequestMapping(method=GET, value="/task/{taskIdx}/comments")
	public @ResponseBody Object selectComment(@PathVariable("taskIdx") String taskIdx) {
		taskService.getOrFail(taskIdx);
		return commentDAO.selectByTaskIdx(taskIdx,currentUser.getIdx());
	}
	
	@RequestMapping(method=GET, value="/task/{taskIdx}/comment/{commentIdx}")
	public @ResponseBody Object getComment(
		@PathVariable("taskIdx") String taskIdx,
		@PathVariable("commentIdx") String commentIdx
	) {
		taskService.getOrFail(taskIdx);
		Comment comment = commentDAO.selectByIdx(commentIdx);
		if (comment != null) {
			return comment;
		} else {
			throw new APIException(HttpStatus.NOT_FOUND);
		}
	}

	@RequestMapping(method=DELETE, value="/task/{taskIdx}/comment/{commentIdx}")
	public @ResponseBody Object deleteComment(
		@PathVariable("taskIdx") String taskIdx,
		@PathVariable("commentIdx") String commentIdx
	) {
		taskService.getOrFail(taskIdx);
		boolean success = commentDAO.delete(commentIdx, currentUser.getIdx());
		if (success) {
			syncMessagingService.notifyTaskUsers(taskIdx, SyncType.comment, "d" + commentIdx);			
		}
		return success;
	}

	@RequestMapping(method=GET, value="/task/{taskIdx}/assignees")
	public @ResponseBody Object getAssignees(@PathVariable("taskIdx") String taskIdx) {
		taskService.getOrFail(taskIdx);
		return userDAO.selectByTaskIdx(taskIdx);
	}

	@RequestMapping(method=POST, value="/task/{taskIdx}/assignees")
	public @ResponseBody Object postAssignees(
		@PathVariable("taskIdx") String taskIdx,
		@RequestParam(value="userIdxes", required=false, defaultValue="") String userIdxes[]
	) {
		Task task = taskService.getOrFail(taskIdx);

		for (String userIdx : userIdxes) {
			if (strIn(taskListDAO.selectUserState(task.getListIdx(), userIdx), null, "invited")) {
				throw new APIException(HttpStatus.BAD_REQUEST, userIdx + " is not a member or owner in this list");
			}
		}

		taskDAO.deleteAssignees(taskIdx);
		taskDAO.addAssignees(taskIdx, userIdxes);
		noticeService.insertNoticeAssign(taskIdx, userIdxes);
		syncMessagingService.notifyTaskUsers(taskIdx, SyncType.assign);
		return userDAO.selectByTaskIdx(taskIdx);
	}

	@RequestMapping(method=GET, value="/task/{taskIdx}/subtasks")
	public @ResponseBody Object getSubtasks(@PathVariable("taskIdx") String taskIdx){
		taskService.getOrFail(taskIdx);
		return subtaskDAO.selectByTaskIdx(taskIdx);
	}

	@RequestMapping(method=POST, value="/task/{taskIdx}/subtask")
	public @ResponseBody Object postSubtask(
			@PathVariable("taskIdx") String taskIdx,
			@RequestParam(value="name", required=true) String name,
			@RequestParam(value="completed", required=false) boolean isCompleted
	) {
		taskService.getOrFail(taskIdx);
		Subtask subtask = new Subtask();
		subtask.setName(name);
		subtask.setCompleted(isCompleted);
		subtask.setTaskIdx(taskIdx);
		subtask.setOrd(0);
		subtaskDAO.insert(subtask);
		noticeService.insertNoticeSubtaskAdd(taskIdx);
		syncMessagingService.notifyTaskUsers(taskIdx, SyncType.subtask);
		return subtask;
	}

	@RequestMapping(method=DELETE, value="/task/{taskIdx}/subtask/{subtaskIdx}")
	public @ResponseBody Object deleteSubtask(@PathVariable("taskIdx") String taskIdx, @PathVariable("subtaskIdx") String subtaskIdx){
		taskService.getOrFail(taskIdx);
		subtaskDAO.delete(subtaskIdx);
		syncMessagingService.notifyTaskUsers(taskIdx, SyncType.subtask);
		return true;
	}

	@RequestMapping(method=PUT, value="/task/{taskIdx}/subtask/{subtaskIdx}")
	public @ResponseBody Object putSubtask(@PathVariable("taskIdx") String taskIdx,
			@PathVariable("subtaskIdx") String subtaskIdx,
			@RequestParam(value="completed", required=false) Boolean isCompleted,
			@RequestParam(value="name", required=false) String name){
		taskService.getOrFail(taskIdx);
		Subtask subtask = subtaskDAO.select(subtaskIdx);
		if (subtask == null) {
			throw new APIException(HttpStatus.NOT_FOUND);
		}
		if (isCompleted != null) {
			subtask.setCompleted(isCompleted);
		}
		if (name != null) {
			subtask.setName(name);
		}
		subtaskDAO.update(subtask);
		syncMessagingService.notifyTaskUsers(taskIdx, SyncType.subtask);
		return subtask;
	}

	@RequestMapping(method=POST, value="/task/{taskIdx}/sortSubtasks")
	public @ResponseBody Object sortSubtasks(
		@PathVariable("taskIdx") String taskIdx,
		@RequestParam(value="idxes", required=false) String[] idxes
	) {
		taskService.getOrFail(taskIdx);
		taskDAO.sortSubtasks(taskIdx, idxes);
		return true;
	}

	@RequestMapping(method=POST,value="/task/{taskIdx}/attachment")
	public @ResponseBody Object insertAttachment(
			MultipartHttpServletRequest req, HttpServletResponse response,
			@PathVariable("taskIdx") String taskIdx
			) throws IllegalStateException, IOException, SizeLimitExceededException, MaxUploadSizeExceededException{
		Task task=taskDAO.selectByIdxForUser(taskIdx, currentUser.getIdx());
		Attachment attachment=new Attachment();
		if(task == null){
			response.setStatus(404);
			return false;
		}else{
			File uploadDirectory = new File(req.getServletContext().getRealPath("WEB-INF/uploads"));
			if (!uploadDirectory.exists()) {
				uploadDirectory.mkdirs();
			}
			
			MultipartFile upload = req.getFile("attachment");
			if(upload.getSize() > 10485760){
				response.setStatus(400);
				String msg = "업로드 용량제한을 초과했습니다.";
				return msg;
			}
			String originalName = upload.getOriginalFilename();
			String mimetype;
			try {
				MagicMatch match = Magic.getMagicMatch(upload.getBytes());
				
				if (match == null) {
					mimetype = "application/octet-stream";
				} else {
					mimetype = match.getMimeType();
				}
			}catch(MagicMatchNotFoundException me) {
				mimetype = "application/octet-stream";
			} catch (MagicParseException me) {
				mimetype = "application/octet-stream";
			} catch (MagicException e) {
				mimetype = "application/octet-stream";
			}

			attachment.setTaskIdx(taskIdx);
			attachment.setMimetype(mimetype);
			attachment.setName(originalName);
			attachment.setPath("");
			attachmentDAO.insertAttachment(attachment);
			
			File uploadFile = new File(uploadDirectory, attachment.getIdx());
			upload.transferTo(uploadFile);
			noticeService.insertNoticeAttachment(taskIdx);

			syncMessagingService.notifyTaskUsers(taskIdx, SyncType.attachment);

			return attachment;
		}
	}
	
	@RequestMapping(method=GET,value="/task/{taskIdx}/attachments")
	public @ResponseBody Object selectAllAttachment(
			@PathVariable("taskIdx") String taskIdx,
			HttpServletResponse response
			){
		List<Attachment> attachmentList=attachmentDAO.selectByTaskIdx(taskIdx);
		if(attachmentList == null){
			response.setStatus(404);
			return false;
		}else{
			return attachmentList;
		}
	}
	
	@RequestMapping(method=DELETE,value="/task/{taskIdx}/attachment/{attachmentIdx}")
	public @ResponseBody Object deleteAttachment(
		@PathVariable("attachmentIdx") String attachmentIdx,
		@PathVariable("taskIdx") String taskIdx,
		HttpServletResponse response
	) {
		taskService.getOrFail(taskIdx);
		attachmentDAO.deleteByAttachmentIdx(attachmentIdx);
		syncMessagingService.notifyTaskUsers(taskIdx, SyncType.attachment);
		return true;
	}

	@RequestMapping(method=GET,value="/task/search")
	public @ResponseBody Object searchByKeywords(
		@RequestParam("keyword") String keyword,
		@RequestParam("fields") String[] fields
	){
		List<Task> tasks = taskDAO.searchByKeywords(currentUser.getIdx(), fields, keyword);
		return ListSection.indexByListIdx(tasks);
	}
	
	@RequestMapping(method=GET,value="task/importants")
	public @ResponseBody Object isImportant(){
		 List<Task> tasks = taskDAO.selectImportantTasks(currentUser.getIdx());
		 return ListSection.indexByListIdx(tasks);
	}	

	@RequestMapping(method=GET,value="/task/assignments")
	public @ResponseBody Object assignments(HttpServletResponse response){
		List<Task> tasks = taskDAO.assignmentsList(currentUser.getIdx());
		return ListSection.indexByListIdx(tasks);
	}
	 
	@RequestMapping(method=GET, value="/task/byDate")
	public @ResponseBody Object byDate(
		@RequestParam(value="dateFrom", required=false) String dateFrom,
		@RequestParam(value="dateTo", required=false) String dateTo,
		@RequestParam("group") String group
	) {
		if (isEmpty(dateFrom) && isEmpty(dateTo)) {
			throw new APIException(HttpStatus.BAD_REQUEST, "date range not specified");
		}

		List<Task> tasks = taskDAO.selectByDate(dateFrom, dateTo,currentUser.getIdx());
		if (group.equals("list")) {
			return ListSection.indexByListIdx(tasks);
		}
		if (group.equals("daily")) {
			return ListSection.indexByDay(tasks);
		}
		throw new APIException(HttpStatus.BAD_REQUEST, "unknown grouping: " + group);
	}

	@RequestMapping(method=GET, value="/hashtags")
	public @ResponseBody Object hashtags() {
		return taskDAO.selectHashtags(currentUser.getIdx());
	}
	
	@RequestMapping(method=POST, value="/sortTasks")
	public @ResponseBody Object updateTaskOrder(
		@RequestParam(value="idxes", required=false) String idxes[]
	) {
		taskDAO.sort(idxes, currentUser.getIdx());
		return true;
	}

	@RequestMapping(method={GET, POST}, value="/task/countEntities")
	public @ResponseBody Map<String, EntityCount> countEntities(@RequestParam("idxes") String idxes[]) {
		return taskDAO.countEntities(idxes);
	}
	
	@RequestMapping(method={GET}, value="/task/staleReminders")
	public @ResponseBody List<Reminder> staleReminders() {
		return taskDAO.selectStaleReminders(currentUser.getIdx());
	}

	@RequestMapping(method=GET,value="task/count")
	public @ResponseBody Object count(
		@RequestParam(value="queries", required=false) String[] queries
	) {
		if (queries == null) {
			queries = new String[]{"importants", "assignments"};
		}

		Map<String, Integer> counts = new HashMap<String, Integer>();
		for (String query : queries) {
			if (query.equals("importants")) {
				counts.put("importants", taskDAO.countImportantTasks(currentUser.getIdx()));
			} else if (query.equals("assignments")) {
				counts.put("assignments", taskDAO.countAssignments(currentUser.getIdx()));
			}
		}
		return counts;
	}
}
