package toodle.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.socket.TextMessage;

import toodle.message.HelloMessage;
import toodle.model.User;

@Controller
public class MessageController {
	
	@Autowired
	private User currentUser;
	
	@Autowired
	private SimpMessagingTemplate msg;

	@MessageMapping("/greeting")
	public void greeting(SimpMessageHeaderAccessor headerAccessor, HelloMessage message) {
		User currentUser = (User) headerAccessor.getSessionAttributes().get("scopedTarget.currentUser");
		msg.convertAndSend("/topic/greeting/" + message.getIdx(), currentUser.getName() + ": " + message.getGreeting());
	}
	
	@MessageMapping("/echo")
	public String echo(TextMessage message) {
		return "ECHO: " + message.getPayload();
	}

	@RequestMapping("message/test.do")
	public String websocketTest(ModelMap model) {
		model.put("user", currentUser);
		return "message/test";
	}

}
