package toodle.controller;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;
import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import toodle.dao.TaskListDAO;
import toodle.dao.UserDAO;
import toodle.model.TaskList;
import toodle.model.User;
import toodle.service.LoginService;
import toodle.service.SmtpMailSender;
import toodle.util.NewPassword;
import toodle.util.Str;
import toodle.util.Utils;

@Controller
public class LoginController {
	
	@Autowired
	private UserDAO userDao;

	@Autowired
	private User currentUser;

	@Autowired
	private LoginService loginService;
	
	@Autowired
	private TaskListDAO taskListDAO;

	@Autowired 
	private SmtpMailSender smtpMailSender;
	
	@Autowired
	private NewPassword newPassword;
	
	@RequestMapping(method=RequestMethod.GET, value={"/joinForm.do"})
	public String UserJoinForm(){
		String mav = "User/JoinForm";
		return mav;
	}

	@RequestMapping(method=RequestMethod.POST, value={"/emailAuth.do"})
	public ModelAndView UserInsert(User dto,@RequestParam("email") String email) throws MessagingException{
		
		
		String authNum = ""+ Utils.RandomNum();
		String subject ="Toodle 인증번호 확인";
		String body="인증번호 :"+ authNum;
		
		smtpMailSender.send(email, subject, body);
		
		return null;
	}


	@RequestMapping(method=RequestMethod.POST, value={"/joinForm.do"})
	public ModelAndView UserInsert(User dto,@RequestParam("email") String email, 
			@RequestParam("password") String password, HttpServletRequest req,
			@RequestParam("name") String name){
		//User email duplication check
		ModelAndView mav = new ModelAndView();
		User user = userDao.selectByEmail(email);
		String regex = "[a-zA-Z0-9]+[._a-zA-Z0-9!#$%&'*+-/=?^_`{|}~]*[a-zA-Z]*@[a-zA-Z0-9]{2,8}.[a-zA-Z.]{2,6}"; 
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(email);
		if(matcher.matches()){
			mav.addObject("msg", "Valid Email Address");
			mav.setViewName("User/userMsg");
			}else{
				mav.addObject("msg", "올바른 메일 형식이 아닙니다.");
				mav.setViewName("User/joinMsg");
				return mav;	
		}
		if(password.length()< 8 || password.length() > 20){
			mav.addObject("msg", "8자이상 ~ 20자사이로 입력해주세요");
			mav.setViewName("User/joinMsg");
			return mav;
		}
		if(user==null){
			userDao.insert(dto);
			File uploadDirectory = new File(req.getServletContext().getRealPath("img/users"));
			if (!uploadDirectory.exists()) {
				uploadDirectory.mkdirs();
			}
			File file = new File(uploadDirectory, dto.getIdx() + ".png");
			BufferedImage bi =  Utils.generateIdenticons(email, 100, 100);
			try {
				System.out.println(bi);
				System.out.println(file);
				ImageIO.write(bi, "png", file);
			} catch (IOException e) {
				e.printStackTrace();
			}
			dto.setPhoto(dto.getIdx() + ".png");
			
			TaskList taskList = new TaskList();
			taskList.setName("inbox");
			taskList.setUserIdx(dto.getIdx());
			taskList.setUserState("owner");
			taskList.setOrd(0);
			taskListDAO.insert(taskList);
			taskListDAO.insertUser(taskList);
			
			dto.setInboxIdx(taskList.getIdx());
			userDao.update(dto);

			mav.addObject("msg", "Congrat! Now you are a Member");
			mav.setViewName("User/userMsg");
		}else{
			String msg ="same Email exist";
			mav.addObject("msg",msg);
			mav.setViewName("User/joinMsg");

		}
		return mav;
	}

	@RequestMapping(method=RequestMethod.GET, value="/loginForm.do")
	public String userLoginForm(){
		String result ="User/loginForm";
		return result;
	}

	@RequestMapping(method=RequestMethod.POST, value="/login.do")
	public String userLogin(
			@RequestParam(value="rememberLogin", required=false) String rememberLogin,
			@RequestParam("email") String email, 
			@RequestParam("password") String password,
			HttpServletResponse response,
			ModelMap model
	) {
		loginService.authenticate(email, password, currentUser);
		if (currentUser.isLoggedIn()) {
			if (Str.isNotEmpty(rememberLogin)) {
				loginService.issueAutoLoginToken(response, currentUser);
			}			
			return "redirect:toodle.do";
		} else {
			model.put("msg", "이메일 또는 비밀번호가 일치하지 않습니다.");
			return "User/userMsg";
		}
	}

	@RequestMapping("/logout.do")
	public String logout(
		HttpServletRequest req,
		HttpServletResponse res,
		HttpSession session
	){
		loginService.deleteAutoLoginToken(req, res, currentUser);
		session.invalidate();
		currentUser.clear();
		return "redirect:index.do";
	}
	
	@RequestMapping("/forgetpasswordForm.do")
	public String forgetpasswordForm(){
		return "User/forgetpasswordForm";
	}
	
	@RequestMapping("/forgetpassword.do")
	public String forgetpassword(
			@RequestParam("email") String email){
		User user=userDao.selectByUserEmail(email);
		String newpassword=newPassword.newPassword();
		System.out.println("pwd: "+newpassword);
		userDao.updatePassword(email, newpassword);
		String to=user.getEmail();
		String subject=user.getName()+"님의 임시 비밀번호입니다.";
		String body=user.getName()+"님의 임시 비밀번호는 "+newpassword+"입니다. \n로그인 후 비밀번호를 변경해주세요.";
		body = body.replaceAll("\\n", "<br>");
		try {
			smtpMailSender.send(to, subject, body);
		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
		return "redirect:index.do";
	}
}
