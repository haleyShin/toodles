package toodle.model;

import static toodle.util.Str.randomString;

import java.util.Date;
import java.util.List;

import javax.servlet.http.Cookie;

import org.springframework.security.crypto.bcrypt.BCrypt;

public class AutoLoginEntry {
	final private static int SELECTOR_LENGTH = 16;
	final private static int TOKEN_LENGTH = 32;
	private String selector;
	private String token;
	private String tokenHash;
	private String userIdx;
	private Date lastLogin;

	public static AutoLoginEntry generate(String userIdx) {
		AutoLoginEntry instance = new AutoLoginEntry();
		instance.selector = randomString(SELECTOR_LENGTH);
		instance.token = randomString(TOKEN_LENGTH);
		instance.tokenHash = BCrypt.hashpw(instance.token, BCrypt.gensalt());
		instance.userIdx = userIdx;
		return instance;
	}

	public AutoLoginEntry() {

	}

	public AutoLoginEntry(Cookie cookie) {
		String value = cookie.getValue();
		try {
			selector = value.substring(0, SELECTOR_LENGTH);
			token = value.substring(SELECTOR_LENGTH);			
		} catch (StringIndexOutOfBoundsException e) {
			// pass
		}
	}
	
	public AutoLoginEntry(Cookie cookie, String userIdx) {
		this(cookie);
		this.userIdx = userIdx;
	}

	public Cookie makeCookie(String name) {
		Cookie c = new Cookie(name, selector + token);
		c.setMaxAge(60 * 60 * 24 * 2);
		return c;
	}
	
	public AutoLoginEntry check(List<AutoLoginEntry> entries) {
		if (token == null || entries == null) {
			return null;
		}
		int matchCount = 0;
		AutoLoginEntry match = null;
		for (AutoLoginEntry entry : entries) {
			if (BCrypt.checkpw(token, entry.tokenHash)) {
				match = entry;
				matchCount++;
			}
		}
		if (matchCount == 1) {
			userIdx = match.userIdx;
			return match;
		} else {
			return null;
		}
	}

	public String getSelector() {
		return selector;
	}

	public boolean hasValidSelector() {
		return (selector != null && selector.length() == SELECTOR_LENGTH);
	}

	public String getTokenHash() {
		return tokenHash;
	}
	public String getUserIdx() {
		return userIdx;
	}
	public void setLastLogin(Date d) {
		lastLogin = d;
	}
	public Date getLastLogin(Date d) {
		return lastLogin;
	}
}
