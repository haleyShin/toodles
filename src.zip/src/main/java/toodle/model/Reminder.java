package toodle.model;

public class Reminder {
	private String userIdx;
	private String taskIdx;
	private String listIdx;
	private String email;
	private String taskName;
	public String getUserIdx() {
		return userIdx;
	}
	public void setUserIdx(String userIdx) {
		this.userIdx = userIdx;
	}
	public String getTaskIdx() {
		return taskIdx;
	}
	public void setTaskIdx(String taskIdx) {
		this.taskIdx = taskIdx;
	}
	public String getListIdx() {
		return listIdx;
	}
	public void setListIdx(String listIdx) {
		this.listIdx = listIdx;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
}
