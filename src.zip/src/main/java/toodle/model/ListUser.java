package toodle.model;

public class ListUser extends User {
	private String userState;

	public String getUserState() {
		return userState;
	}

	public void setUserState(String userState) {
		this.userState = userState;
	}
	
}
