package toodle.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class User {
	private String idx;
	private String email;
	private String name;
	private String inboxIdx;
	private String lastNoticeIdx;
	private Date updatedAt;
	private String settings;

	@JsonIgnore
	private String password;
	private String photo;
	
	public User() {
		
	}
	
	public User(User user) {
		merge(user);
	}
	public String getLastNoticeIdx() {
		return lastNoticeIdx;
	}
	
	public void setLastNoticeIdx(String lastNoticeIdx) {
		this.lastNoticeIdx = lastNoticeIdx;
	}
	
	public User(String email, String password) {
		super();
		this.email = email;
		this.password = password;
	}
	
	public User(String idx, String email, String name, String password) {
		this.idx = idx;
		this.email = email;
		this.name = name;
		this.password = password;
	}

	public User(String idx, String email, String name, String password, String photo) {
		this.idx = idx;
		this.email = email;
		this.name = name;
		this.password = password;
		this.photo = photo;
	}
	
	public String getIdx() {
		return idx;
	}
	public void setIdx(String idx) {
		this.idx = idx;
	}

	public boolean isLoggedIn() {
		return idx != null;
	}

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	
	public String getInboxIdx() {
		return inboxIdx;
	}

	public void setInboxIdx(String inboxIdx) {
		this.inboxIdx = inboxIdx;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	
	public String getSettings() {
		return settings;
	}

	public void setSettings(String settings) {
		this.settings = settings;
	}

	public void merge(User user) {
		idx = user.getIdx();
		email = user.getEmail();
		name = user.getName();
		inboxIdx = user.getInboxIdx();
		password = user.getPassword();
		photo = user.getPhoto();
		lastNoticeIdx = user.getLastNoticeIdx();
		updatedAt = user.getUpdatedAt();
		settings = user.getSettings();
	}
	public void clear() {
		merge(new User());
	}
	
}
