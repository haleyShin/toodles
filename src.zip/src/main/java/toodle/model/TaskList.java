package toodle.model;

import static toodle.util.Str.strEquals;

public class TaskList {

	private String idx;
	private String name;
	private String userIdx;
	private String userState;
	private String folder;
	private int ord;
	private int version = 0;
	private int userCount;

	public TaskList() {
		
	}

	public TaskList(TaskList l) {
		idx = l.idx;
		name = l.name;
		userIdx = l.userIdx;
		userState = l.userState;
		folder = l.folder;
		ord = l.ord;
		version = l.version;
		userCount = l.userCount;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj instanceof TaskList) {
			TaskList l = (TaskList) obj;
			if (!strEquals(name, l.name)) {
				return false;
			}
			if (!strEquals(folder, l.folder)) {
				return false;
			}
			return true;

		} else {
			return false;
		}
	}

	public int getUserCount() {
		return userCount;
	}
	public void setUserCount(int userCount) {
		this.userCount = userCount;
	}
	public String getIdx() {
		return idx;
	}
	public void setIdx(String idx) {
		this.idx = idx;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUserIdx() {
		return userIdx;
	}
	public void setUserIdx(String userIdx) {
		this.userIdx = userIdx;
	}
	public String getUserState() {
		return userState;
	}
	public void setUserState(String userState) {
		this.userState = userState;
	}
	public String getFolder() {
		return folder;
	}
	public void setFolder(String folder) {
		this.folder = folder;
	}
	public int getOrd() {
		return ord;
	}
	public void setOrd(int ord) {
		this.ord = ord;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}


}
