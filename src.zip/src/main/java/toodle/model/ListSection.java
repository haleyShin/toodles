package toodle.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import toodle.util.Utils;

public class ListSection {
	final private Type type;
	final private Object arg;
	private List<Task> tasks;
	enum Type {
		completed,
		list,
		day,
		week,
		montth
	}

	public static ListSection[] indexByDay(List<Task> tasks) {
		int nextIndex = 0;
		Map<Date, Integer> indices = new HashMap<Date, Integer>();
		List<ListSection> sections = new ArrayList<ListSection>();
		for (Task task : tasks) {
			Date day = Utils.normalizeDay(task.getDueDatetime());
			Integer index = indices.get(day);
			if (index == null) {
				index = nextIndex++;
				sections.add(new ListSection(Type.day, day));
				indices.put(day, index);
			}
			ListSection section = sections.get(index);
			section.addTask(task);
		}
		return sections.toArray(new ListSection[sections.size()]);
	}

	public static ListSection[] indexByListIdx(List<Task> tasks) {
		int nextIndex = 0;
		Map<String, Integer> indices = new HashMap<String, Integer>();
		List<ListSection> sections = new ArrayList<ListSection>();
		for (Task task : tasks) {
			String listIdx = task.getListIdx();
			Integer index = indices.get(listIdx);
			if (index == null) {
				index = nextIndex++;
				sections.add(new ListSection(Type.list, listIdx));
				indices.put(listIdx, index);
			}
			ListSection section = sections.get(index);
			section.addTask(task);
		}
		return sections.toArray(new ListSection[sections.size()]);
	}

	public static ListSection[] indexByCompleted(List<Task> tasks) {
		ListSection completed = new ListSection(Type.completed, 1);
		ListSection notCompleted = new ListSection(Type.completed, 0);
		for (Task task : tasks) {
			if (task.isCompleted()) {
				completed.addTask(task);
			} else {
				notCompleted.addTask(task);
			}
		}
		return new ListSection[]{ notCompleted, completed };
	}

	public ListSection(Type type, Object arg) {
		this.type = type;
		this.arg = arg;
		this.tasks = new ArrayList<Task>();
	}

	public Type getType() {
		return type;
	}

	public Object getArg() {
		return arg;
	}

	public void addTask(Task task) {
		this.tasks.add(task);
	}
	
	public List<Task> getTasks() {
		return new ArrayList<Task>(this.tasks);
	}
}
