package toodle.model;

import java.sql.*;

public class Attachment {
	private String idx;
	private String taskIdx;
	private String name;
	private String path;
	private String mimetype;
	private Date createdAt;
	public String getIdx() {
		return idx;
	}
	public void setIdx(String idx) {
		this.idx = idx;
	}
	public String getTaskIdx() {
		return taskIdx;
	}
	public void setTaskIdx(String taskIdx) {
		this.taskIdx = taskIdx;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String getMimetype() {
		return mimetype;
	}
	public void setMimetype(String mimetype) {
		this.mimetype = mimetype;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public Attachment() {
		super();
		
	}
}
