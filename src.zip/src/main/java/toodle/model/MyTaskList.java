package toodle.model;

public class MyTaskList extends TaskList {
	private boolean isInbox;

	public boolean isInbox() {
		return isInbox;
	}

	public void setInbox(boolean isInbox) {
		this.isInbox = isInbox;
	}
	
}
