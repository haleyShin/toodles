package toodle.model;

import java.util.*;

class entitiesResult{
	 String attachmentCount;
	 String commentCount;
	 String subtaskCount;
	 String subtaskCompletedCount;

	
 public entitiesResult(Object attachment, Object comment,Object subtask,Object subtaskCompleted){
			this.attachmentCount =""+ attachment;
			this.commentCount= ""+ comment;
			if(subtaskCompleted==null){
				this.subtaskCompletedCount="0";	
			}else{
				this.subtaskCompletedCount=""+ subtaskCompleted;
			}
			this.subtaskCount= ""+ subtask;
			
	 }
 
}

public class SearchResult {
	private String section;
	private String listIdx;
	private List<Task> tasks;

	public SearchResult(String section, String listIdx) {
		this.section = section;
		this.listIdx = listIdx; 
		this.tasks = new ArrayList<Task>();
	}
	
	public List<Task> getTasks() {
		return tasks;
	}

	public String getSection() {
		return section;
	}



	public String getListIdx() {
		return listIdx;
	}

	

	public void addTask(Task task) {
		tasks.add(task);
	}
	public static Map<String, SearchResult> indexByListIdx(List<Task> tasks) {
		//
		Map<String, SearchResult> sections = new HashMap<String, SearchResult>();

		for (Task task : tasks) { //tasks에 있는 데이터를 task에 넣는다. 1개씩 
			if (!sections.containsKey(task.getListIdx())) {
				sections.put(task.getListIdx(), new SearchResult(
					task.getSection(),
					task.getListIdx()
				));
		//	System.out.println(task.getName()+":"+task.getSection());
			}
			SearchResult section = sections.get(task.getListIdx());
			section.addTask(task);
		}

		return sections;

	}

	public static Map<String, SearchResult> indextBySection(List<Task> tasks){
		Map<String, SearchResult> sections = new HashMap<String, SearchResult>();
		
		for(Task task: tasks){
			if(!sections.containsKey(task.getSection())){
				sections.put(task.getSection(), 
				new SearchResult(task.getSection(), task.getIdx()));
			
			//	System.out.println(task.getName()+":"+task.getSection()+":"+task.getIdx());
			}
			SearchResult section = sections.get(task.getSection());
		
			section.addTask(task);
		}
		return sections;
	}

	public static Map<Object,Object> indexByDate(List<Map<String,Object>> calendarDate){
		Map<Object, Object> sections = new HashMap<Object, Object>();
	
		for(int i=0;i<calendarDate.size();i++){
			if(!sections.containsKey(calendarDate.get(i).get("date"))){
				sections.put(calendarDate.get(i).get("date"),
							 calendarDate.get(i).get("COUNT"));
//				System.out.println(calendarDate.get(i).get("date")+":"
//							 +calendarDate.get(i).get("COUNT"));
			}
			
		}
		
		return sections;
	}
	

}

