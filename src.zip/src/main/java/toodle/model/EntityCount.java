package toodle.model;

public class EntityCount {
	private String idx;
	private int attachments;
	private int comments;
	private int subtasks;
	private int subtasksDone;
	public String getIdx() {
		return idx;
	}
	public void setIdx(String idx) {
		this.idx = idx;
	}
	public int getAttachments() {
		return attachments;
	}
	public void setAttachments(int attachments) {
		this.attachments = attachments;
	}
	public int getComments() {
		return comments;
	}
	public void setComments(int comments) {
		this.comments = comments;
	}
	public int getSubtasks() {
		return subtasks;
	}
	public void setSubtasks(int subtasks) {
		this.subtasks = subtasks;
	}
	public int getSubtasksDone() {
		return subtasksDone;
	}
	public void setSubtasksDone(int subtasksDone) {
		this.subtasksDone = subtasksDone;
	}
	
}
