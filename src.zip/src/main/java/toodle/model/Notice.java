package toodle.model;

import java.util.Date;

public class Notice {
	private String idx;
	private String type;
	private String refIdx;
	private String refName;
	private String taskIdx;
	private String taskName;
	private String listIdx;
	private String listName;
	private Date createdAt;
	private String userIdx;
	private String userPhoto;
	private String userName;
	private String userEmail;

	public String getIdx() {
		return idx;
	}
	public void setIdx(String idx) {
		this.idx = idx;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getRefIdx() {
		return refIdx;
	}
	public void setRefIdx(String refIdx) {
		this.refIdx = refIdx;
	}
	public String getRefName() {
		return refName;
	}
	public void setRefName(String refName) {
		this.refName = refName;
	}
	public String getTaskIdx() {
		return taskIdx;
	}
	public void setTaskIdx(String taskIdx) {
		this.taskIdx = taskIdx;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getListIdx() {
		return listIdx;
	}
	public void setListIdx(String listIdx) {
		this.listIdx = listIdx;
	}
	public String getListName() {
		return listName;
	}
	public void setListName(String listName) {
		this.listName = listName;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public String getUserIdx() {
		return userIdx;
	}
	public void setUserIdx(String userIdx) {
		this.userIdx = userIdx;
	}
	public String getUserPhoto() {
		return userPhoto;
	}
	public void setUserPhoto(String userPhoto) {
		this.userPhoto = userPhoto;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
}
