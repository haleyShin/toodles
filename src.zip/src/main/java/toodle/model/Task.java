package toodle.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Task {
    private String idx;
    private String listIdx;
    private String userIdx;
    private String name;
    private String description;
    private Date startDatetime;
    private Date dueDatetime;
    private Date remindDatetime;
    private boolean isImportant;
    private boolean isCompleted;
    private Date createdAt;
    private Date updatedAt;
    private String version;
    private int ord;
    private String section;
    private Integer subtaskCompletion;

	public String getIdx() {
		return idx;
	}
	public void setIdx(String idx) {
		this.idx = idx;
	}
	public String getListIdx() {
		return listIdx;
	}
	public void setListIdx(String listIdx) {
		this.listIdx = listIdx;
	}
	public String getUserIdx() {
		return userIdx;
	}
	public void setUserIdx(String userIdx) {
		this.userIdx = userIdx;
	}
	public String getName() {
		return name;
	}

	public Set<String> extractTags() {
		Set<String> tags = new HashSet<String>();
		Pattern p = Pattern.compile("#([0-9a-zA-Z가-힣]+)");
		Matcher m = p.matcher(name);
		while (m.find()) {
			tags.add(m.group(1));
		}
		return tags;
	}

	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getStartDatetime() {
		return startDatetime;
	}
	public void setStartDatetime(Date startDatetime) {
		this.startDatetime = startDatetime;
	}
	public Date getDueDatetime() {
		return (dueDatetime == null) ? null : new Date(dueDatetime.getTime());
	}
	public void setDueDatetime(Date dueDatetime) {
		this.dueDatetime = dueDatetime;
	}
	public Date getRemindDatetime() {
		return (remindDatetime == null) ? null : new Date(remindDatetime.getTime());
	}
	public boolean isImportant() {
		return isImportant;
	}
	public void setImportant(boolean isImportant) {
		this.isImportant = isImportant;
	}
	public boolean isCompleted() {
		return isCompleted;
	}
	public void setCompleted(boolean isCompleted) {
		this.isCompleted = isCompleted;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public int getOrd() {
		return ord;
	}
	public void setOrd(int ord) {
		this.ord = ord;
	}
    public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public Integer getSubtaskCompletion() {
		return subtaskCompletion;
	}
	public void setSubtaskCompletion(Integer subtaskCompletion) {
		this.subtaskCompletion = subtaskCompletion;
	}
	public void setRemindDatetime(Date remindDatetime) {
		this.remindDatetime = remindDatetime;
	}
}
