package toodle.exception;

import org.springframework.http.HttpStatus;

@SuppressWarnings("serial")
public class APIException extends RuntimeException {
	private HttpStatus status;
	private String message;

	public APIException(HttpStatus status) {
		this.status = status;
		this.message = status.getReasonPhrase();
	}

	public APIException(HttpStatus status, String message) {
		this.status = status;
		this.message = message;
	}

	public HttpStatus getStatus() {
		return status;
	}
	
	public void setStatus(HttpStatus status) {
		this.status = status;
	}
	
	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
}
