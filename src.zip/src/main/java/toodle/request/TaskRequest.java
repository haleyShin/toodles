package toodle.request;

import static toodle.util.Str.nullIfEmpty;
import static toodle.util.Str.strEquals;
import static toodle.util.Utils.isEqualDate;
import static toodle.util.Utils.parseDate;
import static toodle.util.Str.parseBoolean;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import toodle.model.Task;

public class TaskRequest {
	final static private SimpleDateFormat timestampFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
	final static private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	private String name;
	private String listIdx;
	private String description;
	private Date dueDatetime;
	private Date remindDatetime;
	private String dueDatetimeSource;
	private String remindDatetimeSource;
	private Boolean isCompleted;
	private Boolean isImportant;

	public TaskRequest() {
		
	}
	
	public TaskRequest(Task task) {
		name = task.getName();
		listIdx = task.getListIdx();
		description = task.getDescription();
		dueDatetime = task.getDueDatetime();
		remindDatetime = task.getRemindDatetime();
		if (dueDatetime != null) {
			dueDatetimeSource = dateFormat.format(dueDatetime);
		}
		if (remindDatetime != null) {
			remindDatetimeSource = timestampFormat.format(remindDatetime);
		}
		isCompleted = task.isCompleted();
		isImportant = task.isImportant();
	}
	
	public void modify(Map<String, String> changes) {
		if (changes.containsKey("name")) {
			name = changes.get("name");
		}
		if (changes.containsKey("listIdx")) {
			listIdx = changes.get("listIdx");
		}
		if (changes.containsKey("description")) {
			description = changes.get("description");
		}
		if (changes.containsKey("dueDatetime")) {
			setDueDatetime(changes.get("dueDatetime"));
		}
		if (changes.containsKey("remindDatetime")) {
			setRemindDatetime(changes.get("remindDatetime"));
		}
		if (changes.containsKey("completed")) {
			isCompleted = parseBoolean(changes.get("completed"));
		}
		if (changes.containsKey("important")) {
			isImportant = parseBoolean(changes.get("important"));
		}
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = nullIfEmpty(name);
	}
	public String getListIdx() {
		return listIdx;
	}
	public void setListIdx(String listIdx) {
		this.listIdx = nullIfEmpty(listIdx);
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = nullIfEmpty(description);
	}
	public Date getDueDatetime() {
		return dueDatetime;
	}
	public void setDueDatetime(String dueDatetime) {
		this.dueDatetimeSource = dueDatetime;
		this.dueDatetime = parseDate(dueDatetime, timestampFormat, dateFormat);
	}
	public Date getRemindDatetime() {
		return remindDatetime;
	}
	public void setRemindDatetime(String remindDatetime) {
		this.remindDatetimeSource = remindDatetime;
		this.remindDatetime = parseDate(remindDatetime, timestampFormat, dateFormat);
	}
	public Boolean isCompleted() {
		return isCompleted;
	}
	public void setCompleted(boolean isCompleted) {
		this.isCompleted = isCompleted;
	}
	public Boolean isImportant() {
		return isImportant;
	}
	public void setImportant(Boolean isImportant) {
		this.isImportant = isImportant;
	}
	
	public boolean update(Task task) {
		if (name == null) {
			throw new IllegalStateException("name is missing");
		}

		boolean isDirty = false;
		isDirty = isDirty || !strEquals(name, task.getName());
		isDirty = isDirty || !strEquals(description, task.getDescription());
		isDirty = isDirty || !isEqualDate(dueDatetime, task.getDueDatetime());
		isDirty = isDirty || !isEqualDate(remindDatetime, task.getRemindDatetime());
		isDirty = isDirty || !strEquals(listIdx, task.getListIdx());
		isDirty = isDirty || (isCompleted == null ? false : isCompleted) != task.isCompleted();
		isDirty = isDirty || (isImportant == null ? false : isImportant) != task.isImportant();

		task.setName(name);
		task.setDescription(description);
		task.setListIdx(listIdx);
		task.setDueDatetime(dueDatetime);
		task.setRemindDatetime(remindDatetime);
		task.setCompleted((isCompleted == null) ? false : isCompleted);
		task.setImportant((isImportant == null) ? false : isImportant);
		return isDirty;
	}

	public boolean updatePartial(Task task) {
		if (task.getIdx() == null && name == null) {
			throw new IllegalStateException("name is missing");
		}

		boolean isDirty = false;
		isDirty = isDirty || (name != null && !strEquals(name, task.getName()));
		isDirty = isDirty || (description != null && !strEquals(description, task.getDescription()));
		isDirty = isDirty || (dueDatetimeSource != null && !isEqualDate(dueDatetime, task.getDueDatetime()));
		isDirty = isDirty || (remindDatetimeSource != null && !isEqualDate(remindDatetime, task.getRemindDatetime()));
		isDirty = isDirty || (listIdx != null && !strEquals(listIdx, task.getListIdx()));
		isDirty = isDirty || (isCompleted != null && isCompleted != task.isCompleted());
		isDirty = isDirty || (isImportant != null && isImportant != task.isImportant());

		if (name != null) {
			task.setName(name);
		}
		if (description != null) {
			task.setDescription(description);
		}
		if (listIdx != null) {
			task.setListIdx(listIdx);
		}
		if (dueDatetimeSource != null) {
			task.setDueDatetime(dueDatetime);
		}
		if (remindDatetimeSource != null) {
			task.setRemindDatetime(remindDatetime);
		}
		if (isCompleted != null) {
			task.setCompleted(isCompleted);
		}
		if (isImportant != null) {
			task.setImportant(isImportant);
		}
		return isDirty;
	}
}
