package toodle.request;

import toodle.model.TaskList;
import static toodle.util.Str.strEquals;
import static toodle.util.Str.nullIfEmpty;

public class ListRequest {
	private String name;
	private String folder;
	private String invites[] = new String[0];
	private String expels[] = new String[0];
	private String chown;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = nullIfEmpty(name);
	}
	public String getFolder() {
		return folder;
	}
	public void setFolder(String folder) {
		this.folder = nullIfEmpty(folder);
	}
	public String[] getInvites() {
		return invites;
	}
	public void setInvites(String[] invites) {
		this.invites = invites;
	}
	public String[] getExpels() {
		return expels;
	}
	public void setExpels(String[] expels) {
		this.expels = expels;
	}
	public String getChown() {
		return chown;
	}
	public void setChown(String chown) {
		this.chown = chown;
	}
	
	public boolean update(TaskList list) {
		boolean changed = false;
		if (!strEquals(name, list.getName())) {
			changed = true;
			list.setName(name);
		}
		list.setFolder(folder);
		return changed;
	}

	public boolean partialUpdate(TaskList list) {
		boolean changed = false;
		if (name != null && !name.equals(list.getName())) {
			changed = true;
			list.setName(name);
		}
		if (folder != null) {
			list.setFolder(folder);
		}
		return changed;
	}
	
	public String validate() {
		if (name == null) {
			return "missing argument: name";
		}
		return null;
	}
}
