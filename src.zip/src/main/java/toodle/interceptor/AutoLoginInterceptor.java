package toodle.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import toodle.model.User;
import toodle.service.LoginService;

public class AutoLoginInterceptor extends HandlerInterceptorAdapter {
	@Autowired
	private LoginService loginService;

	@Autowired
	private User currentUser;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		User user = loginService.getAutoLoginUser(request, currentUser);
		if (user != null) { //자동로그인
			currentUser.merge(user);
		}
		if (currentUser.isLoggedIn()) { //로그인여부
			return true;
		}else{
			response.setStatus(401);
			return false;
		}
	}
}
