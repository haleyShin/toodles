from sys import stdout
from os import listdir
from os.path import join as joinpath
from xml.etree.ElementTree import parse as parsexml
from xml.etree.ElementTree import ElementTree
from xml.etree.ElementTree import Element
from xml.etree.ElementTree import SubElement
from xml.etree.ElementTree import register_namespace

register_namespace('', 'http://www.w3.org/2000/svg')

svg = Element('svg', style='display:none;')
for filename in listdir('src'):
	basename = filename[:filename.index('.')]
	tree = parsexml(joinpath('src', filename));
	root = tree.getroot()
	viewBox = root.attrib['viewBox']
	symbol = SubElement(svg, 'symbol', id=basename, viewBox=viewBox)
	for child in list(root):
		symbol.append(child)

out = ElementTree(svg)
out.write('../sprites.xml')
