ToodleVue.component('task-calendar', ToodleVue.extend({
	template: '#task-calendar',
	props: {
		store: Object,
		month: Date
	},
	data() {
		let weeks = [];
		let m = this.month.getMonth();
		let d1 = new Date(this.month.getTime());
		while (d1.getDay() != 0) {
			d1.setDate(d1.getDate() - 1);
		}

		while (d1.getMonth() <= m) {
			let week = [];
			for (let i = 0; i < 7; i++) {
				let d2 = new Date(d1.getTime());
				d2.setDate(d2.getDate() + i);
				week.push({
					date: d2,
					isCurrentMonth: d2.getMonth() == m,
					count: 0
				});
			}
			d1.setDate(d1.getDate() + 7);
			weeks.push(week);
		}
		return {weeks}
	},
	computed: {
		prevMonth() {
			let d = new Date(this.month.getTime());
			d.setMonth(d.getMonth() - 1);
			return d;
		},
		nextMonth() {
			let d = new Date(this.month.getTime());
			d.setMonth(d.getMonth() + 1);
			return d;
		}
	},
	created() {
		this.store.api.forCalendar(this.month).then((counts) => {
			this.weeks.forEach((week) => {
				week.forEach((day) => {
					day.count = counts[fn.iso8601date(day.date)];
				});
			})
		});
	},
	methods: {
		navigateToDaterange(day) {
			this.bus.$emit("app.navigate", "/list/daterange", {
				dateFrom: fn.iso8601date(day.date),
				dateTo: fn.iso8601date(day.date)
			});
		},
		navigate(month) {
			this.bus.$emit("app.navigate", "/calendar/" + month.getFullYear() + "/" + (month.getMonth() + 1));
		}
	}
}));
