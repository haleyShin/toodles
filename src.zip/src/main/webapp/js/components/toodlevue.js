ToodleVue = Vue.extend({
	beforeCreate() {
		if (this.$root == this) {
			this.bus = new Vue();
		} else {
			this.bus = this.$root.bus;
		}
	}
});
ToodleModal = Vue.extend({
	props: {
		store: Object,
		bus: Vue
	},
	methods: {
		afterOpen() {
			
		},
		beforeClose() {
			
		}
	}
});
ToodleVue.component('user-photo', {
	props: {
		user: Object,
		htmlClass: {
			'type': String,
			'default': ''
		}
	},
	template: [
		'<div v-if="user.photo"',
		'     :class="htmlClass"',
		'     :style="styleObject" class="circle  x-my-photo"',
		'     :title="title"></div>'
	].join('\n'),
	computed: {
		title() {
			return this.user.name + '(' + this.user.email + ')';
		},
		styleObject() {
			let styles = {};
			if (this.user.photo) {
				styles['background-image'] = 'url(img/users/' + this.user.photo + '?updated_at=' + this.user.updatedAt + ')';
			} else {
				styles['background-image'] = 'url(img/profile3.png)';
			}
			return styles;
		}
	}
});
