ToodleVue.component('notices', ToodleVue.extend({
	template: '#notices',
	props: {
		store: Object
	},
	data() {
		return {
			notices: [],
			loaded: false,
			show: false
		}
	},
	watch: {
		show(v) {
			if (v) {
				$(document).one('click', () => this.show = false);
			}
		}
	},
	created() {
		this.xhrSchedules = {
			reload: fn.singleXhr('abort'),
			clear: fn.singleXhr('wait')
		};
		this.reload();
		this.bus.$on('notices.reload', this.reload.bind(this));
	},
	methods: {
		reload: _.debounce(function() {
			this.loaded = false;
			this.xhrSchedules.reload(() => this.store.api.notices()).then((notices) => {
				this.notices = notices;
				this.loaded = true;
			});
		}, 1000),
		clear() {
			let noticeIdx = _.chain(this.notices).pluck('idx').max().value();
			this.xhrSchedules.clear(() => this.store.api.seenNotice(noticeIdx)).then((notices) => {
				this.notices = notices;
			});
		}
	}
}));
