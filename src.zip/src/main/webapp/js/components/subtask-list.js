ToodleVue.component('subtask-list', ToodleVue.extend({
	template: '#t-subtask-list',
	props: {
		store: Object,
		selectedTask: Object
	},
	data() {
		return {
			loaded: false,
			subtasks: [],
			subtaskInput: ''
		}
	},
	created() {
		this.store.api.getSubtasks(this.selectedTask.idx).then((subtasks) => {
			this.subtasks = subtasks;
			this.loaded = true;
		});		
	},
	mounted() {
		$(this.$refs.list).sortable({
			delay: 300,
			onDrop: ($item, container, _super, event) => {
				_super($item, container);
				let idxes = _.map(this.$refs.list.childNodes, (el) => el.getAttribute('data-idx'));
				this.store.api.request("POST", "/task/" + this.selectedTask.idx + "/sortSubtasks", {idxes});
			}
		});
	},
	methods: {
		addSubtask() {
			if (this.subtaskInput) {
				this.store.api.addSubtask(this.selectedTask.idx, {name: this.subtaskInput}).then((subtask) => {
					this.subtasks.push(subtask);
					this.bus.$emit('app.task-sync-counts', this.selectedTask);
				});
				this.subtaskInput = '';
			}
		},
		
		updateCompleted(subtask, completed) {
			this.store.api.updateSubtask(this.selectedTask.idx, subtask.idx, {completed}).then(() => {
				this.bus.$emit('app.task-sync-counts', this.selectedTask);
			});
		},
		
		remove(subtask) {
			fn.remove(this.subtasks, subtask);
			this.store.api.request("DELETE", "/task/" + this.selectedTask.idx + "/subtask/" + subtask.idx).then(() => {
				this.bus.$emit('app.task-sync-counts', this.selectedTask);
			});
		}
	}
}));
