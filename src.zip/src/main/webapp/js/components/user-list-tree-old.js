ToodleVue.component('user-list-tree', ToodleVue.component('tree').extend({
	props: {
		lists: [Array],
		ready: [Boolean]
	},

	beforeCreate() {
		let bus = this.bus = new Vue();		
		bus.$on('rename', (node) => {
			console.log(node);
		});
		bus.$on('sort', () => {
			this.walk((node) => {
				if (node.type == 'folder' && node.children.length == 0) {
					node.parent.removeChild(node);
				}
			});			
			console.log('sort');
		});
		bus.$on('navigate', (href) => {
			
		});
	},

	created() {
		this.oldLists = this.lists.slice(0);
	},

	watch: {
		'root.children': function() {
			this.bus.$emit('sort');
		},

		lists() {
			let removed = _.difference(this.oldLists, this.lists);
			let inserted = _.difference(this.lists, this.oldLists).reverse();
			let existing = _.intersection(this.lists, this.oldLists);

			removed.forEach((list) => {
				let node = this.getNodeBy((n) => n.idx == list.idx);
				if (node) {
					node.parent.removeChild(node);
				}
			});

			let parent = this.root;
			inserted.forEach((list) => {
				if (list.folder) {
					if (parent.type != 'folder' || parent.name != list.folder) {
						parent = this.root.appendChild(this.createFolder(list.folder));
					}
					parent.prependChild(this.createList(list));
				} else {
					parent = this.root;
					parent.prependChild(this.createList(list));
				}
			});
			
			existing.forEach((list) => {
				
			});
			
			this.oldLists = this.lists.slice(0);
		}
	},
	
	components: {
		'node': {
			name: 'node',
			template: '#t-user-list-node',
			props: ['node'],
			computed: {
				icon() {
					if (this.node.type == 'folder') {
						return 'folder';
					} else {
						if (this.node.userCount > 1) {
							return 'user-many';
						} else {
							return 'list';
						}
					}
				}
			},

			created() {
				this.bus = this.$parent.bus;
			},

			watch: {
				'node.name': function(v, oldV) {
					this.bus.$emit('rename', this.node);
				},
				'node.children': function() {
					this.bus.$emit('sort');
				}
			},

			methods: {
				onClick(event) {
					if (this.node.type == 'folder') {
						this.node.isCollapsed = !this.node.isCollapsed;					
					} else {
						this.bus.$emit('navigate', this.node.href);
					}
				},

				onContextmenu(event) {
					event.preventDefault();
					event.stopPropagation();
					if (this.node.type == 'list') {
						this.$root.showContextMenu(event, [
							{name: '수정 ', action: [null, {edit: this.node.idx}, true]},
							{name: '새 폴더', hide: (this.node.parent.type === 'folder'), action: () => {
								this.$parent.wrapList(this.node);
							}},
							{name: '삭제', action: () => {
								this.$root.showConfirmModal("삭제하시겠습니까", () => {
									this.$root.api.deleteList(idx).then(() => {
										this.$root.$refs.userLists.deleteList(idx);
									});
								});
							}},
							{name: '초대', action: [null, {edit: this.node.idx}, true]}
						]);
					} else {
						this.$root.showContextMenu(event, [
							{name: '이름 바꾸기', action: () => {
								this.$refs.name.startEditing();
							}},
							{name: '폴더 해제', action: () => {
								this.$parent.removeFolder(this.node);
							}}
						]);
					}
				}
			}
		}
	},

	mounted() {
		$(this.$el).sortable({
			delay: 300,
			isValidTarget: ($item, container) => {
				return !($item.hasClass('js-folder') && container.el.parent().hasClass('js-folder'));
			},
			onDrop: ($item, container, _super, event) => {
				_super($item, container);
				var item = $item[0];
				var node = this.getNodeById(item.getAttribute('data-node-id'));
				var oldParent = node.parent;
				var newParent = this.getNodeById(item.parentNode.getAttribute('data-parent-id')) || this.root;
				newParent.insertChildAt($item.index(), node);
				if (oldParent !== newParent) {
					$item.remove();
				}
				this.bus.$emit('sort');
			}
		});
	},	

	methods: {

		getFolderByName(name) {
			return this.getNodeBy((n) => n.type == 'folder' && n.name == name);
		},
		
		createFolder(name, initRenaming = false) {
			return this.createNode({
				initRenaming,
				name,
				type: 'folder',
				isCollapsed: false	
			})
		},

		createList(data) {
			return this.createNode({
				name: data.name,
				userCount: data.userCount,
				idx: data.idx,
				type: 'list',
				href: '/list/' + data.idx
			});
		},
		
		// /sortLists API 호출을 위한 인자 값 마련
		toArray() {
			var result = [];
			this.walk((node) => {
				if (node.type == 'list') {
					if (node.parent.type == 'folder') {
						result.push(node.idx + ':' + node.parent.name);
					} else {
						result.push(node.idx);
					}
				}
			});
			return result;
		},
		
		removeFolder(folder) {
			let pos = folder.parent.indexOf(folder);
			folder.children.forEach((child) => {
				folder.parent.insertChildAt(pos++, child);
			});
			this.sortLists();
		},

		updateListNode(list) {
			let theNode = this.getNodeBy((n) => n.idx == list.idx);
			if (!theNode) {
				theNode = this.createList(list);
			}
			
			let theParent = theNode.parent; 

			if (list.folder) {
				let parentChanged = (!theParent || theParent == this.root || list.folder != theParent.name); 
				if (parentChanged) {
					let pos = (theParent) ? theParent.indexOf(theNode) : 0;
					let parent = this.getFolderByName(list.folder);
					if (parent) {
						parent.appendChild(theNode);
					} else {
						this.root.insertChildAt(pos, this.createFolder(list.folder)).appendChild(theNode);
					}
				}

			} else {
				let pos;
				if (theParent && theParent.type === 'folder') {
					pos = theParent.indexOf(theNode);
				} else {
					pos = 0;
				}
				this.root.insertChildAt(pos, theNode);
			}

			theNode.idx = list.idx;
			theNode.name = list.name;
			this.sortLists();
		},

		deleteList(idx) {
			let theNode = this.getNodeBy((n) => n.idx == idx);
			if (theNode) {
				theNode.parent.removeChild(theNode);
				this.sortLists();
			}
		},

		wrapList(node) {
			node.parent.insertChildAt(
				node.parent.indexOf(node),
				this.createFolder("새 폴더", true)
			).appendChild(node);
			this.sortLists();
		}
	}
}));
