ToodleVue.component('daterange-modal', ToodleModal.extend({
	template: '#daterange-modal',
	props: {
		
	},
	data() {
		return {
			range: null,
			error: null
		}
	},
	mounted() {
		let flatpickr = new Flatpickr(this.$refs.input, {
			mode: 'range',
			onClose: () => {
				if (flatpickr.selectedDates.length == 2) {
					this.range = flatpickr.selectedDates.slice(0);
				} else {
					this.range = null;
				}
			}
		});
	},
	methods: {
		apply() {
			if (!this.range) {
				this.error = "범위를 선택해주세요.";
			} else {
				this.error = "";
				this.onApply.apply(this, this.range);
				this.close();
			}
		},
		cancel() {
			this.onCancel();
			this.close();
		},
		onApply(dateFrom, dateTo) {
			
		},
		onCancel() {
			
		}
	}
}));
