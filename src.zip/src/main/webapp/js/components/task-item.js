ToodleVue.component('task-item', ToodleVue.extend({
	template: '#t-task-item',
	props: {
		store: Object,
		userListTree: Object,
		task: Object,
		selection: Object,
		index: Number
	},
	data() {
		return {
			checked: this.task.completed
		}
	},
	computed: {
		id() {
			return 'task' + this.task.idx;
		},
		classes() {
			return {
				'in-selection': this.task.inSelection,
				'editing': this.task.editing,
				'is-completed': this.task.completed,
				'task-item': true
			}
		},
		formattedDue() {
			if (this.task.dueDatetime) {
				return (new Date(this.task.dueDatetime)).toLocaleDateString('ko-KR');
			}
		}
	},
	watch: {
		'task.name'() {
			this.displayName();
		}
	},
	created() {
		this.toggleCheck = _.debounce((v) => {
			if (v != this.task.completed) {
				this.bus.$emit("app.task-update", this.task, {completed: v});
			}
		}, 500);
		this.setImportant = _.debounce((v) => {
			if (v != this.task.important) {
				this.task.important = v;
				this.bus.$emit("app.task-update", this.task, {important: v});				
			}
		});
	},
	mounted() {
		this.displayName();		
	},
	methods: {
		displayName() {
			let patt = /((?:[^#\s]*\s*)*)(#[0-9a-zA-Z가-힣]*)?/g;
			let name = this.task.name;
			let element = this.$refs.taskName;
			
			element.innerHTML = "";
			while (patt.lastIndex < name.length) {
				let match = patt.exec(name);
				if (match[1]) {
					element.appendChild(document.createTextNode(match[1]));					
				}
				if (match[2]) {
					if (match[2] == '#') {
						element.appendChild(document.createTextNode('#'));
					} else {
						let span = element.appendChild(document.createElement('span'));
						span.className = 'hashtag';
						span.textContent = match[2];						
					}
				}
			}
			
		},
		onClick(event) {
			if (event.target.className == 'hashtag') {
				this.bus.$emit('app.navigate', null, {search:event.target.textContent, fields: 'taskName'});
			} else {
				this.bus.$emit('app.task-click', this.task, event);				
			}
		},
		onCheckChange() {
			this.toggleCheck(this.checked);
		},
		onContextmenu(event) {
			if (this.selection.size()) {
				let allCompleted = _.every(this.selection.items, (task) => task.completed);
				let allNotCompleted = _.every(this.selection.items, (task) => !task.completed);
				let allImportant = _.every(this.selection.items, (task) => task.important);
				let allNotImportant = _.every(this.selection.items, (task) => !task.important);
				this.bus.$emit("app.contextmenu", event, [
					{icon: 'trash-o', name: '삭제', action: () => {
						this.bus.$emit("app.task-delete-selection");
					}},
					{icon: 'check-square-o', name: '모두 완료', action: () => {
						this.bus.$emit("app.task-update-selection", {completed: true});
					}, hide: allCompleted},
					{icon: 'check-square', name: '모두 ‘완료 안 됨’으로 처리', action: () => {
						this.bus.$emit("app.task-update-selection", {completed: false});
					}, hide: allNotCompleted},
					{icon: 'star', name: '모두 중요 표시', action: () => {
						this.bus.$emit('app.task-update-selection', {important: true});
					}, hide: allImportant},
					{icon: 'star-o  text-strike', name: '모두 중요 표시 해제', action: () => {
						this.bus.$emit('app.task-update-selection', {important: false});
					}, hide: allNotImportant},
					{icon: 'exchange', name: '이동', children: this.userListTree.generateContextmenu((node) => {
						return {
							icon: this.getListIcon(node),
							name: this.getListName(node),
							disabled: this.task.listIdx == node.idx,
							action: () => {
								if (node.idx != this.task.listIdx) {
									this.bus.$emit('app.task-update-selection', {listIdx: node.idx});									
								}
							}
						}
					})},
					{icon: 'clone', name: '복사', action: () => {
						this.bus.$emit('app.task-clone-selection');
					}},
					{icon: 'clone', name: '다른 목록으로 복사', children: this.userListTree.generateContextmenu((node) => {
						return {
							icon: this.getListIcon(node),
							name: this.getListName(node),
							action: () => this.bus.$emit('app.task-clone-selection', {listIdx: node.idx})
						}
					})}
				]);
			} else {
				this.bus.$emit("app.contextmenu", event, [
					{icon: 'trash-o', name: '삭제', action: () => {
						this.bus.$emit("app.task-delete", this.task);
					}},
					{icon: 'star', name:'중요 표시', action: () => {
						this.bus.$emit('app.task-update', this.task, {important: true});
					}, hide: this.task.important},
					{icon: 'star-o  text-strike', name: '중요 표시 해제', action: () => {
						this.bus.$emit('app.task-update', this.task, {important: false});
					}, hide: !this.task.important},
					{icon: 'exchange', name: '이동', children: this.userListTree.generateContextmenu((node) => {
						return {
							icon: this.getListIcon(node),
							name: this.getListName(node),
							disabled: (this.task.listIdx == node.idx),
							action: () => this.bus.$emit("app.task-update", this.task, {listIdx: node.idx})
						}
					})},
					{icon: 'clone', name: '복사', action: () => {
						this.bus.$emit('app.task-clone', this.task);
					}},
					{icon: 'clone', name: '다른 목록으로 복사', children: this.userListTree.generateContextmenu((node) => {
						return {
							icon: this.getListIcon(node),
							name: this.getListName(node),
							hide: (this.task.listIdx == node.idx),
							action: () => this.bus.$emit("app.task-clone", this.task, {listIdx: node.idx})
						}
					})}
				]);
			}
		},
		getListIcon(node) {
			if (node.idx == this.task.listIdx) {
				return 'check';
			}
			if (node.idx == this.store.me.inboxIdx) {
				return 'inbox';
			} else {
				return 'list';
			}
		},
		getListName(node) {
			if (node.idx == this.store.me.inboxIdx) {
				return '임시 보관함';
			} else {
				return node.name;
			}
		}
	}
}));
