ToodleVue.component('me-edit-modal', ToodleModal.extend({
	template: '#me-edit-modal',
	props: {
		me: Object
	},
	computed: {
		photo() {
			return {
				'background-image': 'url(img/users/' + this.me.photo + ')' 
			}
		}
	},
	methods: {
		onSubmit(event) {
			let form = event.target;
			let formData = new FormData(form);			
			this.store.api.me(formData).then((me) => {
				console.log(this.store.me);
				_.extend(this.store.me, me);
				this.close();
			}, (xhr) => {
				// TODO: 오류 처리
			});
		},
		beforeClose() {
			this.bus.$emit("app.navigate", null, {editMe: undefined}, true);
		}
	}
}));
