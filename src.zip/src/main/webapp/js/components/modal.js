ToodleModal = Vue.extend({
	props: {
		store: Object,
		bus: Vue
	},
	methods: {
		onClose() {
			
		}
	}
});
