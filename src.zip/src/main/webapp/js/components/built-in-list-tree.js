ToodleVue.component('inbox-node', ToodleVue.extend({
	template: '#t-inbox-node',
	props: {
		node: Object
	},
	computed: {
		notCompleted() {
			if (this.node.linkedNode) {
				return this.node.linkedNode.notCompleted;
			} else {
				return 0;
			}
		}
	},
	methods: {
		onClick() {
			this.bus.$emit('app.navigate', '/list/inbox');
		}
	}
}));
ToodleVue.component('built-in-node', ToodleVue.extend({
	template: '#t-built-in-node',
	props: {
		node: Object
	},
	computed: {
		notCompleted() {
			return this.node.notCompleted || 0;
		}
	},
	methods: {
		onClick() {
			this.bus.$emit('app.navigate', this.node.route);
		}
	}
}));
ToodleVue.component('built-in-folder', ToodleVue.extend({
	props: {
		node: Object,
		store: Object
	},
	computed: {
		classObject() {
			return {'is-selected': this.node.isCollapsed && (this.node.children.filter((n) => n.isSelected)).length };
		}
	},
	template: '#t-built-in-folder'
}));
ToodleVue.component('invitation-node', ToodleVue.extend({
	template: '#invitation-node',
	props: {
		node: Object,
		store: Object
	},
	methods: {
		
	}
}));

ToodleVue.component('invitation-folder', ToodleVue.extend({
	template: '#invitation-folder',
	props: {
		node: Object,
		store: Object
	}
}));

ToodleVue.component('built-in-list-tree', ToodleVue.extend({
	components: {
		'inbox-node': ToodleVue.component('inbox-node')
	},

	template: [
		'<ul class="list-tree">',
		'  <component :is="child.componentName" v-for="child of store.builtInListTree.root.children" :node="child" :store="store" :key="child.id"/>',
		'</ul>'
	].join('\n'),

	props: {
		store: Object
	},

	created() {
		// alias
		this.tree = this.store.builtInListTree;
	},

	mounted() {
		
	}
}));
