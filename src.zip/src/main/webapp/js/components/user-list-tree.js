ToodleVue.component('user-list-node', ToodleVue.extend({
	name: 'user-list-node',
	template: '#t-user-list-node',
	props: {
		node: Object,
		tree: Object
	},
	created() {
		if (this.node.type == 'list') {
			this.tree.updateNotCompleted(this.node.idx);
		}
	},

	computed: {
		icon() {
			if (this.node.type == 'folder') {
				return 'folder';
			} else {
				return (this.node.userCount > 1) ? 'user-many' : 'list';
			}
		},
		classObject() {
			if (this.node.type == 'folder') {
				return {'is-selected': this.node.isCollapsed && (this.node.children.filter((n) => n.isSelected)).length };
			} else {
				return {'is-selected': this.node.isSelected};
			}
		}
	},

	watch: {
		'node.name'() {
			this.tree.saveRenamedNode(this.node);
		},
		'node.children'() {
			this.bus.$emit('userListTree.saveTree');
		}
	},

	methods: {
		onClick(event) {
			if (this.node.type == 'folder') {
				this.node.isCollapsed = !this.node.isCollapsed;	
			} else {
				this.bus.$emit('app.navigate', "/list/" + this.node.idx, null, false);
			}
		},

		onContextmenu(event) {
			event.preventDefault();
			event.stopPropagation();
			if (this.node.type == 'folder') {
				this.bus.$emit('app.contextmenu', event, [
					{icon: 'pencil', name: '이름 바꾸기', action: () => {
						this.$refs.name.startEditing();
					}},
					{icon: 'outdent',name: '폴더 해제', action: () => {
						this.tree.unfolder(this.node);
					}}
				]);
			} else {
				this.bus.$emit('app.contextmenu', event, [
					{icon: 'pencil', name: '이름 바꾸기', action: () => {
						this.$refs.name.startEditing();
					}},
					{icon: 'folder-open-o', name: '새 폴더', hide: this.node.parent.type == 'folder', action: () => {
						this.tree.enfolder(this.node);
					}},
					{
						icon: (this.node.userState == 'owner') ? 'trash-o' : 'sign-out',
						name: (this.node.userState == 'owner') ? '삭제' : '나가기',
						action: () => {
							this.bus.$emit('app.list-delete', this.node.idx);
						}
					},
					{icon: 'pencil-square-o', name: '수정', action: () => {
						this.bus.$emit('app.navigate', null, {edit: this.node.idx}, true);
					}},
				]);
			}
		}
	}
}));

ToodleVue.component('user-list-tree', ToodleVue.extend({
	template: [
		'<ul class="list-tree">',
		'  <user-list-node v-for="child of store.userListTree.root.children" :node="child" :tree="store.userListTree" :key="child.id"/>',
		'</ul>'
	].join('\n'),

	props: {
		store: Object
	},

	created() {
		// alias
		this.tree = this.store.userListTree;
		this.saveTree = _.debounce(() => this.tree.saveTree(), 50);
	},

	watch: {
		'store.userListTree.root.children'() {
			this.bus.$emit('userListTree.saveTree');
		},
		'store.userListTreeLoaded'(v) {
			if (v) {
				this.bus.$on('userListTree.saveTree', this.saveTree);
			} else {
				this.bus.$off('userListTree.saveTree', this.saveTree);
			}
		}
	},

	mounted() {
		$(this.$el).sortable({
			delay: 300,
			isValidTarget: ($item, container) => {
				return !($item.hasClass('js-folder') && container.el.parent().hasClass('js-folder'));
			},
			onDrop: ($item, container, _super, event) => {
				_super($item, container);
				let item = $item[0];
				let node = this.tree.getNodeById(item.getAttribute('data-node-id'));
				let oldParent = node.parent;
				let newParent = this.tree.getNodeById(item.parentNode.getAttribute('data-parent-id')) || this.tree.root;

				// + 1을 하는 이유는 inbox가 언제나 제일 앞에 있기 때문
				newParent.insertChildAt($item.index() + 1, node);
				if (oldParent !== newParent) {
					$item.remove();
				}
			}
		});
	}
}));
