ToodleVue.component('list-edit-modal', ToodleModal.extend({
	template: '#list-edit-modal',
	components: {
		'user-photo': ToodleVue.component('user-photo')
	},
	props: {
		list: Object,
		editUser: Boolean
	},

	data() {
		return {
			users: [],
			userInput: '',
			userError: ''
		}
	},

	created() {
		this.xhrSchedules = {
			getUser: fn.singleXhr('abort'),
			saveList: fn.singleXhr('wait')
		};

		if (this.list.idx) {
			this.store.api.getListUsers(this.list.idx).then((users) => {
				this.users.push.apply(this.users, users.map((u) => this.computeUserProperties(u)));
			});			
		}
	},
	
	mounted() {
		if (this.editUser) {
			Vue.nextTick(() => {
				this.$refs.user.focus();				
			});
		} else {
			Vue.nextTick(() => {
				this.$refs.name.focus();
			});
		}
	},
	
	methods: {
		computeUserProperties(user) {

			// userStateLabel
			switch (user.userState) {
				case 'owner': user.userStateLabel = '소유자'; break;
				case 'member': user.userStateLabel = '참여자'; break;
				case 'invited': user.userStateLabel = '초대 중'; break;

				case 'willInvite': user.userStateLabel = '초대할 예정'; break;
				case 'willDelete': user.userStateLabel = '추방됨'; break;
				default: user.userStateLabel = user.userState;
			}

			// isRemovable
			if (this.list.userState == 'owner') {
				user.isRemovable = (this.store.me.idx != user.idx);
			} else if (this.list.userState == 'member'){
				user.isRemovable = (this.store.me.idx == user.idx);
			}
			
			// removalLabel
			if (this.store.me.idx == user.idx) {
				user.removalLabel = '나가기';
			} else if (user.userState == 'willInvite') {
				user.removalLabel = '취소';
			} else if (user.userState == 'invited') {
				user.removalLabel = '취소';
			} else if (user.userState == 'member') {
				user.removalLabel = "내보내기";
			}

			return user;
		},

		removeUser(idx) {
			let target = _.findWhere(this.users, {idx});
			if (target) {
				if (target.userState == 'willInvite') {
					this.users.splice(this.users.indexOf(target), 1);					
				} else {
					target.userState = 'willDelete';
				}
			}
		},

		addUser(email) {
			if (!email) {
				return fn.resolvedDefer();
			}

			if (email == this.store.me.email) {
				this.userError = "이미 참여하고 계십니다.";
				return deferred;
			}

			return this.xhrSchedules.getUser(() => this.store.api.getUser({email})).then((user) => {
				if (!user) {
					this.userError = '존재하지 않는 사용자입니다.';
					return;
				}

				let match = _.findWhere(this.users, {email});
				if (match) {
					switch (match.userState) {
						case 'willInvite':
							this.userError = '이미 초대할 사용자 입니다.';
							this.userInput = '';
							break;
						case 'invited':
							this.userError = '이미 초대 중인 사용자입니다.';
							this.userInput = '';
							break;
						case 'willDelete':
							match.userState = user.userState;
							this.userError = '';
							this.userInput = '';
							break;
						case 'member':
						case 'owner':
							this.userError = '이미 참여 중인 사용자입니다.';
							this.userInput = '';
							break;
					}
					return;
				}

				user.userState = 'willInvite';
				this.users.push(this.computeUserProperties(user));
				this.userInput = '';
				this.userError = '';

			}, (xhr) => {
				switch (xhr.status) {
					default:
						if (xhr.readyState == 0) {
							// abort
						} else {
							// TODO: 오류 처리							
						}
				}
			});
		},

		afterOpen() {
			let contactTemplate = _.template([
				"<div class='media'>",
				"  <div class='media-img'></div>",
				"  <div class='media-body'>",
				"    <b><%- name %></b><br>",
				"    <%- email %>",
				"  </div>",
				"</div>"
			].join("\n"));

			this.store.api.contacts().then((contacts) => {
				$(this.$refs.user).autocomplete({
					minLength: 0,
					delay: 100,
					source: contacts.map((contact) => _.extend(contact, { 
						label: contact.name,
						value: contact.email
					}))
				}).autocomplete('instance')._renderItem = function(ul, item) {
					return $('<li>').html(contactTemplate(item)).appendTo(ul);
				}
			});
		},

		beforeClose() {
			this.bus.$emit('app.navigate', null, {edit: undefined, editUser: undefined, create: undefined}, true);
		},

		save() {
			let isNew = !this.list.idx;
			this.addUser(this.userInput).then(() => {
				let users = _.chain(this.users);
				let expels = users.where({userState: 'willDelete'}).pluck('idx').value();
				let invites = users.where({userState: 'willInvite'}).pluck('idx').value();
				return this.xhrSchedules.saveList(() => this.store.api.saveList({
					idx: this.list.idx,
					name: this.list.name,
					folder: this.list.folder,
					expels, invites
				}));

			}).then((result) => {
				this.close();
				if (result) {
					this.bus.$emit("app.list-update", result);										
					if (isNew) {
						this.bus.$emit("app.navigate", "/list/" + result.idx);
					}
				} else {
					this.bus.$emit("app.list-clean", this.list.idx);
				}
			}, (xhr) => {
				// TODO: 오류 처리
				switch (xhr.status) {
					case 404:
						this.close();
						this.bus.$emit("app.alert", "목록이 이미 삭제됐습니다.");
						this.bus.$emit("app.list-clean", this.list.idx);
						break;
				}
			});
		}		
	}
}));
