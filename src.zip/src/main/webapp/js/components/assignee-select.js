ToodleVue.component('assignee-select', ToodleVue.extend({
	template: '#t-assignee-select',
	props: {
		selectedTask: Object,
		store: Object
	},
	data() {
		return {
			loaded: false,
			users: [],
			unassigned: [],
			assignees: []
		}
	},
	computed: {
		sortedUnassigned() {
			return _.sortBy(this.unassigned, (u) => this.users.indexOf(u))
		}
	},
	watch: {
		selectedTask() {
			this.reset();
		},
		assignees(v, oldV) {
			if (v == oldV) {
				this.store.api.assign(this.selectedTask.idx, _.pluck(this.assignees, 'idx')).then(() => {
					this.store.main.handleTaskUpdate(this.selectedTask);
				})
			}
		}
	},
	created() {
		this.api = this.store.api;		
		this.xhrSchedules = {
			getListUsers: fn.singleXhr('abort'),
			getAssignees: fn.singleXhr('abort')
		};
		this.gotUsersOf = null;
		this.gotUsers = null;
		this.reset();
	},
	mounted() {
		this.clickHandler = () => {
			this.hidePopover();
		}
	},

	methods: {
		showPopover(event) {
			let $popover = $(this.$refs.popover);
			if ($popover.hasClass('hide')) {
				$popover.removeClass('hide').position({
					'my': 'left-10 top+5',
					'at': 'center bottom',
					'of': event.currentTarget,
					'collision': 'fit none'
				});
				$(document).on('click', this.clickHandler);
			}
		},
		hidePopover() {
			this.$refs.popover.classList.add('hide');
			$(document).off('click', this.clickHandler);
		},
		assign(user) {
			this.unassigned.splice(this.unassigned.indexOf(user), 1);
			this.assignees.push(user);
		},
		unassign(user) {
			this.assignees.splice(this.assignees.indexOf(user), 1);
			this.unassigned.push(user);
		},

		reset() {
			this.loaded = false;
			let gotUsers = this.getUsers().then(fn.pass);
			let gotAssignees = this.getAssignees().then(fn.pass);
			$.when(gotUsers, gotAssignees).then((users, assignees) => {
				this.users = users;
				this.assignees = assignees.filter((u) => _.findWhere(users, {idx: u.idx}));
				this.unassigned = users.filter((u) => !_.findWhere(assignees, {idx: u.idx}));
				this.loaded = true;
			});
		},

		getUsers(force) {
			if (force || this.gotUsersOf != this.selectedTask.listIdx) {
				let req = () => this.api.getListUsers(this.selectedTask.listIdx, ['member', 'owner']);
				this.gotUsers = this.xhrSchedules.getListUsers(req);
				this.gotUsersOf = this.selectedTask.listIdx;
				return this.gotUsers;
			} else {
				return this.gotUsers;
			}
		},

		getAssignees() {
			let req = () => this.api.getAssignees(this.selectedTask.idx);
			return this.xhrSchedules.getAssignees(req);
		}
	}
}));
