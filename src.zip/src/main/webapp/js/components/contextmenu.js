ToodleVue.component('contextmenu', ToodleVue.extend({
	name: 'contextmenu',
	template: [
		'<ul class="contextmenu"', 
		'    v-show="show"',
		'    :style="styles">',
		'	 <li v-for="(item, i) of menuItems"',
		'        v-if="!item.hide"',
		'        :class="item.disabled ? \'is-disabled\' : \'\'"',
		'        :ref="\'item\'+i"',
		'        @mouseover="onMouseover(item)"',
		'        @mouseleave="onMouseleave(item)"',
		'        @click.stop="onClick($event, item)">',
		'        <i v-if="item.icon" class="contextmenu-icon  fa" :class="\'fa-\' + item.icon"></i>',
		'        {{ item.name }}',
		'        <i v-if="item.children && item.children.length" class="fa  fa-caret-right  contextmenu-caret"></i>',
		'        <contextmenu v-if="item.children && item.children.length"',
		'                    :items="item.children" :z-index="zIndex + 1"',
		'                    :ref="\'submenu\' + i"',
		'                    @select="onSelect"></contextmenu>',
		'    </li>',
		'</ul>'
	].join('\n'),
	props: {
		items: Array,
		zIndex: {
			'type': Number,
			'default': 1
		}
	},
	data() {
		return {
			x: 0,
			y: 0,
			show: false,
			currentSubmenu: null,
		}
	},
	computed: {
		styles() {
			return {
				'left': this.x + 'px',
				'top': this.y + 'px',
				'z-index': this.zIndex
			}
		},
		menuItems() {
			return this.items.slice(0);				
		}
	},
	watch: {
		currentSubmenu(v, old) {
			if (old) {
				old.hide();				
			}
		}
	},
	created() {
		this.submenuTimeout = null;
	},
	methods: {
		display(origin) {
			this.show = true;
			this.x = origin.x;
			this.y = origin.y;
			Vue.nextTick(() => {
				let el$ = $(this.$el);
				let offsets = el$.offset();
				let height = el$.height();
				let width = el$.width();
				let dy = offsets.top + height - document.body.clientHeight;
				let dx = offsets.left + width - document.body.clientWidth;

				if (dy > 0) {
					if (this.$parent.$options.name == 'contextmenu') {
						this.y = origin.y - height + 38;
					} else {
						this.y = origin.y - height;				
					}
				}
				if (dx > 0) {
					if (this.$parent.$options.name == 'contextmenu') {
						this.x = origin.x - width - 20;
					} else {
						this.x = origin.x - width;						
					}
				}
			});
		},

		hide() {
			this.show = false;
			clearTimeout(this.submenuTimeout);
			for (let p in this.$refs) {
				if (fn.startswith(p, "submenu")) {
					if (this.$refs[p].length) {
						this.$refs[p][0].hide();						
					}
				}
			}
		},

		getSubmenuComponent(item) {
			let ref = this.$refs['submenu' + this.menuItems.indexOf(item)];
			if (ref) {
				return ref[0]
			} else {
				return;
			}
		},
		
		getItemElement(item) {
			return this.$refs['item' + this.menuItems.indexOf(item)][0];
		},

		scheduleSubmenuDisplay(item) {
			let submenu = this.getSubmenuComponent(item);
			if (submenu) {
				this.currentSubmenu = null;
				clearTimeout(this.submenuTimeout);
				this.submenuTimeout = setTimeout(() => this.showSubmenu(item), 200);
			}
		},

		showSubmenu(item) {
			let submenu = this.getSubmenuComponent(item);
			if (submenu) {
				clearTimeout(this.submenuTimeout);
				let element = this.getItemElement(item);
				let x = element.getBoundingClientRect().width - 1;
				let y = 0;
				submenu.display({x, y});
				this.currentSubmenu = submenu;
			}
		},

		onClick(event, item) {
			let submenu = this.getSubmenuComponent(item);
			if (submenu) {
				if (submenu.show) {
					this.currentSubmenu = null;
				} else {
					this.showSubmenu(item);					
				}
			} else {
				if (item.disabled) {
					event.stopPropagation();
				} else {
					item.action();
					this.hide();
					this.$emit("select");					
				}
			}
		},
		onMouseover(item) {
			let submenu = this.getSubmenuComponent(item);
			if (submenu && !submenu.show) {
				this.scheduleSubmenuDisplay(item);
			}
		},
		onMouseleave(item) {
			this.currentSubmenu = null;
		},
		onSelect() {
			this.hide();
			this.$emit("select");
		}
	}
}));
