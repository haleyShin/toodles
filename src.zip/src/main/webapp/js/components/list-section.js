ToodleVue.component('list-section', ToodleVue.extend({
	template: '#t-list-section',
	props: {
		store: Object,
		section: Object
	},

	data() {
		return {
			isCollapsed: (this.section.type == 'completed' && this.section.arg), // 완료된 일
		}
	},

	computed: {
		show() {
			// 완료된 일은 있을 때에만 보여준다.
			if (this.section.type == 'completed' && this.section.arg) {
				return this.section.tasks.length > 0;
			}
			// 나머지는 언제나 보여준다.
			return true;
		},

		title() {
			if (this.section.type == 'list') {
				if (this.section.arg == this.store.me.inboxIdx) {
					return '임시 보관함';
				}

				let node = this.store.userListTree.getListNodeByIdx(this.section.arg);
				if (node) {
					return node.name;
				} else {
					return '(??)';
				}
			}
			if (this.section.type == 'completed' && this.section.arg) {
				return '완료된 일';
			}
			if (this.section.type == 'completed') {
				return;
			}
			if (this.section.type == 'day') {
				return (new Date(this.section.arg)).toLocaleDateString('ko-KR');
			}
		},

		// 목록 대신 보여줄 메시지
		altMessage() {
			if (this.section.tasks.length > 0) {
				return;
			}
			if (this.section.type == 'completed' && !this.section.arg) {
				if (this.store.main.countTasks() > 0) {
					return '모든 작업을 완료했습니다! :)';
				} else {
					return '등록된 작업이 없습니다.';
				}
			}
		}
	},

	watch: {
		'store.main.sortType'(v) {
			this.setupSortable();
		}
	},
	
	created() {
		this.xhrSchedules = {
			sortTasks: fn.singleXhr('abort')	
		};
	},
	
	mounted() {
		this.setupSortable();
	},

	methods: {
		setupSortable() {
			if (this.store.main.sortType == 'user' && this.store.main.loader && this.store.main.loader.idx) {
				$(this.$refs.list).sortable({
					delay: 300,
					onDrop: ($item, container, _super, event) => {
						_super($item, container);
						let indices = _.map(this.$refs.list.children, (el) => el.getAttribute('data-index'));
						let tasks = _.map(indices, (i) => this.section.tasks[i]);
						this.section.tasks = tasks;
						if (this.store.main == this.store.listSections && this.store.main.loader.idx) {
							let idxes = _.pluck(this.section.tasks, 'idx');
							this.xhrSchedules.sortTasks(() => this.store.api.sortTasks(idxes));				
						}
					}
				});			
			} else {
				$(this.$refs.list).sortable('destroy');
			}			
		},		
	}
}));
