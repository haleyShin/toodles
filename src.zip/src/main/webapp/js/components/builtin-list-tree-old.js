ToodleVue.component('builtin-list-tree', ToodleVue.component('tree').extend({
	components: {
		'node': {
			name: 'node',
			template: '#t-builtin-list-node',
			props: ['node'],
			computed: {
				icon() {
					if (this.node.type == 'folder') {
						return 'folder';
					} else {
						if (this.node.memberCount > 0) {
							return 'user-many';
						} else {
							return 'list';
						}
					}
				}
			},
			methods: {
				accept() {
					this.$root.api.acceptInvitation(this.node.idx).then(() => {
						
					});
				},
				reject() {
					this.$root.api.rejectInvitation(this.node.idx).then(() => {
						
					})
				}
			}
		}
	},

	created: function() {
		var invitations = this.root.appendChild(this.createNode({
			name:'초대함',
			icon:'envelope',
			isCollapsed:true,
			type:'list'
		}));

		this.$root.api.invitations().then((lists) => {
			lists.forEach((list) => {
				invitations.appendChild(this.createNode({
					idx: list.idx,
					name: list.name,
					icon: 'envelope-open',
					isCollapsed:false,
					type:'invitedList',
				}))
			});	
		});

		this.root.appendChild(this.createNode({
			name:'임시보관함',
			icon:'inbox',
			isCollapsed:false,
			type:'list'
		}))
		this.root.appendChild(this.createNode({
			name:'달력보기',
			icon:'calendar-table',
			isCollapsed:false
		}))
		var timetask = this.root.appendChild(this.createNode({
			name:'기간별 할 일',
			icon:'calendar-empty',
			isCollapsed:true
		}));
			
		timetask.appendChild(this.createNode({
			name:'지난 할 일',
			icon:'calendar-x',
			isCollapsed:false,
			type:'list'
		}));
		timetask.appendChild(this.createNode({
			name:'오늘 할 일',
			icon:'calendar-25',
			isCollapsed:false,
			type:'list'
		}));
		timetask.appendChild(this.createNode({
			name:'주간 할 일',
			icon:'calendar-list',
			isCollapsed:false,
			type:'list'
		}));
		
		this.root.appendChild(this.createNode({
			name:'중요한 일',
			icon:'star-empty',
			isCollapsed:false,
			type:'list'
		}));
		this.root.appendChild(this.createNode({
			name: '내가 담당하는 일',
			icon: 'user',
			isCollapsed: false,
			type:'list'
		}))
	},
	
}));
