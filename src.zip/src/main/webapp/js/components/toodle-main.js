ToodleVue.component('toodle-main', ToodleVue.extend({
	template: '#t-toodle-main',
	props: {
		store: Object
	},
	data() {
		return {
			taskInput: '',
			sortMode: 'user'
		}
	},
	watch: {
		'store.main.loaded'() {
			Vue.nextTick(() => {
				$(this.$refs.input).atwho({
					at: '#',
					data: 'api/hashtags',
					limit: 200,
					callbacks: {
						matcher(flag, subtext) {
							let rindex = subtext.lastIndexOf('#');
							if (rindex < 0) {
								return;
							}

							let patt, match;
							patt = /[0-9a-zA-Z가-힣]+$/g;
							patt.lastIndex = rindex + 1;
							match = patt.exec(subtext);
							if (match) {
								return match[0];
							} else {
								return;
							}
						}
					}
				});				
			});
		}
	},
	computed: {
		title() {
			if (this.store.main == this.store.search) {
				return this.store.search.keyword;
			} else {
				return fn.maybe(this.store.main)('loader')('name')();
			}
		},
		note() {
			if (this.store.main == this.store.search) {
				return null;
			} else {
				return fn.maybe(this.store.main)('loader')('note')();
			}
		},
		taskCount() {
			return this.store.main.countTasks();
		}
	},
	created() {
		let reloadHashtagsBound = this.reloadHashtags.bind(this);
		this.store.events.$on('on-task-deletion', reloadHashtagsBound);
		this.store.events.$on('on-task-update', reloadHashtagsBound);
	},
	methods: {
		reloadHashtags: _.debounce(function() {
			if (this.$refs.input) {
				$(this.$refs.input).data('atwho').controllers['#'].model.reload("api/hashtags");
			}
		}, 500),
		
		showInboxGoingTask(task) {
			let inboxNode = document.getElementById('inbox-node');
			let initialOffset = $(this.$refs.input).offset();
			let targetOffset = $(inboxNode).offset();
			let dLeft = targetOffset.left + ($(inboxNode).width() / 2) - initialOffset.left;
			let dTop = targetOffset.top - initialOffset.top;

			let div = document.body.appendChild(document.createElement('div'));
			div.textContent = task.name;
			div.className = 'inbox-going';
			div.style.transition = '2s ease';
			div.style.transform = 'translate(0,0)';
			div.style.position = 'absolute';
			div.style.opacity = 1;
			div.style.left = initialOffset.left + 'px';
			div.style.top = initialOffset.top + 'px';
			
			setTimeout(() => {
				div.style.transform = 'translate('+dLeft+'px,'+dTop+'px)';
				div.style.opacity = 0;
			}, 100);
			setTimeout(() => {
				div.parentNode.removeChild(div);
			}, 2100);
			setTimeout(() => {
				inboxNode.classList.add('is-highlighted');
				setTimeout(() => {
					inboxNode.classList.remove('is-highlighted');					
				}, 1000);				
			}, 0);
		},

		addTask() {
			this.store.addTask({name: this.taskInput}).then((task) => {
				if (!this.store.findTaskByIdx(task.idx)) {
					this.showInboxGoingTask(task);
				}
			});
			this.taskInput = '';
		},
		
		openListEdit() {
			this.bus.$emit('app.navigate', null, {edit: this.store.main.loader.idx, editUser: 1}, null);
		},
		
		showSortMenu() {
			let el = this.$refs.sortIcon;
			let offsets = $(el).offset();
			let width = $(el).width();
			let height = $(el).height();
			this.bus.$emit('app.contextmenu', {
				clientX: offsets.left,
				clientY: offsets.top + height
			}, [
				{icon: 'arrows-v', name: '사용자 정의', action: () => {
					this.store.main.setSortType('user');
				}},
				{icon: 'sort-alpha-asc', name: '이름순(오름차순)', action: () => {
					this.store.main.setSortType('name-asc');
				}},
				{icon: 'sort-alpha-desc', name: '이름순(내림차순)', action: () => {
					this.store.main.setSortType('name-desc');
				}},
				{icon: 'star-o', name: '중요 표시순', action: () => {
					this.store.main.setSortType('importance');
				}},
				{icon: 'sort-numeric-asc', name: '마감순', action: () => {
					this.store.main.setSortType('dueDatetime');
				}}
			]);
		}
	}
}));
