ToodleVue = Vue.extend();
ToodleVue.component('tree', ToodleVue.extend({
	template: '<ul class="list-tree"><node v-for="node of root.children" v-bind:node="node" :key="node.id"></node></ul>',
	data() {
		return new Tree();
	},
	methods: Tree.prototype
}));
