ToodleVue.component('user-profile', ToodleVue.extend({
	template: '#t-user-profile',
	props: {
		store: Object
	},
	methods: {
		showUserMenu() {
			let el = this.$refs.cogIcon;
			let offsets = $(el).offset();
			this.bus.$emit("app.contextmenu", {
				clientX: offsets.left,
				clientY: offsets.top + 24
			}, [
				{name: '프로필 수정', action: () => {
					this.bus.$emit("app.navigate", null, {editMe: 1}, true);
				}},
				{name: 'Toodle 설정', action: () => {
					this.bus.$emit("app.alert", "준비중입니다.^^;");
				}},
				{name: '만든 사람들', action: () => {
					this.bus.$emit("app.alert", "KH 정보교육원 3조");
				}},
				{name: '로그아웃', action: () => {
					location.href = "logout.do";
				}}
			])
		}
	}
}));
