ToodleVue.component('task-editor', ToodleVue.extend({
	template: '#t-task-editor',
	props: {
		store: Object,
		loaded: Boolean,
		selectedTask: Object,
	},

	data() {
		return {
			input: {
				name: undefined,
				important: false,
				completed: false,
				description: undefined,
				dueDatetime: undefined,
				remindDatetime: undefined,
			},
			attachments: [],
			uploads: [],
			comments: [],
			subtaskInput: '',
			commentInput: ''
		}
	},
	watch: {
		input: {
			handler(v) {
				if (this.initialized) {
					this.dirty = false;
				}
			},
			deep: true
		}
	},

	created() {
		this.api = this.store.api;
		this.initialized = false;
		this.xhrSchedules = {
			syncComment: fn.singleXhr('abort')
		};

		this.onCommentSync = (taskIdx, extra) => {
			if (this.selectedTask.idx != taskIdx) {
				return;
			}
			let op = extra.substr(0, 1);
			let idx = extra.substr(1);
			switch (op) {
				case 'i':
					this.xhrSchedules.syncComment(() => this.api.getComment(this.selectedTask.idx, idx)).then((comment) => {
						let index = _.sortedIndex(this.comments, comment, "createdAt");
						this.comments.splice(index, 0, comment);
					});
					break;
				case 'd':
					let comment = _.findWhere(this.comments, {idx});
					if (comment) {
						fn.remove(this.comments, comment);
					}
					break;
				default:
					console.warn("unknown extra message: " + extra);
			}
		}
	},

	beforeDestroy() {
		this.bus.$off("task-editor.comment-sync", this.onCommentSync);
	},

	mounted() {
		this.duePicker = new Flatpickr(this.$refs.due);
		this.reminderPicker = new Flatpickr(this.$refs.remind, {
			enableTime: true,
			minDate: 'today'
		});		
		this.initialize();
	},

	beforeDestroy() {
		if (this.dirty) {
			this.bus.$emit("app.task-update", this.selectedTask, this.input);
		}
	},

	methods: {
		upload() {
			if (this.$refs.fileInput.length < 1) {
				return;
			}

			let upload = {
				name: this.$refs.fileInput.files[0].name,
				progress: 0
			};

			this.store.api.addAttachment(this.selectedTask.idx, this.$refs.fileInput, (xhr) => { 
				upload.xhr = xhr;
			},(done, total) => {
				upload.progress = done / total;
			}).then((response) => {
				this.uploads.splice(this.uploads.indexOf(upload), 1);
				this.attachments.push(response);
				this.bus.$emit('app.task-sync-counts', this.selectedTask);
			}, (xhr) => {
				this.bus.$emit('app.alert', '파일 업로드 중 오류가 발생했습니다');
			});

			this.uploads.push(upload);
			this.$refs.fileInput.value = null;
		},

		cancelUpload(upload) {
			upload.xhr.abort();
			fn.remove(this.uploads, upload);
		},

		removeAttachment(attachment) {
			fn.remove(this.attachments, attachment);
			this.store.api.deleteAttachment(attachment.taskIdx, attachment.idx).then(() => {
				this.bus.$emit('app.task-sync-counts', this.selectedTask);
			});
		},

		initialize() {
			this.initialized = false;
			this.dirty = false;

			_.extend(this.input, this.selectedTask);
			Vue.nextTick(() => {
				if (this.selectedTask.dueDatetime) {
					let d = new Date(this.selectedTask.dueDatetime);
					this.duePicker.setDate(d);
					this.input.dueDatetime = this.duePicker.formatDate(d, 'Y-m-d');
				} else {
					this.duePicker.clear();
				}

				if (this.selectedTask.remindDatetime) { 
					let d = new Date(this.selectedTask.remindDatetime)
					this.reminderPicker.setDate(d);
					this.input.remindDatetime = this.reminderPicker.formatDate(d, 'Y-m-d H:i'); 
				} else {
					this.reminderPicker.clear();
				}
				this.store.api.getAttachments(this.selectedTask.idx).then((attachments) => {
					this.attachments.push.apply(this.attachments, attachments);
				});
				this.store.api.getComments(this.selectedTask.idx).then((comments) => {
					this.comments.push.apply(this.comments, comments);
					this.bus.$on("task-editor.comment-sync", this.onCommentSync);
				});
				this.initialized = true;
			});
		},
		addComment() {
			if (this.initialized && this.commentInput) {
				this.store.api.addComment(this.selectedTask.idx, this.commentInput).then((comment) => {
					this.comments.push(comment);
					this.bus.$emit('app.task-sync-counts', this.selectedTask);
				});
				this.commentInput = '';
			}
		},
		removeComment(comment) {
			fn.remove(this.comments, comment);
			this.store.api.deleteComment(this.selectedTask.idx, comment.idx).then(() => {
				this.bus.$emit('app.task-sync-counts', this.selectedTask);
			});
		},

		onChange(event) {
			if (this.initialized) {
				let change = {};
				this.input[event.target.name] = change[event.target.name] = event.target.value;
				this.bus.$emit('app.task-update', this.selectedTask, change);
				this.dirty = false;
			}
		},
		updateImportant() {
			this.bus.$emit('app.task-update', this.selectedTask, {important: this.input.important});
		},
		updateCompleted() {
			this.bus.$emit('app.task-update', this.selectedTask, {completed: this.input.completed});
		}
	}
}));
