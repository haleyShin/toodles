ToodleVue.component('stale-reminders', ToodleVue.extend({
	template: '#stale-reminders',
	props: {
		store: Object
	},
	data() {
		return {
			loaded: false,
			show: false,
			reminders: []
		}
	},
	watch: {
		show(v) {
			if (v) {
				$(document).one('click', () => this.show = false);
			}
		}
	},
	created() {
		this.xhrSchedules = {
			reload: fn.singleXhr('abort')	
		};
		// TODO: 보일 때 reload하게 하기?
		let boundReload = this.reload.bind(this);
		this.store.events.$on('on-list-deletion', boundReload);
		this.store.events.$on('on-task-update', boundReload);
		this.store.events.$on('on-task-deletion', boundReload);
		this.bus.$on('stale-reminders.reload', boundReload);
		boundReload();
	},
	methods: {
		reload: _.debounce(function() {
			this.store.ready.then(() => {
				this.store.api.staleReminders().then((reminders) => {
					reminders.forEach((reminder) => {
						reminder.listNode = this.store.userListTree.getListNodeByIdx(reminder.listIdx);				
					});
					this.reminders = reminders;
					this.loaded = true;
				});
			});	
		}, 1000)
	}
}));
