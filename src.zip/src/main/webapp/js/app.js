toodleApp = new ToodleVue({
	el: '#app',
	data: {
		store,
		searchInput: "",
		searchFieldSelect: "",
		contextmenuItems: []
	},
	computed: {
		searchFields() {
			return (this.searchFieldSelect) ? [this.searchFieldSelect] : ['taskName', 'subtaskName', 'taskDescription']
		}
	},
	watch: {
		'store.taskEditor.selectedTask'(v) {
			if (!v) {
				Finch.navigate(null, {task: undefined}, true);
			}
		}
	},

	created() {
		this.prepareRoutes();
		this.listenBus();
		this.store.init().then(() => {
			this.listenRoutes();
			
			// sync
			let subscription;
			this.stompClient = Stomp.over(new SockJS("sync"));
			this.stompClient.connect({}, () => {
				subscription = this.stompClient.subscribe('/topic/sync/' + this.store.me.idx,
					this.onSyncMessage.bind(this),
					this.onSyncError.bind(this)
				);
			}, (error) => {
				console.log(error);
			});

			window.addEventListener('beforeunload', () => {
				if (subscription) {
					subscription.unsubscribe();
				}
				this.stompClient.disconnect();
			});
		});
		
		this.debouncedSearch = _.debounce(() => {
			if (this.searchInput) {
				Finch.navigate(null, {search: this.searchInput, fields: this.searchFieldSelect, task: undefined}, true);				
			} else {
				Finch.navigate(null, {search: undefined, fields: undefined, task: undefined}, true);
			}
		}, 1000);
	},
	methods: {		
		onSyncMessage(message) {
			let [entity, type, idx, extra] = message.body.split(" ");
			switch (entity + " " + type) {
				case "list insert": this.store.loadInvitations(); break;
				case "list update": this.store.syncList(idx); break;
				case "list delete": this.store.syncDeletedList(idx); break;
				case "task insert":
					this.store.syncNewTask(idx);
					this.bus.$emit("notices.reload");
					break;
				case "task update":
					this.store.syncTask(idx);
					this.bus.$emit("notices.reload");
					break;
				case "task delete": this.store.syncDeletedTask(idx); break;
				case "task assign":
					this.store.syncTask(idx);
					this.bus.$emit("notices.reload");
					break;
				case "task comment":
					this.bus.$emit("task-editor.comment-sync", idx, extra);
					this.bus.$emit("notices.reload");
					this.store.syncEntityCountsByIdx(idx);
					break;
				case "task attachment":
					this.bus.$emit("notices.reload");
					this.store.syncEntityCountsByIdx(idx);
					break;
				case "task subtask":
					this.bus.$emit("notices.reload");
					this.store.syncEntityCountsByIdx(idx);
					break;
				case "task reminder": 
					this.showReminderNotification(idx);
					this.bus.$emit("stale-reminders.reload");
					break;
				default:
					console.warn("failed to parse sync message: " + message.body);
			}
		},
		onSyncError(error) {
			
		},

		showReminderNotification(idx) {
			Notification.requestPermission().then((permission) => {
				if (permission != 'granted') {
					return;
				}
				this.store.api.getTask(idx).then((data) => {
					let notification = new Notification('Toodle 알림', {
						body : data.name,
						icon : 'img/simbol.png',
						tag: 'task' + idx
					});
					notification.onclick = () => {
						Finch.navigate("/list/" + data.listIdx, {task: idx});
					};
					setTimeout(() => {
						notification.close();
					}, 10000);				
				});
			});
		},

		listenBus() {
			this.bus.$on('app.alert', (message) => {
				this.alert(message);
			});
			this.bus.$on('app.contextmenu', (event, items) => {
				if (event instanceof Event) {
					event.preventDefault();
					event.stopPropagation();					
				}
				this.contextmenuItems = items;
				this.$refs.contextmenu.display({x: event.clientX, y: event.clientY});
			});
			this.bus.$on('app.list-accept', (idx) => {
				this.store.acceptList(idx);
			});
			this.bus.$on('app.list-clean', (idx) => {
				this.store.userListTree.removeListNodeByIdx(idx);
			});
			this.bus.$on('app.list-delete', (idx) => {
				this.confirm("정말로 삭제하시겠습니까?", (yes) => {
					if (yes) {
						this.store.api.deleteList(idx).then(() => {
							let node = this.store.userListTree.removeListNodeByIdx(idx);
							if (node == this.store.main.loader) {
								this.bus.$emit('app.navigate', '/list/inbox');
							}
						}, (xhr) => {
							this.alert("목록을 삭제하는 도중 오류가 발생했습니다.");
						});
					}
				});
			});

			this.bus.$on('app.list-edit', (idx, editUser) => {
				this.store.api.getList(idx).then((list) => {
					this.showModal(ToodleVue.component('list-edit-modal'), {list, editUser});
				}, (xhr) => {
					// 실패시
				});
			});
			this.bus.$on('app.list-new', () => {
				this.showModal(ToodleVue.component('list-edit-modal'), {
					list: {
						name: '',
						folder: '',
						userState: 'owner'						
					}
				});
			});
			this.bus.$on('app.list-reject', (idx) => {
				this.store.rejectList(idx);
			});
			this.bus.$on('app.list-update', (data) => {
				this.store.userListTree.updateListNode(data);
			});
			this.bus.$on("app.me-edit", () => {
				this.showModal(ToodleVue.component('me-edit-modal'), {
					me: this.store.me
				});
			});
			this.bus.$on('app.navigate', (route, params, doUpdate) => {
				Finch.navigate(route, params, doUpdate);
			});
			this.bus.$on('app.task-click', (task, event) => {
				let hasModifier = event.ctrlKey || event.shiftKey;
				let selectedTask = this.store.taskEditor.selectedTask;
				let alreadySelected = (selectedTask == task); 
				if (selectedTask) {
					if (alreadySelected) {
						if (hasModifier) {
							// pass
						} else {
							this.store.selection.reset();
							Finch.navigate(null, {task: undefined}, true);
						}
					} else {
						if (hasModifier) {
							this.store.selection.reset();
							this.store.selection.add(selectedTask);
							if (event.shiftKey) {
								this.store.selectRange(task);
								document.getSelection().removeAllRanges();
							} else {
								this.store.selection.add(task);								
							}
							Finch.navigate(null, {task: undefined}, true);
						} else {
							this.store.selection.reset();
							Finch.navigate(null, {task: task.idx}, true);
						}
					}
				} else {
					if (hasModifier) {
						if (event.shiftKey) {
							this.store.selectRange(task);
							document.getSelection().removeAllRanges();
						} else {
							this.store.selection.toggle(task);
						}
					} else {
						this.store.selection.reset();
						Finch.navigate(null, {task: task.idx}, true);
					}
				}
			});
			this.bus.$on('app.task-clone', (task, updates) => {
				this.store.cloneTasks([task], updates);
			});
			this.bus.$on('app.task-clone-selection', (updates) => {
				this.store.cloneTasks(this.store.selection.items, updates);
				this.store.selection.items.splice(0, this.store.selection.items.length);
			});
			this.bus.$on('app.task-delete', (task) => {
				this.store.deleteTasks([task]);
			});
			this.bus.$on('app.task-delete-selection', () => {
				this.store.deleteTasks(this.store.selection.items);
				this.store.selection.items.splice(0, this.store.selection.items.length);
			});
			this.bus.$on('app.task-sync-counts', (task) => {
				this.store.syncEntityCounts(task);
			});
			this.bus.$on('app.task-update', (task, updates) => {
				this.store.updateTask(task, updates);
			});
			this.bus.$on('app.task-update-selection', (updates) => {
				this.store.updateTasks(this.store.selection.items, updates);
				this.store.selection.items.splice(0, this.store.selection.items.length);
			});
		},
		
		prepareRoutes() {
			let currentMenuItem = {};

			Finch.route("/", () => {
				Finch.navigate("/list/inbox");
			});

			Finch.route("/list/daterange", () => {
				Finch.observe("dateFrom", "dateTo", (dateFrom, dateTo) => {
					if (!dateFrom || !dateTo) {
						this.showModal(ToodleVue.component('daterange-modal').extend({
							methods: {
								onApply(dateFrom, dateTo) {
									Finch.navigate(null, {dateFrom: fn.iso8601date(dateFrom), dateTo: fn.iso8601date(dateTo)}, false);
								},
								onCancel() {
									history.go(-1);
								}
							}
						}));						
					} else {
						this.store.nodes.daterange.dateFrom = Flatpickr.prototype.parseDate(dateFrom, 'Y-m-d');
						this.store.nodes.daterange.dateTo = Flatpickr.prototype.parseDate(dateTo, 'Y-m-d');
						currentMenuItem.isSelected = false;
						currentMenuItem = this.store.nodes.daterange;
						currentMenuItem.isSelected = true;
						this.store.main = this.store.listSections;
						this.store.main.loader = currentMenuItem;
						this.store.main.setSortType('dueDatetime');
						this.observeTaskParam(this.store.main.loadSections());
						this.observeOtherParams();
					}
				});
			});

			Finch.route("/list/:name", (params) => {
				let node, sortType = 'user';
				switch (params.name) {
					case 'inbox': node = this.store.nodes.inbox; break;
					case 'importants': node = this.store.nodes.importants; break;
					case 'assignments':  node = this.store.nodes.assignments; break;
					case 'today': node = this.store.nodes.today; break;
					case 'overdue':
						node = this.store.nodes.overdue;
						sortType = 'dueDatetime';
						break;
					case 'thisWeek': node = this.store.nodes.thisWeek; break;
					case 'daterange':
						node = this.store.nodes.daterange;
						sortType = 'dueDatetime';
						break;
					default:
						node = this.store.userListTree.getListNodeByIdx(params.name);
				}

				if (!node) {
					this.store.main.error = "목록 정보를 불러올 수 없습니다.";
				} else {
					currentMenuItem.isSelected = false;
					currentMenuItem = node;
					currentMenuItem.isSelected = true;
					this.store.main = this.store.listSections;
					this.store.main.loader = currentMenuItem;
					this.store.main.setSortType(sortType);
					this.observeTaskParam(this.store.main.loadSections());
				}
				this.observeOtherParams();					
			});

			Finch.route("/calendar/:year/:month", (params) => {
				this.store.unloadTaskEditor();

				currentMenuItem.isSelected = false;
				currentMenuItem = this.store.nodes.calendar;
				currentMenuItem.isSelected = true;

				this.store.main = this.store.calendar;
				this.store.main.year = params.year || (new Date()).getFullYear();
				this.store.main.month = params.month || (new Date()).getMonth() + 1;
				this.store.main.loadSections();
				this.observeOtherParams();
			});
		},

		observeTaskParam(mainLoaded) {
			Finch.observe('task', (taskIdx) => {
				if (taskIdx) {
					mainLoaded.then(() => {
						this.store.loadTaskEditor(taskIdx);
					});
				} else {
					this.store.unloadTaskEditor();						
				}
			});			
		},

		observeOtherParams() {
			Finch.observe('edit', 'create', 'editUser', 'editMe', (edit, create, editUser, editMe) => {
				if (editMe) {
					this.bus.$emit("app.me-edit");
					return;
				}
				if (edit) {
					this.bus.$emit("app.list-edit", edit, !!editUser);	
				} else {
					if (create) {
						this.bus.$emit("app.list-new");						
					}
				}
			});

			let previousMain = this.store.main;
			Finch.observe('search', 'fields', (search, fields) => { 
				if (search) {
					this.searchInput = search;
					this.searchFieldSelect = fields;
					this.store.search.keyword = search;
					this.store.search.fields = this.searchFields;
					this.store.main = this.store.search;
					this.store.main.setSortType('name-asc');
					this.store.main.loadSections();
				} else {
					this.searchInput = '';
					this.store.search.keyword = null;
					this.store.main = previousMain;
				}
			});
		},

		listenRoutes() {
			Finch.listen();
		},

		alert(message) {
			vex.dialog.alert(message);
		},

		confirm(question, callback) {
			vex.dialog.confirm({
				message: question,
				callback: callback
			});
		},

		showModal(ModalComponent, propsData) {
			let popup;
			vue = new ModalComponent({
				el: document.createElement('div'),
				propsData: _.extend({
					store: this.store,
					bus: this.bus
				}, propsData),
				methods: {
					close() {
						popup.close();
					}
				}
			});
			popup = vex.open({
				unsafeContent: vue.$el,
				beforeClose() {
					vue.beforeClose()
				},
				afterOpen() {
					vue.afterOpen();
				}
			});
		},

		hideContextmenu: _.debounce(function() {
			this.$refs.contextmenu.hide();	
		}, 100, true),
		
		onSearchInput() {
			this.debouncedSearch();
		},
		onSearchFieldChange() {
			if (this.searchInput) {
				Finch.navigate(null, {search: this.searchInput, fields: this.searchFieldSelect, task: undefined}, true);				
			}			
		}
	}
});
