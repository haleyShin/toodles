(() => {

let api = new Toodle(document.getElementById('baseurl').content);

let storeEvents = new Vue();

function Task(attrs) {
	_.extend(this, attrs);
	this.editing = false;
	this.inSelection = false;
	this.attachments = 0;
	this.comments = 0;
	this.subtasks = 0;
	this.subtasksDone = 0;
}

function ListSection(attrs) {
	this.tasks = [];
	_.extend(this, attrs);
	this.tasks = this.tasks.map((t) => new Task(t));
}

ListSection.prototype = {
	findTaskByIdx(idx) {
		for (let task of this.tasks) {
			if (task.idx == idx) {
				return task;
			}
		}
	},
	contains(task) {
		return this.tasks.indexOf(task) > -1;
	},
	remove(task) {
		return fn.remove(this.tasks, task);
	},
	push(task) {
		this.tasks.push(task);
	},
	unshift(task) {
		this.tasks.unshift(task);
	}
};

let selection = {
	items: [],
	size() {
		return this.items.length;
	},
	reset() {
		this.items.forEach((item) => item.inSelection = false);
		this.items.splice(0, this.items.length);
	},
	contains(item) {
		return !(this.item.indexOf(item) < 0);
	},
	toggle(item) {
		let index = this.items.indexOf(item);
		if (index < 0) {
			this.items.push(item);
			item.inSelection = true;
		} else {
			this.items.splice(index, 1);
			item.inSelection = false;
		}
	},
	add(item) {
		if (this.items.indexOf(item) < 0) {
			item.inSelection = true;
			this.items.push(item);
		}
	},
	remove(item) {
		let index = this.items.indexOf(item);
		if (index >= 0) {
			item.inSelection = false;
			this.items.splice(index, 1);
		}
	}
};


let mainView = {
	sortMode: undefined,
	loadSections() {
		this.loaded = false;
		this.error = "";
		return this.requestSections().then((sections) => {
			this.sections = sections.map((s) => new ListSection(s));
			this.sections.forEach((section) => section.tasks.sort(this.cmp));

			// TODO: 다른 곳으로 옮기기
			this.sections.forEach((section) => {
				if (section.tasks.length) {
					api.countEntities(section.tasks.map((t) => t.idx)).then((resp) => {
						section.tasks.forEach((task) => {
							if (task.idx in resp) {
								_.extend(task, resp[task.idx]);
							}
						});
					});				
				}
			});

			
		}, (xhr) => {
			if (xhr.status) {
				// TODO: handle error
				this.error = '서버에 오류가 발생했습니다.(응답코드:' + xhr.status + ')';				
			}

		}).always(() => {
			this.loaded = true;
		});
	},
	findTaskByIdx(idx) {
		for (let section of this.sections) {
			for (let task of section.tasks) {
				if (task.idx == idx) {
					return task;
				}
			}
		}
	},
	findSectionByTask(task) {
		for (let section of this.sections) {
			if (section.contains(task)) {
				return section;
			}
		}
	},
	appendSection(type, arg) {
		let newSection = new ListSection({type, arg});
		this.sections.push(newSection);
		return newSection;
	},

	setSortType(type) {
		let cmp;
		switch (type) {
			case 'user': cmp = (a, b) => b.ord - a.ord; break;
			case 'name-asc': cmp = (a, b) => fn.strcmp(a.name, b.name); break;
			case 'name-desc': cmp = (a, b) => fn.strcmp(b.name, a.name); break;
			case 'importance': cmp = (a, b) => (b.important - a.important) || (b.ord - a.ord); break;
			case 'dueDatetime': cmp = (a, b) => ((a.dueDatetime || -99999) - (b.dueDatetime || -99999)) || (b.ord - a.ord); break;
			default:
				throw 'invalid sort type';
		}
		this.sortType = type;
		this.cmp = cmp;
		this.sections.forEach((section) => section.tasks.sort(this.cmp));
	},

	sortType: null,
	cmp: (a, b) => b.ord - a.ord,

	insortTask(section, task) {
		fn.remove(section.tasks, task);
		fn.insort(section.tasks, task, this.cmp);
	},

	handleDeletedList(list) {
		let section = _.findWhere(this.sections, {type: 'list', arg: list.idx});
		if (section) {
			fn.remove(this.sections, section);
		} else {
			this.sections.forEach((section) => {
				fn.removeMany(section.tasks, section.tasks.filter((t) => t.listIdx == list.idx));
			});
		}
		storeEvents.$emit("on-list-deletion", list);
	},

	requestSections() {
		let d = $.Deferred();
		d.resolve([]);
		return d;
	},
	countTasks() {
		return _.reduce(this.sections, (sum, section) => sum + section.tasks.length, 0);
	},
	beforeAddTask(task) {
		
	},
	handleDeletedTask(task) {
		for (let section of this.sections) {
			fn.remove(section.tasks, task);
		}
		storeEvents.$emit("on-task-deletion", task);
	},
	handleTaskUpdate(task, mode) {
		storeEvents.$emit("on-task-update", task, mode);
	}
};

let listSections = (function() {
	let loader = ListSectionLoader;
	let xhrSchedule = fn.singleXhr('abort');
	let obj = _.extend(Object.create(mainView), {
		sortType: undefined,
		loaded: false,
		error: null,
		sections: [],
		requestSections() {
			return xhrSchedule(() => loader.requestSections());
		},
		handleDeletedList(list) {
			mainView.handleDeletedList.apply(this, arguments);
			loader.handleDeletedList(this, list);
		},
		beforeAddTask(task) {
			loader.beforeAddTask(task);
		},
		handleTaskUpdate(task, mode) {
			mainView.handleTaskUpdate.apply(this, arguments);
			return loader.handleTaskUpdate(this, task, mode);
		}
	});

	// loader lifecycle hook	
	Object.defineProperty(obj, 'loader', {
		configurable: true,
		enumerable: true,
		get: () => loader,
		set(newLoader) {
			if (loader != newLoader) {
				loader.unloaded();
				loader = newLoader;
				newLoader.beforeLoad();				
			}
		}
	});
	return obj;
})();

let calendar = _.extend(Object.create(mainView), {
	loaded: false,
	error: null,
	sections: [],
	year: (new Date()).getFullYear(),
	month: (new Date()).getMonth() + 1,
	date: null,
	loadSections() {
		let deferred = $.Deferred();
		let date = new Date();
		if (isNaN(date.setFullYear(this.year))) {
			deferred.reject({message: this.error = "invalid year: " + this.year});
			return deferred;
		}

		let monthNumber = parseInt(this.month, 10);
		if (isNaN(monthNumber) || monthNumber < 1 || 12 < monthNumber) {
			deferred.reject({message: this.error = "invalid month: " + this.month});
			return deferred;
		}

		deferred.resolve([]);

		this.error = "";
		date.setMonth(this.month - 1);
		date.setDate(1);
		this.date = date;

		return deferred;
	}
});

let search = (function () {
	let xhrSchedule = fn.singleXhr('abort');
	return _.extend(Object.create(mainView), {
		sortType: undefined,
		loaded: false,
		error: null,
		sections: [],
		keyword: '',
		fields: [],
		requestSections() {
			return xhrSchedule(() => api.search(this.keyword, this.fields));
		},
		handleTaskUpdate(task, mode) {
			mainView.handleTaskUpdate.apply(this, arguments);			
			return api.match(task.idx, this.keyword, this.fields).then((match) => {
				let currentSection = this.findSectionByTask(task);
				if (match) {
					let rightSection = _.findWhere(this.sections, {type: 'list', arg: task.listIdx});
					if (!rightSection) {
						rightSection = this.appendSection('list', task.listIdx);
					}
					if (currentSection != rightSection) {
						if (currentSection) {
							currentSection.remove(task);							
						}
						rightSection.unshift(task);				
					}
				} else {
					if (currentSection) {
						currentSection.remove(task); 
					}
				}
			});
		}
	});
})();

let userListTree = new UserListTree(api);
let builtInListTree = new BuiltInListTree(api);

window.store = {
	api,
	events: storeEvents,
	userListTreeLoaded: false,
	userListTree,
	builtInListTree,

	/* main views */
	search,
	listSections,
	calendar,

	/* main view ref */
	main: listSections,

	me: {
		idx: null,
		name: null,
		email: null,
		photo: null,
		inboxIdx: null,
		updatedAt: null
	},

	selection,

	taskEditor: {
		loaded: false,
		selectedTask: null,
	},
	
	nodes: {},
	
	xhrSchedules: {
		loadTask: fn.singleXhr('abort'),
		loadInvitations: fn.singleXhr('abort'),
		syncTask: fn.limitParallelXhr(2),
		syncList: fn.limitParallelXhr(2),
		syncEntityCounts: fn.limitParallelXhr(2) 
	},


	init() {
		this.userListTreeLoaded = false;
		let gotUserLists = this.userListTree.loadTree();
		let gotMe = this.loadMe();

		let builtIn = this.builtInListTree;
		this.nodes.invitements = builtIn.root.appendChild(builtIn.createNode('folder', '초대함', 'envelope', {iconClass:'text-brand'}));
		this.nodes.inbox = builtIn.root.appendChild(builtIn.createNode('inbox', this.api));
		this.nodes.importants = builtIn.root.appendChild(builtIn.createNode('importants', this.api));
		this.nodes.assignments = builtIn.root.appendChild(builtIn.createNode('assignments', this.api));
		
		this.nodes.calendar = builtIn.root.appendChild(builtIn.createNode('calendar'));
		let dateFilters = builtIn.root.appendChild(builtIn.createNode('folder', '기간별 보기', 'calendar-empty', {isCollapsed: true}));
		this.nodes.today = dateFilters.appendChild(builtIn.createNode('date-filter', this.api, {
			icon: 'calendar-25',
			route: '/list/today',
			name: '오늘 마감',
			params: () => {
				return {
					dateFrom: fn.iso8601date(new Date()),
					dateTo: fn.iso8601date(fn.nextDay(new Date())),
					group: 'list'
				}
			}
		}));
		this.nodes.overdue = dateFilters.appendChild(builtIn.createNode('date-filter', this.api, {
			icon: 'calendar-x',
			route: '/list/overdue',
			name: '마감 지남',
			params: () => {
				return {
					dateTo: fn.iso8601date(new Date()),
					group: 'list'
				}
			}
		}));
		this.nodes.thisWeek = dateFilters.appendChild(builtIn.createNode('date-filter', this.api, {
			icon: 'calendar-list',
			route: '/list/thisWeek',
			name: '이번 주',
			params: () => {
				return {
					dateFrom: fn.iso8601date(fn.weekStart(new Date())),
					dateTo: fn.iso8601date(fn.weekEnd(new Date())),
					group: 'daily'
				}
			}
		}));
		this.nodes.daterange = dateFilters.appendChild(builtIn.createNode('date-filter', this.api, {
			icon: 'calendar-empty',
			route: '/list/daterange',
			name: '기간 선택',
			params() {
				return {
					dateFrom: fn.iso8601date(this.dateFrom),
					dateTo: fn.iso8601date(fn.nextDay(this.dateTo)),
					group: 'list'
				}
			},
			unloaded() {
				this.name = '기간 선택';
				this.note = undefined;
			},
			beforeLoad() {
				this.name = '기간';
				if (this.dateTo.getTime() - this.dateFrom.getTime() <= 24 * 60 * 60 * 1000) {
					this.note = '(' + fn.iso8601date(this.dateFrom) + ')';
				} else {
					this.note = '(' + fn.iso8601date(this.dateFrom) + ' ~ ' + fn.iso8601date(this.dateTo) + ')';												
				}
			}
		}));

		// TODO: 코드 정리
		let updateCounts = _.debounce(() => {
			this.api.request("GET", "/task/count").then((counts) => {
				this.nodes.importants.notCompleted = counts.importants;
				this.nodes.assignments.notCompleted = counts.assignments;
			});
		}, 1000);

		$.when(gotMe).then((me) => {
			this.nodes.assignments.meIdx = me.idx;
		});
		$.when(gotUserLists).then(() => this.userListTreeLoaded = true); 
		$.when(gotUserLists, gotMe).then(() => {
			this.nodes.inbox.link(this.userListTree.getListNodeByIdx(this.me.inboxIdx));
			updateCounts();
		});
		
		storeEvents.$on('on-task-update', updateCounts);
		storeEvents.$on('on-task-deletion', updateCounts);
		storeEvents.$on('on-list-deletion', updateCounts);

		$.when(gotUserLists).then(() => this.loadInvitations());
		return (this.ready = $.when(gotUserLists, gotMe));
	},

	loadMe() {
		return this.api.me().then((me) => _.extend(this.me, me));
	},

	loadInvitations() {
		this.xhrSchedules.loadInvitations(() => this.api.invitations()).then((lists) => {
			let oldNodes = this.nodes.invitements.children;
			let oldIdxes = _.pluck(oldNodes, 'idx');
			let newIdxes = _.pluck(lists, 'idx');
			let nodeIndex = _.indexBy(oldNodes, 'idx');
			let listIndex = _.indexBy(lists, 'idx');
			for (let idx of _.difference(oldIdxes, newIdxes)) {
				nodeIndex[idx].parent.removeChild(nodeIndex[idx]);
			}
			for (let idx of _.difference(newIdxes, oldIdxes)) {
				this.nodes.invitements.appendChild(this.builtInListTree.createNode('invitation', listIndex[idx]));
			}
			for (let idx of _.intersection(newIdxes, oldIdxes)) {
				_.extend(nodeIndex[idx], listIndex[idx]);
			}
		});
	},

	acceptList(idx) {
		let invitation = this.builtInListTree.getNodeBy((n) => n.type == 'invitation' && n.idx == idx);
		if (invitation) {
			invitation.parent.removeChild(invitation);
			this.api.acceptInvitation(idx).then((list) => {
				this.userListTree.updateListNode(list);
			});
		}
	},

	rejectList(idx) {
		let invitation = this.builtInListTree.getNodeBy((n) => n.type == 'invitation' && n.idx == idx);
		if (invitation) {
			invitation.parent.removeChild(invitation);
			this.api.rejectInvitation(idx);
		}
	},

	syncDeletedList(idx) {
		let node = this.userListTree.getListNodeByIdx(idx) || this.builtInListTree.getNodeBy((n) => n.type == 'invitation' && n.idx == idx);
		if (node) {
			node.parent.removeChild(node);
			return;
		}
	},
	
	syncList(idx) {
		this.xhrSchedules.syncList(idx, () => this.api.getList(idx)).then((list) => {
			this.userListTree.updateListNode(list);
		});
	},

	findTaskByIdx(taskIdx) {
		for (let section of this.main.sections) {
			let task = section.findTaskByIdx(taskIdx);
			if (task) {
				return task;
			}
		}
	},

	addTask(task) {
		task = new Task(task);
		this.main.beforeAddTask(task);
		return this.api.updateTask('', task).then((result) => {
			_.extend(task, result);
			this.userListTree.updateNotCompleted(result.listIdx);
			this.main.handleTaskUpdate(task, 'insert');
			return result;
		});
	},

	deleteTasks(tasks) {
		let chain = _.chain(tasks.slice(0));
		if (chain.indexOf(this.taskEditor.selectedTask).value() >= 0) {
			this.unloadTaskEditor();
		}
		chain.each((task) => this.selection.remove(task));

		return this.api.deleteTask(chain.pluck('idx').value().join(',')).then(() => {
			chain.pluck('listIdx').unique().each((listIdx) => this.userListTree.updateNotCompleted(listIdx));
			chain.each((task) => this.main.handleDeletedTask(task));
		});
	},

	updateTasks(tasks, updates) {
		tasks = tasks.slice(0);
		let chain = _.chain(tasks.slice(0));
		let listIdxes = chain.pluck('listIdx').value();
		this.api.updateTask(chain.pluck('idx').value().join(','), updates, true).then((results) => {
			let indexedTasks = _.indexBy(tasks, 'idx');
			let affectedListIdxes = _.union(_.pluck(results, 'listIdx'), _.pluck(tasks, 'listIdx'));
			
			affectedListIdxes.forEach((idx) => this.userListTree.updateNotCompleted(idx));
			results.forEach((result) => _.extend(indexedTasks[result.idx], result));
			tasks.forEach((task) => this.main.handleTaskUpdate(task, "update"));
		});
	},

	updateTask(task, updates) {
		return this.api.updateTask(task.idx, updates).then((result) => {
			this.userListTree.updateNotCompleted(task.listIdx);
			if (task.listIdx != result.listIdx) {
				this.userListTree.updateNotCompleted(result.listIdx);
			}
			_.extend(task, result);
			this.main.handleTaskUpdate(task, "update");
			return task;
		});
	},
	
	syncEntityCounts(task) {
		this.xhrSchedules.syncTask(task.idx, () => this.api.countEntities(task.idx)).then((count) => {
			_.extend(task, count[task.idx] || {
				subtasks: 0,
				subtasksDone: 0,
				comments: 0,
				attachments: 0
			});
		});
	},
	
	syncEntityCountsByIdx(idx) {
		let task = this.findTaskByIdx(idx);
		if (task) {
			this.syncEntityCounts(task);
		}
	},

	syncNewTask(idx) {
		this.xhrSchedules.syncTask(idx, () => this.api.getTask(idx)).then((task) => {
			this.main.handleTaskUpdate(new Task(task), 'insert');
			this.userListTree.updateNotCompleted(task.listIdx);
		});
	},

	syncTask(idx) {
		let task = this.main.findTaskByIdx(idx);
		if (!task) {
			task = new Task({idx});
		}
		this.xhrSchedules.syncTask(idx, () => this.api.getTask(idx)).then((updated) => {
			_.extend(task, updated);
			this.userListTree.updateNotCompleted(task.listIdx);
			this.main.handleTaskUpdate(task, 'update');
		});
	},
	
	syncDeletedTask(idx) {
		let task = this.main.findTaskByIdx(idx);
		if (task) {
			this.main.handleDeletedTask(task);
			this.userListTree.updateNotCompleted(task.listIdx);
		}
	},

	cloneTasks(tasks, updates) {
		this.api.cloneTask(_.pluck(tasks, 'idx').join(','), updates).then((results) => {
			let chain = _.chain(results).map((r) => new Task(r));
			chain.pluck("listIdx").unique().each((listIdx) => this.userListTree.updateNotCompleted(listIdx));				
			chain.each((task) => this.main.handleTaskUpdate(task, "insert"));					
		});
	},

	loadTaskEditor(idx) {
		this.unloadTaskEditor();
		let task = this.findTaskByIdx(idx);
		if (task) {
			task.editing = true;
			this.taskEditor.selectedTask = task;
		}
		this.taskEditor.loaded = false;
		this.xhrSchedules.loadTask(() => this.api.getTask(idx)).then((data) => {
			this.taskEditor.selectedTask = _.extend(task || {}, data);
			this.taskEditor.loaded = true;
		});
	},

	unloadTaskEditor() {
		if (this.taskEditor.selectedTask) {
			this.taskEditor.selectedTask.editing = false;
			this.taskEditor.selectedTask = null;
			this.taskEditor.loaded = false;
		}
	},

	selectRange(task) {
		if (this.selection.items.length) {
			let anchor = this.selection.items[0];
			let anchorSection = this.main.findSectionByTask(anchor);
			let targetSection = this.main.findSectionByTask(task);
			if (anchorSection && targetSection) {
				this.selection.reset();
				let anchorSectionIndex = this.main.sections.indexOf(anchorSection);
				let targetSectionIndex = this.main.sections.indexOf(targetSection);
				let anchorIndex = anchorSection.tasks.indexOf(anchor);
				let targetIndex = targetSection.tasks.indexOf(task);
				let i, j, firstJ, lastJ, section;
				if (anchorSectionIndex < targetSectionIndex) {
					firstJ = anchorIndex;
					for (i = anchorSectionIndex; i <= targetSectionIndex; i++) {
						section = this.main.sections[i];
						lastJ = (section == targetSection) ? targetIndex + 1 : section.tasks.length;
						for (j = firstJ; j < lastJ; j++) {
							this.selection.add(section.tasks[j]);
						}
						firstJ = 0;
					}
				} else if (anchorSectionIndex > targetSectionIndex) {
					firstJ = targetIndex;
					for (i = targetSectionIndex; i <= anchorSectionIndex; i++) {
						section = this.main.sections[i];
						lastJ = (section == anchorSection) ? anchorIndex + 1 : section.tasks.length;
						for (j = firstJ; j < lastJ; j++) {
							this.selection.add(section.tasks[j]);
						}
						firstJ = 0;
					}
				} else {
					if (anchorIndex < targetIndex) {
						for (let i = anchorIndex; i <= targetIndex; i++) {
							this.selection.add(anchorSection.tasks[i]);
						}
					} else if (anchorIndex > targetIndex) {
						for (let i = targetIndex; i <= anchorIndex; i++) {
							this.selection.add(anchorSection.tasks[i]);
						}
					} else {
						// pass
					}
				}
			} else {
				// pass
			}
		} else {
			this.selection.add(task);
		}
	}
};

})();
