ListSectionLoader = {
	unloaded() {

	},
	beforeLoad() {

	},
	requestSections() {
		return fn.resolvedDefer([]);
	},
	handleDeletedList(mainView, list) {
		
	},
	beforeAddTask(task) {
		
	},
	handleTaskUpdate(mainView, task, mode) {

	}
};

function ListNode(api, list) {
	_.extend(this, list);
	this.api = api;
	this.notCompleted = undefined;
	this.isSelected = false;
}
ListNode.prototype = _.extend(Object.create(ListSectionLoader), {
	requestSections() {
		return this.api.getTasks(this.idx);
	},
	handleDeletedList(mainView, list) {
		if (list.idx == this.idx) {
			mainView.error = "목록이 삭제됐습니다.";
		}
	},
	beforeAddTask(task) {
		task.listIdx = this.idx;
	},
	handleTaskUpdate(mainView, task, mode) {
		let section = mainView.findSectionByTask(task);
		if (this.idx != task.listIdx) {
			if (section) {
				section.remove(task);
			}
			return;
		} else {
			let completed = mainView.sections[1];
			let notCompleted = mainView.sections[0];
			let rightSection = (task.completed) ? completed : notCompleted;
			if (section != rightSection) {
				if (section) {
					section.remove(task);
				}
			}
			mainView.insortTask(rightSection, task);
		}
	}	
});

function InboxNode(api) {
	this.api = api;
	this.name = '임시 보관함';
	this.isSelected = false;
	this.isHidden = false;

	this.linkedNode = null;
	this.idx = null;
	this.componentName = 'inbox-node';
	this.htmlId = 'inbox-node';
}

InboxNode.prototype = _.extend(Object.create(ListSectionLoader), {
	link(node) {
		this.linkedNode = node;
		this.idx = node.idx;
	},
	requestSections() {
		return this.linkedNode.requestSections();
	},
	beforeAddTask(task) {
		return this.linkedNode.beforeAddTask(task);
	},
	handleTaskUpdate(mainView, task, mode) {
		return this.linkedNode.handleTaskUpdate(mainView, task, mode);
	}
	
});

function ImportantsNode(api) {
	this.api = api;
	this.name = '중요 표시';
	this.route = '/list/importants';
	this.icon = 'star-empty';
	this.iconClass = 'star-empty-red';
	this.isSelected = false;
	this.notCompleted = 0;
	this.componentName = 'built-in-node';
}
ImportantsNode.prototype = _.extend(Object.create(ListSectionLoader), {
	requestSections() {
		return this.api.importants();
	},
	beforeAddTask(task) {
		task.important = true;
	},
	handleTaskUpdate(mainView, task, mode) {
		let section = mainView.findSectionByTask(task);
		if (!task.important) {
			if (section) {
				section.remove(task);
			}
			return;
		} else {
			let rightSection = _.findWhere(mainView.sections, {type: 'list', arg: task.listIdx});
			if (!rightSection) {
				rightSection = mainView.appendSection('list', task.listIdx);
			}
			if (rightSection != section) {
				if (section) {
					section.remove(task);
				}
			}
			mainView.insortTask(rightSection, task);
		}
	}
});

function AssignmentsNode(api) {
	this.api = api;
	this.meIdx = null;
	this.name = '내가 담당한 일';
	this.isSelected = false;
	this.route = '/list/assignments';
	this.icon = 'user';
	this.iconClass = 'user-skyblue';
	this.componentName = 'built-in-node';
	this.notCompleted = 0;
}
AssignmentsNode.prototype = _.extend(Object.create(ListSectionLoader), {
	requestSections() {
		return this.api.assignments();
	},
	handleTaskUpdate(mainView, task, mode) {
		return this.api.getAssignees(task.idx).then((users) => {
			let section = mainView.findSectionByTask(task);
			let match = _.findWhere(users, {idx: this.meIdx});
			if (match) {
				let rightSection = _.findWhere(mainView.sections, {type: 'list', arg: task.listIdx});
				if (!rightSection) {
					rightSection = mainView.appendSection('list', task.listIdx);
				}
				if (rightSection != section) {
					if (section) {
						section.remove(task);
					}
				}
				mainView.insortTask(rightSection, task);
			} else {
				if (section) {
					section.remove(task);
				}
			}
		});
	}
});

function InvitationNode(list) {
	_.extend(this, list);
	this.componentName = 'invitation-node';
}

function DateFilterNode(api, attrs) {
	_.extend(this, attrs);
	this.isSelected = false;
	this.api = api;
	this.componentName = 'built-in-node';
	this.note = undefined;
}

DateFilterNode.prototype = _.extend(Object.create(ListSectionLoader), {
	requestSections() {
		return this.api.byDate(this.params());
	},
	handleTaskUpdate(mainView, task, mode) {
		let match = this.match(task);
		let params = this.params();
		let section = mainView.findSectionByTask(task);
		if (match) {
			if (params.group == 'list') {
				let rightSection = _.findWhere(mainView.sections, {type: 'list', arg: task.listIdx});
				if (!rightSection) {
					rightSection = mainView.appendSection('list', task.listIdx);
				}
				if (section) {
					section.remove(task);
				}
				mainView.insortTask(rightSection, task);
			} else if (params.group == 'daily') {
				let rightSection = _.findWhere(mainView.sections, {type: 'day', arg: task.dueDatetime});
				if (!rightSection) {
					rightSection = mainView.appendSection('day', task.dueDatetime);
					mainView.sections.pop();
					mainView.sections.splice(_.sortedIndex(mainView.sections, rightSection, 'arg'), 0, rightSection);
				}
				if (section) {
					section.remove(task);					
				}
				mainView.insortTask(rightSection, task);
			} else {
				console.warn("DateFilterNode.prototype.handleTaskUpdate is not implemented for " + params.group + " grouping.");
			}
		} else {
			if (section) {
				section.remove(task);
			}
		}
	},
	match(task) {
		if (!task.dueDatetime) {
			return false;
		}
		let date = fn.iso8601date(new Date(task.dueDatetime));
		let params = this.params();
		if (params.dateFrom && date < params.dateFrom) {
			return false;
		}
		if (params.dateTo && params.dateTo <= date) {
			return false;
		}
		return true;
	}
});

UserListTree = function UserListTree(api) {
	Tree.call(this);
	this.api = api;
	this.addType('list', ListNode);
	this.addType('folder', function Folder(attrs) {
		_.extend(this, {
			name: '새 폴더',
			isCollapsed: false,
			initEdit: false,
			isSelected: false
		}, attrs);
	});
	this.xhrSchedules = {
		countNotCompleted: fn.limitParallelXhr(3),
		myLists: fn.singleXhr('abort'),
		sortLists: fn.singleXhr('abort')
	};
}

UserListTree.prototype = _.extend(Object.create(Tree.prototype), {
	getListNodeByIdx(idx) {
		return this.getNodeBy((n) => n.type == 'list' && n.idx == idx);
	},
	getFolderNodeByName(name) {
		return this.getNodeBy((n) => n.type == 'folder' && n.name == name);
	},
	removeListNodeByIdx(idx) {
		let node = this.getListNodeByIdx(idx);
		if (node) {
			node.parent.removeChild(node);
		}
		return node;
	},
	updateListNode(list) {
		let node = this.getListNodeByIdx(list.idx);
		if (node) {
			_.extend(node, list);
		} else {
			node = this.createNode('list', this.api, list);
		}

		let parent = node.parent;
		if (list.folder) {
			let parentChanged = (!parent || parent.type != 'folder' || list.folder != parent.name);
			if (parentChanged) {
				let newParent = this.getFolderNodeByName(list.folder);
				if (!newParent) {
					newParent = this.createNode('folder', {name: list.folder});
					this.root.insertChildAt((parent) ? parent.indexOf(node) : 0, newParent);
				}
				newParent.appendChild(node);
			}
		} else {
			if (parent) {
				if (parent.type) {
					this.root.insertChildAt(parent.indexOf(node), node);
				}
			} else {
				this.root.insertChildAt(0, node);
			}
		}
	},
	updateNotCompleted(idx) {
		this.xhrSchedules.countNotCompleted(idx, () => this.api.countNotCompleted(idx)).then((count) => {
			let node = this.getListNodeByIdx(idx);
			if (node) {
				node.notCompleted = count;
			}
		});
	},
	unfolder(folder) {
		if (folder.type != 'folder') {
			return;
		}
		let parent = folder.parent;
		let index = parent.indexOf(folder);
		let children = folder.resetChildren();
		parent.removeChild(folder);
		children.forEach((child, i) => {
			parent.insertChildAt(index + i, child);
		});
	},
	enfolder(node) {
		let folder = this.createNode('folder', {initEdit: true});
		node.parent.insertChildAt(node.parent.indexOf(node), folder);
		folder.appendChild(node);
		return folder;
	},
	saveRenamedNode(node) {
		if (node.type == 'folder') {
			this.saveTree();
		} else {
			this.api.updateList(node.idx, {name: node.name}).then((newData) => this.updateListNode(newData));
		}
	},
	saveTree() {
		let idxes = [];
		this.walk((node) => {
			// remove empty folder
			if (node.type == 'folder' && !node.children.length) {
				node.parent.removeChild(node);
			} else if (node.type == 'list' && !node.inbox) {
				if (node.parent.type == 'folder') {
					idxes.push(node.idx + ':' + node.parent.name);
				} else {
					idxes.push(node.idx);
				}
			}
		});
		if (idxes.length) {
			this.xhrSchedules.sortLists(() => this.api.request("POST", "/sortLists", {idxes}));
		}
	},

	loadTree() {
		return this.xhrSchedules.myLists(() => this.api.myLists()).then((lists) => {
			let parent = this.root;
			lists.forEach((list) => {
				// inbox는 언제나 제일 앞에 붙인다.
				if (list.inbox) {
					this.root.insertChildAt(0, this.createNode('list', this.api, list));
					return;
				}

				if (list.folder) {
					if (parent.type != 'folder' || parent.name != list.folder) {
						parent = this.root.appendChild(this.createNode('folder', {
							name: list.folder,
							isCollapsed: false
						}));
					}
					parent.appendChild(this.createNode('list', this.api, list));
				} else {
					parent = this.root;
					parent.appendChild(this.createNode('list', this.api, list));
				}
			});
		});
	},
	
	generateContextmenu(makeItem, node) {
		node = node || this.root;
		return node.children.map((child) => {
			if (child.type == 'folder') {
				return {
					name: child.name,
					icon: 'folder-o',
					children: this.generateContextmenu(makeItem, child)
				}
			} else {
				return makeItem(child);
			}
		});
	}
});

BuiltInListTree = function BuiltInListTree(api) {
	Tree.call(this);
	this.api = api;
	this.addType('inbox', InboxNode);
	this.addType('invitation', InvitationNode);
	this.addType('importants', ImportantsNode);
	this.addType('assignments', AssignmentsNode);
	this.addType('folder', function BuiltInFolder(name, icon, attrs) {
		this.icon = icon;
		this.iconClass = null;
		this.isCollapsed = false;
		_.extend(this, attrs);
		this.name = name;
		this.componentName = 'built-in-folder';
	});
	this.addType('date-filter', DateFilterNode);
	this.addType('calendar', function CalendarNode() {
		this.componentName = 'built-in-node';
		this.icon = 'calendar-table';
		this.name = '달력';
		this.route = '/calendar';
		this.isSelected = false;
	});

	this.xhrSchedules = {
		loadInvitations: fn.singleXhr('abort'),
	}
}

BuiltInListTree.prototype = _.extend(Object.create(Tree.prototype), {
	
});
